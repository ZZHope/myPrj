//
//  ImageControl.m
//  xike
//
//  Created by Leading Chen on 14-9-2.
//  Copyright (c) 2014年 Leading. All rights reserved.
//

#import "ImageControl.h"

@implementation ImageControl

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
