//
//  NewFeatureViewController.h
//  shaker
//
//  Created by a on 15/4/17.
//  Copyright (c) 2015年 manyStyle. All rights reserved.
//  引导页

#import <UIKit/UIKit.h>

@interface NewFeatureViewController : UIViewController

@end
