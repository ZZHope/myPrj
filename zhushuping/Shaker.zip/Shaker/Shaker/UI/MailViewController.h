//
//  MailViewController.h
//  Shaker
//
//  Created by shaker on 15/5/24.
//  Copyright (c) 2015年 Shaker. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NavigationBar.h"

@interface MailViewController : UIViewController

@end
