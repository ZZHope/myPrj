//
//  AboutUSViewController.h
//  Shaker
//
//  Created by Leading Chen on 15/5/13.
//  Copyright (c) 2015年 Shaker. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NavigationBar.h"

@interface AboutUSViewController : UIViewController <NavigationBarDelegate>

@end
