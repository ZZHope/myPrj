//
//  UserInfo.m
//  Shaker2
//
//  Created by Leading Chen on 15/3/30.
//  Copyright (c) 2015年 Shaker. All rights reserved.
//

#import "UserInfo.h"

@implementation UserInfo

@end
