//
//  AppDelegate.m
//  xike
//
//  Created by shaker on 15/6/1.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "AppDelegate.h"
#import "ShakerManager.h"
#import "common.h"
#import "WXApi.h"
#import "ShareEngine.h"
#import "UserSingleton.h"
#import "MobClick.h"

@interface AppDelegate ()<WXApiDelegate>

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    [NSThread sleepForTimeInterval:1.0];//可以让加载页面显示时间更长点
#pragma mark -- deal with remote notification when app close
    
#pragma mark -- 临时
    
//    [UserSingleton shareUserSingleton].deviceToken = @"23be476fdcc462818d758fade605c1bc41b6587dc875519112fe159e7883652c";
    //0821
//    [[NSUserDefaults standardUserDefaults] setObject:@"23be476fdcc462818d758fade605c1bc41b6587dc875519112fe159e7883652c" forKey:kDeviceToken];
//    [[NSUserDefaults standardUserDefaults]synchronize];

#pragma mark -- 通知
    //注册远程通知
    if (DeviceVersion>=8.0) {

        [[UIApplication sharedApplication]registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeBadge|UIUserNotificationTypeSound|UIUserNotificationTypeAlert) categories:nil]];
        [[UIApplication sharedApplication]registerForRemoteNotifications];//ios8必须加上这句话
    
    }else{
        
        [[UIApplication sharedApplication]registerForRemoteNotificationTypes:UIUserNotificationTypeBadge|UIUserNotificationTypeSound|UIUserNotificationTypeAlert];
    }
    
    
#pragma mark - 
#pragma mark -- 首次下载使用这个版本的软件(包括友盟版本的设置)
    
    [self firstLaunch];
    
#pragma mark -- UMeng
    //batch 根据环境和要求更改
    //channelId:@""or nil默认作为@“app store”并且@“appstore”不可以作为chnnel的名称
    [MobClick startWithAppkey:@"55b998fbe0f55a431e007964" reportPolicy:REALTIME channelId:@""];
    [MobClick setEncryptEnabled:YES];
    [MobClick setLogEnabled:YES];

    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];

    
    return YES;
}

-(BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url
{
    return [[ShareEngine sharedInstance] handleOpenURL:url];
}


-(BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
{
    //创建通知
    NSNotification *notification =[NSNotification notificationWithName:@"changeNav" object:nil userInfo:nil];
    //通过通知中心发送通知
    [[NSNotificationCenter defaultCenter] postNotification:notification];
    return [[ShareEngine sharedInstance]handleOpenURL:url];
    
    
    
}

#pragma mark -- 通知

-(void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
  
    NSString *token = [[deviceToken description] stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"<>"]];
    NSString *device = [token stringByReplacingOccurrencesOfString:@" " withString:@""];
    [UserSingleton shareUserSingleton].deviceToken =device;
    [[NSUserDefaults standardUserDefaults] setObject:device forKey:kDeviceToken];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
   // 23be476fdcc462818d758fade605c1bc41b6587dc875519112fe159e7883652c
    
   // NSLog(@"======remote : %@",device);
}

-(void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error
{
    NSLog(@"error:==%@",error);
}

//app后台运行时候点击通知调用的方法

-(void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    NSLog(@"%@",userInfo);
}


#pragma mark -- custom method
#pragma mark 如果是首次下载使用这个版本的软件，那么需要弹出用户指引界面
-(void)firstLaunch
{

    
    /*
     1.判断是否第一次使用这个版本
     */
    NSString *key = @"CFBundleShortVersionString";
    
    // 1.1.先去沙盒中取出上次使用的版本号
    NSString *lastVersionCode = [[NSUserDefaults standardUserDefaults] objectForKey:key];
    
    // 1.2.加载程序中info.plist文件(获得当前软件的版本号)
    NSString *currentVersionCode = [NSBundle mainBundle].infoDictionary[key];
    
    //Umeng
        [MobClick setAppVersion:currentVersionCode];
    if ([lastVersionCode isEqualToString:currentVersionCode]) {
        // 非第一次使用软件
        [ShakerManager presentViewControllerWithType:SHAKERMAIN];
        [UIApplication sharedApplication].statusBarHidden = NO;
        
        //判断一下登陆情况等
        //TODO
        
        
    } else {
        // 第一次使用软件
        
        // 1.3.保存当前软件版本号
        
        [[NSUserDefaults standardUserDefaults] setObject:currentVersionCode forKey:key];
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:isLogin];
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:kIsLantingD];
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:kIsSongD];
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:kIsFangSongD];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        
        // 1.4.新特性控制器（指引界面）
        [ShakerManager presentViewControllerWithType:SHAKERGUIDE];
        [UIApplication sharedApplication].statusBarHidden = YES;
    }

}
@end
