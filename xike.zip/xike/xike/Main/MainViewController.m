//
//  TabBarViewController.m
//  xike
//
//  Created by shaker on 15/6/1.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "MainViewController.h"
#import "common.h"

#import "HomeViewController.h"
#import "RecommendViewController.h"
#import "AddTopicViewController.h"
#import "MsgViewController.h"
#import "UserViewController.h"


@interface MainViewController ()<UITabBarControllerDelegate>


@end

@implementation MainViewController
//@synthesize lastSelectIndex = _lastSelectIndex;

- (void)viewDidLoad {
    [super viewDidLoad];

    
    [self creatViewControllers];
}


#pragma mark -- controllers

-(void)creatViewControllers
{
    RecommendViewController *recommendVC = [[RecommendViewController alloc]init];

    recommendVC.tabBarItem = [self menuWithPic:[UIImage imageNamed:@"xike"] normalImg:[UIImage imageNamed:@"xike1"]];
    recommendVC.navigationController.navigationBar.translucent= NO;
    
    HomeViewController *homeVC = [[HomeViewController alloc]init];
    homeVC.tabBarItem = [self menuWithPic:[UIImage imageNamed:@"jing xuan"] normalImg:[UIImage imageNamed:@"jing xuan1"]];
    homeVC.navigationController.navigationBar.translucent= NO;
    
    
    AddTopicViewController *addVC = [[AddTopicViewController alloc]init];
    addVC.tabBarItem = [self menuWithPic:[UIImage imageNamed:@"chuang jian"] normalImg:[UIImage imageNamed:@"chuang jian1"]];
    addVC.navigationController.navigationBar.translucent= NO;
    
    
    MsgViewController *msgVC = [[MsgViewController alloc]init];
    msgVC.tabBarItem = [self menuWithPic:[UIImage imageNamed:@"xiao xi"] normalImg:[UIImage imageNamed:@"xiao xi1"]];
    msgVC.navigationController.navigationBar.translucent= NO;
    
    
    UserViewController *userVC = [[UserViewController alloc]init];
    userVC.tabBarItem = [self menuWithPic:[UIImage imageNamed:@"zuo zhe"] normalImg:[UIImage imageNamed:@"zuo zhe1"]];
    userVC.navigationController.navigationBar.translucent= NO;

    
    NSArray *VCs = @[recommendVC,homeVC,addVC,msgVC,userVC];
    NSMutableArray *navVCs = [NSMutableArray arrayWithCapacity:5];
    for (UIViewController *controller in VCs) {
        UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:controller];
        [navVCs addObject:nav];
        
    }

    self.viewControllers = navVCs;
    self.tabBar.translucent = NO;
    self.tabBar.backgroundColor = [UIColor whiteColor];

}


-(UITabBarItem *)menuWithPic:(UIImage *)highImg normalImg:(UIImage *)normalImg
{
    
    UITabBarItem *barItem = [[UITabBarItem alloc] initWithTitle:nil image:normalImg selectedImage:[highImg imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];

    // 矫正TabBar图片位置，使之垂直居中显示
    CGFloat offset = 5.0;
    barItem.imageInsets = UIEdgeInsetsMake(offset, 0, -offset, 0);
    
    return barItem;
}


#pragma mark -- delegate

-(void)setSelectedIndex:(NSUInteger)selectedIndex
{
    if (self.selectedIndex != selectedIndex) {
        //self.lastSelectIndex =(NSUInteger)self.selectedIndex;
    }
}
-(void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
