//
//  ShakerDataBaseManager.h
//  xike
//
//  Created by shaker on 15/7/23.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "dataBaseCommon.h"
#import "FMDatabase.h"

@interface ShakerDataBaseManager : NSObject

@property(nonatomic, strong) NSString *dbPath;
@property(nonatomic, strong) FMDatabase *shakerDB;

+(instancetype)shareInstance;
-(void)addNewUserInfoWithData:(NSDictionary*)userInfo;
-(void)changeUserInfo:(NSString*)userId key:(NSString*)key value:(NSString*)value;
-(BOOL)userIsExsitWithId:(NSString*)userId WithTableName:(NSString *)table;
-(void)addNewRelationShipWithUserId:(NSString*)userId fansId:(NSString*)fansId;
-(void)insertNewTypeFaceWithInfo:(NSDictionary *)dic;
-(BOOL)typeIsExsistWithTypeFaceName:(NSString *)faceName;
-(NSDictionary *)queryTypeInfoWithUserId:(NSString *)userId typeFaceName:(NSString *)typeFaceName;
-(void)closeDB;

@end
