//
//  ShakerDataBaseManager.m
//  xike
//
//  Created by shaker on 15/7/23.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "ShakerDataBaseManager.h"


static ShakerDataBaseManager *shakerDBManager;

@interface ShakerDataBaseManager()


@end

@implementation ShakerDataBaseManager

+(instancetype)shareInstance
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shakerDBManager = [[ShakerDataBaseManager alloc]init];
        
    });

    return shakerDBManager;
}

-(id)init
{
    if (self = [super init]) {
        
        NSString *documentPath = NSSearchPathForDirectoriesInDomains( NSDocumentDirectory,  NSUserDomainMask, YES)[0];
    
        
        self.dbPath = [documentPath stringByAppendingPathComponent:kDataBaseName];

       // self.dbPath = [self saveFileToDocument:kDataBaseName];
        self.shakerDB = [FMDatabase databaseWithPath:self.dbPath];
        [self.shakerDB open];
        [self creatTableWithName:kUserInfoTable];
        [self creatTableWithName:kRelationShipTable];
        [self creatTableWithName:kTypeFaceTable];
        NSLog(@"db path:===  %@",self.dbPath);
    }
    return self;
}


-(void)creatTableWithName:(NSString *)tableName
{
    if ([self.shakerDB open]) {
        
        NSString *creatSql;
        if ([tableName isEqualToString:kUserInfoTable]) {
            //创建userinfo表
            creatSql = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS '%@'('%@' TEXT, '%@' TEXT, '%@' TEXT, '%@' VARCHAR NOT NULL, '%@' INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE)",kUserInfoTable,kAccount,kNickName,kProfileUrl,kUserId,@"orderId"];
        }else if([tableName isEqualToString:kRelationShipTable]){

            //创建relation表
            creatSql = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS '%@'('%@' VARCHAR NOT NULL, '%@' VARCHAR NOT NULL, '%@' INTEGER PRIMARY KEY AUTOINCREMENT)",kRelationShipTable,kUserId,kFansId,@"id"];
        }else{
            creatSql = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS'%@' ('%@' INTEGER PRIMARY KEY AUTOINCREMENT, '%@' VARCHAR, '%@' TEXT, '%@' FLOAT, '%@' VARCHAR)",kTypeFaceTable,@"orderId",kTypeFaceName,kTypePath,kTypeSize,kUserId];
        }
        
        [self.shakerDB executeUpdate:creatSql];
    }
}

#pragma mark -- userInfo
//存入user
-(void)addNewUserInfoWithData:(NSDictionary*)userInfo
{
    [self.shakerDB open];
    NSMutableString *insertSQL = [[NSMutableString alloc]init];
    [insertSQL appendString:@"INSERT INTO "];
    [insertSQL appendString:kUserInfoTable];
    [insertSQL appendString:@"('userId','account','nickName','profileUrl') VALUES (?,?,?,?)"];//?不可以加单引号
    BOOL isInsertOK = [self.shakerDB executeUpdate:insertSQL,
                       [userInfo objectForKey:kUserId],
                       [userInfo objectForKey:kAccount],
                       [userInfo objectForKey:kNickName],
                       [userInfo objectForKey:kProfileUrl]];
    if (isInsertOK) {
        NSLog(@"保存成功");
    }else {
        NSLog(@"保存失败 :%@",[self.shakerDB lastErrorMessage]);
    }
    
    [self.shakerDB close];
}

-(void)changeUserInfo:(NSString*)userId key:(NSString*)key value:(NSString*)value
{
    [self.shakerDB open];
    NSString *updateStr = [NSString stringWithFormat:@"UPDATE '%@' SET '%@' = '%@' WHERE userId = '%@'",kUserInfoTable,key,value,userId];
    BOOL isOK = [self.shakerDB executeUpdate:updateStr];
    if (isOK) {
        
        NSLog(@"chage success");
        
    }else
    {
        NSLog(@"change error:%@",[self.shakerDB lastError]);
    }
    
    [self.shakerDB close];
}

//search userinfo and typaface

-(BOOL)userIsExsitWithId:(NSString*)userId WithTableName:(NSString *)table
{
    [self.shakerDB open];
    BOOL isExist = NO;
    NSMutableString *selectStr = [[NSMutableString alloc]init];
    [selectStr appendString:@"SELECT 'userId' FROM "];
    [selectStr appendString:table];
    
    FMResultSet *set = [self.shakerDB executeQuery:selectStr];
    while ([set next]) {
        
        if ([[set stringForColumn:@"userId"] isEqualToString:userId]) {
            
             isExist = YES;
            break;
        }
    }
    [self.shakerDB close];
    return isExist;
}

#pragma mark -- relationShip

-(void)addNewRelationShipWithUserId:(NSString*)userId fansId:(NSString*)fansId
{
    [self.shakerDB open];
    NSMutableString *insertSQL = [[NSMutableString alloc]init];
    [insertSQL appendString:@"INSERT INTO "];
    [insertSQL appendString:kUserInfoTable];
    [insertSQL appendString:@"('userId','fansId') VALUES (?,?)"];//?不可以加单引号
    BOOL isInsertOK = [self.shakerDB executeUpdate:insertSQL,
                       userId,fansId];
    if (isInsertOK) {
        NSLog(@"保存成功");
    }else {
        NSLog(@"保存失败 :%@",[self.shakerDB lastErrorMessage]);
    }

    [self.shakerDB close];
}


#pragma mark -- typeFace
-(void)insertNewTypeFaceWithInfo:(NSDictionary *)dic
{
    [self.shakerDB open];
    
    NSMutableString *insertSql  = [[NSMutableString alloc]init];
    [insertSql appendString:@"INSERT INTO "];
    [insertSql appendString:kTypeFaceTable];
    [insertSql appendString:@"('typeFaceName','typePath','typeSize','userId') VALUES (?,?,?,?)"];
    BOOL isInsert = [self.shakerDB executeUpdate:insertSql,
                     [dic objectForKey:kTypeFaceName],
                     [dic objectForKey:kTypePath],
                     [dic objectForKey:kTypeSize],
                     [dic objectForKey:kUserId]
                    ];
    if (isInsert) {
        NSLog(@"type save ok");
    }else{
        NSLog(@"type save failed:%@",[self.shakerDB lastErrorMessage]);
    }
    
    [self.shakerDB close];
}


-(BOOL)typeIsExsistWithTypeFaceName:(NSString *)faceName
{
    [self.shakerDB open];
    BOOL isExist = NO;
    NSMutableString *selectStr = [[NSMutableString alloc]init];
    [selectStr appendString:@"SELECT 'typeFaceName' FROM "];
    [selectStr appendString:kTypeFaceTable];
    
    FMResultSet *set = [self.shakerDB executeQuery:selectStr];
    while ([set next]) {
        
        if ([[set stringForColumn:@"typeFaceName"] isEqualToString:faceName]) {
            
            isExist = YES;
            break;
        }
    }
    [self.shakerDB close];
    return isExist;

}

-(NSDictionary *)queryTypeInfoWithUserId:(NSString *)userId typeFaceName:(NSString *)typeFaceName
{
    [self.shakerDB open];
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    
    NSMutableString *selectSql = [[NSMutableString alloc]initWithString:@"SELECT * FROM "];
    [selectSql appendString:kTypeFaceTable];
    [selectSql appendString:[NSString stringWithFormat:@" WHERE userId = \"%@\" and typeFaceName = \"%@\"",userId,typeFaceName]];
    FMResultSet *set = [self.shakerDB executeQuery:selectSql];
    while ([set next]) {
        [dic setObject:[set stringForColumn:kTypeSize] forKey:kTypeSize];
        [dic setObject:[set stringForColumn:kTypePath] forKey:kTypePath];
    }
    
    [self.shakerDB close];
    return dic;
}

-(void)closeDB
{
    [self.shakerDB close];
    shakerDBManager = nil;
}

//将文件保存到document目录下
-(NSString *)saveFileToDocument:(NSString *)fileName
{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *error;
    NSArray *filePaths = NSSearchPathForDirectoriesInDomains( NSDocumentDirectory,  NSUserDomainMask, YES);
    NSString *documentPath = filePaths[0];
    
    NSString *destPath = [documentPath stringByAppendingPathComponent:fileName];
    
    //如果目录下已经存在此文件，将不再创建
    if (![fileManager fileExistsAtPath:destPath]) {
        
        [fileManager createDirectoryAtPath:destPath withIntermediateDirectories:YES attributes:nil error:&error];
        NSLog(@"file error: %@",error);
    }
    return destPath;
}



@end
