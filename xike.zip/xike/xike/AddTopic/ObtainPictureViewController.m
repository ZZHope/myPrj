//
//  ObtainPictureViewController.m
//  xike
//
//  Created by shaker on 15/6/16.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "ObtainPictureViewController.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import "CreatStyleFrameController.h"
#import "common.h"



@interface ObtainPictureViewController ()<UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout,UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@property (strong, nonatomic) NSMutableArray *photoArrM;
@property (strong, nonatomic) ALAssetsLibrary *assetsLibrary;
@property (strong, nonatomic) NSMutableArray *photoArrURL;
@property (strong, nonatomic) UICollectionView *collectionView;
@property (strong, nonatomic) UIImagePickerController *picker;
@property (strong, nonatomic) NSMutableArray *selPhotoArrM;
@property (strong, nonatomic) NSMutableArray *thumbArrM;
@property (assign, nonatomic) NSInteger phohtoNum;
@property (strong, nonatomic) NSMutableArray *convertArrM;
@property (strong, nonatomic) NSFileManager * fileManager;



@end

@implementation ObtainPictureViewController

static NSString * const reuseIdentifier = @"Cell";

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //navigation
    [self settingNavBar];
    self.navigationController.navigationBarHidden = NO;
    
    //获取照片数据
    _photoArrM = [NSMutableArray array];
    _photoArrURL = [NSMutableArray array];
    _selPhotoArrM = [NSMutableArray array];
    _thumbArrM = [NSMutableArray array];
    _convertArrM = [NSMutableArray array];

    [_photoArrURL addObject: @{kImgUrl:@"",kThumbnail:[UIImage imageNamed:@"xiangji"],kImgName:@""}];
    


    //生成整个photoLibrary句柄
    
    _assetsLibrary = [[ALAssetsLibrary alloc]init];
    //获取照片
    [self getPhotoPath];
    
    
    
//
   //collection
    UICollectionViewFlowLayout *flowLayout=[[UICollectionViewFlowLayout alloc]init];
    [flowLayout setScrollDirection:UICollectionViewScrollDirectionVertical];
    _collectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kHeight) collectionViewLayout:flowLayout];
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    [self.collectionView registerClass:[UICollectionViewCell class]
    forCellWithReuseIdentifier:reuseIdentifier];
    self.collectionView.backgroundColor = [UIColor whiteColor];
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.collectionView];
    
    
}



-(void)settingNavBar
{
    UIButton *leftBtn = [self customNaviButtonWithFrame:CGRectMake(0, 0, 30, 30) title:@"取消" tag:1001];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    UIButton *rightBtn = [self customNaviButtonWithFrame:CGRectMake(0, 0, 30, 30) title:@"完成" tag:1002];
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
    self.navigationItem.rightBarButtonItem = rightItem;
    
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 60, 30)];
    label.text=@"插入图片";
    label.font = [UIFont systemFontOfSize:15.0f];
    self.navigationItem.titleView = label;
    
}

//custom button
-(UIButton *)customNaviButtonWithFrame:(CGRect)frame title:(NSString *)title tag:(NSInteger)tag
{
    UIButton *btn = [[UIButton alloc]initWithFrame:frame];
    [btn setTitle:title forState:UIControlStateNormal];
    [btn setTitleColor: kColor(0, 216, 165) forState:UIControlStateNormal];
    btn.tag = tag;
    btn.titleLabel.font = [UIFont systemFontOfSize:15.0f];
    [btn addTarget:self action:@selector(photoNaviItemClick:) forControlEvents:UIControlEventTouchUpInside];
    
    return btn;
    
}

//nav Click
-(void)photoNaviItemClick:(UIButton *)sender
{
    switch (sender.tag) {
        case 1001://取消
             self.navigationController.navigationBarHidden=YES;
            [self.navigationController popViewControllerAnimated:YES];
            break;
        case 1002://完成
        {
        
            sender.userInteractionEnabled = NO;
            if (self.selPhotoArrM.count) {
            
                for (int i=0; i<self.selPhotoArrM.count; i++) {
                    
                    [self imageWithUrl:[self.selPhotoArrM[i] objectForKey:kImgUrl] withFileName:[self.selPhotoArrM[i] objectForKey:kImgName]];
                    
                    
                }

                
            }else{
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"" message:@"您没有选择任何图片" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
                [alert show];
            }

        }
            break;

            
        default:
            break;
    }
}




-(void)returnNewPhoto:(ReturnPhotoBlock)selectPhotoBlock
{
    self.selectPhotoBlock  =selectPhotoBlock;
}



#pragma mark <UICollectionViewDataSource>

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {

    return 1;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {

    return self.photoArrURL.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    
    [cell.contentView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    if (nil == cell) {
        cell = [[UICollectionViewCell alloc]init];
    }
    
    UIImageView *imgView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, (kWidth-8)/3.0, (kWidth-8)/3.0)];
    imgView.userInteractionEnabled = YES;
    if (indexPath.row == 0) {
        imgView.backgroundColor = kColor(0, 216, 165);
        UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake((CGRectGetWidth(imgView.frame)-38)/2, (CGRectGetHeight(imgView.frame)-34)/2, 38, 34)];
        [btn setImage:[self.photoArrURL[indexPath.row] objectForKey:kThumbnail] forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(takeCamera) forControlEvents:UIControlEventTouchUpInside];
        [imgView addSubview:btn];
    }else{
        
        imgView.image = [[self.photoArrURL objectAtIndex:indexPath.row] objectForKey:kThumbnail];
        if ([[self.photoArrURL[indexPath.row] objectForKey:kSelPhoto] boolValue]) {
            UIButton *flagBtn = [[UIButton alloc]initWithFrame:CGRectMake(CGRectGetWidth(imgView.frame)-20-10, 10, 20, 20)];
            [flagBtn setImage:[UIImage imageNamed:@"duihao"] forState:UIControlStateNormal];
            flagBtn.backgroundColor = kColor(0, 216, 165);
            flagBtn.layer.cornerRadius = 10.0f;
            imgView.layer.borderColor = [kColor(0, 216, 165) CGColor];
            imgView.layer.borderWidth = 2.0f;
            [imgView addSubview:flagBtn];
        }
    }

    

    [cell.contentView addSubview:imgView];
    return cell;
}

#pragma mark <UICollectionViewDelegate>



#pragma mark --UICollectionViewDelegateFlowLayout
//定义每个UICollectionView 大小
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
        return CGSizeMake((kWidth-8)/3.0, (kWidth-8)/3.0);
    
}

//定义每个UICollectionView的间距（相对的横向与纵向）
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}

-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    
    return 4.0;
}


-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    if ([self.loopFlag isEqualToString:kReplaceOnePic]) {
        if (indexPath.row==0) {
            
            [self pickImageByType:UIImagePickerControllerSourceTypeCamera];
        }else{
            [self.selPhotoArrM addObject:self.photoArrURL[indexPath.row]];
            [self imageWithUrl:[self.selPhotoArrM[0] objectForKey:kImgUrl] withFileName:[self.selPhotoArrM[0] objectForKey:kImgName]];
        }
        
    }else{
        
        if (indexPath.row==0) {
            
            [self pickImageByType:UIImagePickerControllerSourceTypeCamera];
            
        }else{
            
            NSMutableDictionary *tempDic = [NSMutableDictionary dictionaryWithDictionary:self.photoArrURL[indexPath.row]];
            if ([[tempDic objectForKey:kSelPhoto] boolValue]) {
                [self.selPhotoArrM removeObject:tempDic];
                [self.thumbArrM removeObject:[self.photoArrURL[indexPath.row] objectForKey:kThumbnail]];
                [tempDic setObject:@NO forKey:kSelPhoto];
                
            }else{
                [tempDic setObject:@YES forKey:kSelPhoto];
                [self.selPhotoArrM addObject:tempDic];
                [self.thumbArrM addObject:[self.photoArrURL[indexPath.row] objectForKey:kThumbnail]];
            }
            
            [self.photoArrURL replaceObjectAtIndex:indexPath.row withObject:tempDic];
            
            [self.collectionView reloadData];
            
        }

    }
}



#pragma mark -- obtainAlbum


-(void)getPhotoPath
{
    
    //获取所有group
    
    __block ObtainPictureViewController *photoVC = self;
    dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_DEFAULT,0), ^{
        
        [_assetsLibrary enumerateGroupsWithTypes:ALAssetsGroupAll usingBlock:^(ALAssetsGroup *group, BOOL *stop) {
            
            ALAssetsFilter *onlyPhotoFilter = [ALAssetsFilter allPhotos];
            
            [group setAssetsFilter:onlyPhotoFilter];
            photoVC.phohtoNum = [group numberOfAssets];
            
            
            if (group != nil) {
                [photoVC.photoArrM addObject:group];
                if ([[group valueForProperty:ALAssetsGroupPropertyName] isEqualToString:@"Camera Roll"]) {
                    
                    dispatch_async(dispatch_get_main_queue(), ^{
                        //do what you want
                        
                    });
                    
                    
                }
                
            }else{
                
                
                [photoVC.photoArrM enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
                    
                    
                    if ([[(ALAssetsGroup *)obj valueForProperty:ALAssetsGroupPropertyName] isEqualToString:@"Camera Roll"]) {//My Photo Stream
                        
                        
                        [obj enumerateAssetsUsingBlock:^(ALAsset *result, NSUInteger index, BOOL *stop) {
                            
                            
                            
                            if ([[result valueForProperty:ALAssetPropertyType] isEqualToString:ALAssetTypePhoto]) {
                                
                                if ([result thumbnail]) {
                                    
                                    
                                    
                                    UIImage *img = [UIImage imageWithCGImage:[result thumbnail]];
                                    
                                    NSString *fileName = [[result defaultRepresentation] filename];
                                    NSURL *url = [[result defaultRepresentation] url];

                                    // int64_t fileSize = [[result defaultRepresentation] size];
                                    NSDictionary *dic = @{kImgUrl:url,kThumbnail:img,kImgName:fileName,kSelPhoto:@NO};
                                    
//                                    [self.photoArrURL addObject:dic];
                                    [self.photoArrURL insertObject:dic atIndex:1];
                                  
                                    
                                    
                                    
                                }
                                
                            }



                        }];
                        

                        
                        
                    }
                    

                    
                }];

                

                
            }
            

            dispatch_async(dispatch_get_main_queue(), ^{
                
                
                [self.collectionView reloadData];
                
            });

            
            
            
        } failureBlock:^(NSError *error) {
            
            NSLog(@"error:%@",error);
            NSString *errorMessage = @"";
            
            switch ([error code]) {
                case ALAssetsLibraryAccessUserDeniedError:
                case ALAssetsLibraryAccessGloballyDeniedError:

                    errorMessage = @"用户拒绝访问相册，请在<设置>中开启";
                    break;
                    
                default:
                    break;
            }
            
            
            dispatch_async(dispatch_get_main_queue(), ^{
                UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"错误,无法访问!"
                                                                   message:errorMessage
                                                                  delegate:self
                                                         cancelButtonTitle:@"确定"
                                                         otherButtonTitles:nil, nil];
                [alertView show];
            });
            
        }];
        
    });
   


    
    
}

#pragma mark -- 相册的大图需要转存

// 将原始图片的URL转化为NSData数据,写入沙盒
- (void)imageWithUrl:(NSURL *)url withFileName:(NSString *)fileName
{
    
    // 通过是否存在文件路径，判断是否需要转化
    ALAssetsLibrary *assetLibrary = [[ALAssetsLibrary alloc] init];
    // 创建存放原始图的文件夹--->OriginalPhotoImages
    _fileManager = [NSFileManager defaultManager];
    if (![_fileManager fileExistsAtPath:KOriginalPhotoImagePath]) {
        [_fileManager createDirectoryAtPath:KOriginalPhotoImagePath withIntermediateDirectories:YES attributes:nil error:nil];
        
    }
    
    
    
        if (url) {
            
            [assetLibrary assetForURL:url resultBlock:^(ALAsset *asset) {

                
                ALAssetRepresentation *rep = [asset defaultRepresentation];

                UIImage *img = [UIImage imageWithCGImage:rep.fullScreenImage scale:rep.scale orientation:UIImageOrientationUp];
                NSData *data = UIImageJPEGRepresentation(img, 1.0);
                
                NSString * imagePath = [KOriginalPhotoImagePath stringByAppendingPathComponent:fileName];
                    
                [data writeToFile:imagePath atomically:YES];
                
 
                if ([url isEqual:[[self.selPhotoArrM lastObject]objectForKey:kImgUrl]]) {//判断以保证最后一张存储完毕
                    
                
                    //用于跳转
                    dispatch_async(dispatch_get_main_queue(), ^{
                        
                        if ([self.loopFlag isEqualToString:kAddPhotos] || [self.loopFlag isEqualToString:kReplaceOnePic]) {
                            
                            if (self.selectPhotoBlock) {
                                self.selectPhotoBlock(self.selPhotoArrM);
                            }
                            
                            
                            [self.navigationController popViewControllerAnimated:YES];
                            
                        }else{
                            
                            
                            
                            CreatStyleFrameController *creatStyle = [[CreatStyleFrameController alloc]init];
                            creatStyle.originalPhotoArr = self.selPhotoArrM;
                            creatStyle.topicIdFromCreat = self.creatTopicId;
                            
                            [self.navigationController pushViewController:creatStyle animated:YES];
                            
                            
                            
                            
                        }

                       
                        
                    });

                }
                    

            } failureBlock:^(NSError *error) {
                NSLog(@"error:%@",error);
            }
  
            ];
        }

    
}
//take photo btn click
-(void)takeCamera
{
    [self pickImageByType:UIImagePickerControllerSourceTypeCamera];
}


#pragma mark -- 拍照

#pragma mark -- 拍照上传或者从照片库获取图片

-(void)pickImageByType:(UIImagePickerControllerSourceType)sourceType
{
    _picker = [[UIImagePickerController alloc]init];
    _picker.delegate =self;
    _picker.allowsEditing =YES;
    
    
    if (sourceType == UIImagePickerControllerSourceTypeCamera) {
        
        if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
            
            UIAlertView *alerView = [[UIAlertView alloc]initWithTitle:@"无法拍照" message:@"此设备拍照功能不可用" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
            [alerView show];
            
        }else{
            _picker.sourceType =sourceType;
            
            //ios8必须加这句代码，否则报错
            if ([[[UIDevice currentDevice] systemVersion] floatValue]>=8.0){
               self.modalPresentationStyle = UIModalPresentationCurrentContext;
            }
           
            [self presentViewController:_picker animated:YES completion:nil];
        }
        
    }
}

#pragma mark --  picker delegate


-(void)imagePickerController:(UIImagePickerController*)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    [picker dismissViewControllerAnimated:YES completion:^(){
        UIImage* image = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
        
        UIImageWriteToSavedPhotosAlbum(image, self, nil, nil);
        
        [self.photoArrURL removeAllObjects];
        [_photoArrURL addObject: @{kImgUrl:@"",kThumbnail:[UIImage imageNamed:@"xiangji"],kImgName:@""}];
    dispatch_async(dispatch_get_main_queue(), ^{
        
        [self getPhotoPath];
    });
        
        
//        [self.collectionView reloadData];

    }];
    
    
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    NSLog(@"您取消了选择图片");
    [picker dismissViewControllerAnimated:YES completion:nil];
    
}

-(void)viewWillDisappear:(BOOL)animated
{
    self.navigationController.navigationBarHidden = NO;
    UIButton *btn = (UIButton*)[self.navigationController.navigationBar viewWithTag:1002];
    btn.userInteractionEnabled = YES;

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
