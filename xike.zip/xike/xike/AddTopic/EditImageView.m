//
//  EditImageView.m
//  PhotoEdit
//
//  Created by shaker on 15/5/19.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "EditImageView.h"
#import "UIImage+Edit.h"
#import <QuartzCore/QuartzCore.h>
#import "common.h"
#import "UIImage+Common.h"

@interface EditImageView()
@property(assign, nonatomic) CGSize originalImageViewSize;
@property(nonatomic, strong) UIView *line1;
@property(nonatomic, strong) UIView *line2;
@property(nonatomic, strong) UIView *line3;
@property(nonatomic, strong) UIView *line4;
@property(nonatomic, strong) NSMutableArray *gesM;

@end



@implementation EditImageView

//@synthesize imageView;


-(id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.frame = frame;
        
        [self setup];
    }
    
    return self;
}

//创建展示试图
-(void)setup
{
    self.clipsToBounds = YES;
    self.backgroundColor = [UIColor whiteColor];
    
    self.imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0, 0.0, self.frame.size.width, self.frame.size.height)];
    self.imageView.backgroundColor = [UIColor lightGrayColor];
    self.imageView.userInteractionEnabled = YES;
    UIPinchGestureRecognizer  *pinchGesture = [[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(beginEditPhote:)];
    [self.imageView addGestureRecognizer:pinchGesture];

    [self addSubview:self.imageView];
    _gesM = [NSMutableArray array];
    

    
   
}


-(void)beginEditPhote:(UIPinchGestureRecognizer*)gesture
{
    
    if (gesture.state == UIGestureRecognizerStateBegan) {
        
        if (self.delegate) {
            [_delegate editPhoto];
        }
        
        
        _line1 = [[UIView alloc]initWithFrame:CGRectMake(CGRectGetWidth(self.frame)/3.0,0,1,CGRectGetHeight(self.frame))];
        _line1.backgroundColor = [UIColor lightGrayColor];
        [self addSubview:self.line1];
        
        _line2 = [[UIView alloc]initWithFrame:CGRectMake(CGRectGetWidth(self.frame)*2/3.0,0,1,CGRectGetHeight(self.frame))];
        _line2.backgroundColor = [UIColor lightGrayColor];
        [self addSubview:self.line2];
        
        _line3 = [[UIView alloc]initWithFrame:CGRectMake(0,CGRectGetHeight(self.frame)/3.0, CGRectGetWidth(self.frame),1)];
        _line3.backgroundColor = [UIColor lightGrayColor];
        [self addSubview:self.line3];
        
        _line4 = [[UIView alloc]initWithFrame:CGRectMake(0,CGRectGetHeight(self.frame)*2/3.0, CGRectGetWidth(self.frame),1)];
        _line4.backgroundColor = [UIColor lightGrayColor];
        [self addSubview:self.line4];

        
        UIRotationGestureRecognizer *rotateGes = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(rotateImage:)];
        [self.imageView addGestureRecognizer:rotateGes];
        
        UIPinchGestureRecognizer *scaleGes = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(scaleImage:)];
        [self.imageView addGestureRecognizer:scaleGes];
        
        
        UIPanGestureRecognizer *moveGes = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(moveImage:)];
        [moveGes setMinimumNumberOfTouches:1];
        [moveGes setMaximumNumberOfTouches:1];
        [self.imageView addGestureRecognizer:moveGes];
        [self.gesM addObject:rotateGes];
        [self.gesM addObject:scaleGes];
        [self.gesM addObject:moveGes];

    }

    
}

#pragma mark--- 各种手势的动作

//平移
float _lastTransX = 0.0, _lastTransY = 0.0;
- (void)moveImage:(UIPanGestureRecognizer *)sender
{
    CGPoint translatedPoint = [sender translationInView:self];
    
    if([sender state] == UIGestureRecognizerStateBegan) {
        _lastTransX = 0.0;
        _lastTransY = 0.0;
    }
    
    CGAffineTransform trans = CGAffineTransformMakeTranslation(translatedPoint.x - _lastTransX, translatedPoint.y - _lastTransY);
    CGAffineTransform newTransform = CGAffineTransformConcat(self.imageView.transform, trans);
    _lastTransX = translatedPoint.x;
    _lastTransY = translatedPoint.y;
    
    self.imageView.transform = newTransform;
}

//缩放

float _lastScale = 1.0;
- (void)scaleImage:(UIPinchGestureRecognizer *)sender
{
    if([sender state] == UIGestureRecognizerStateBegan) {
        
        _lastScale = 1.0;
        return;
    }
    
    CGFloat scale = [sender scale]/_lastScale;
    
    CGAffineTransform currentTransform = self.imageView.transform;
    CGAffineTransform newTransform = CGAffineTransformScale(currentTransform, scale, scale);
    [self.imageView setTransform:newTransform];
    
    _lastScale = [sender scale];
}

//旋转
float _lastRotation = 0.0;
- (void)rotateImage:(UIRotationGestureRecognizer *)sender
{
    if([sender state] == UIGestureRecognizerStateEnded) {
        
        _lastRotation = 0.0;
        return;
    }
    
    CGFloat rotation = -_lastRotation + [sender rotation];
    
    CGAffineTransform currentTransform = self.imageView.transform;
    CGAffineTransform newTransform = CGAffineTransformRotate(currentTransform,rotation);
    [self.imageView setTransform:newTransform];
    
    _lastRotation = [sender rotation];
    
}

- (void)setImage:(UIImage *)image
{
    if (_image != image) {
        _image = image;
    }
    
    float _imageScale = self.frame.size.width / image.size.width;
    self.imageView.frame = CGRectMake(0, 0, image.size.width*_imageScale, image.size.height*_imageScale);
    _originalImageViewSize = CGSizeMake(image.size.width*_imageScale, image.size.height*_imageScale);
    self.imageView.image = image;
    self.imageView.center = CGPointMake(self.frame.size.width/2.0, self.frame.size.height/2.0);
}



//编辑完的处理

-(UIImage*)finishEditing
{
    [self.line1 removeFromSuperview];
    [self.line2 removeFromSuperview];
    [self.line3 removeFromSuperview];
    [self.line4 removeFromSuperview];
    
    float zoomScale = [[self.imageView.layer valueForKeyPath:@"transform.scale.x"] floatValue];
    float rotate = [[self.imageView.layer valueForKeyPath:@"transform.rotation.z"] floatValue];
    
    float _imageScale = self.image.size.width/_originalImageViewSize.width;
    CGSize cropSize = CGSizeMake(self.frame.size.width/zoomScale, self.frame.size.height/zoomScale);
    CGPoint cropperViewOrigin = CGPointMake((0.0 - self.imageView.frame.origin.x)/zoomScale,
                                            (0.0 - self.imageView.frame.origin.y)/zoomScale);
    
    if((NSInteger)cropSize.width % 2 == 1)
    {
        cropSize.width = ceil(cropSize.width);
    }
    if((NSInteger)cropSize.height % 2 == 1)
    {
        cropSize.height = ceil(cropSize.height);
    }
    
    CGRect CropRectinImage = CGRectMake((NSInteger)(cropperViewOrigin.x*_imageScale) ,(NSInteger)( cropperViewOrigin.y*_imageScale), (NSInteger)(cropSize.width*_imageScale),(NSInteger)(cropSize.height*_imageScale));
    
    UIImage *rotInputImage = [self.image imageRotatedByRadians:rotate];
    CGImageRef tmp = CGImageCreateWithImageInRect([rotInputImage CGImage], CropRectinImage);
    self.editImage = [UIImage imageWithCGImage:tmp scale:self.image.scale orientation:self.image.imageOrientation];
    CGImageRelease(tmp);
    return self.editImage;
}

//照片复原
- (void)reset
{
    self.imageView.transform = CGAffineTransformIdentity;
}
-(void)endEditPhoto
{
    [self.line1 removeFromSuperview];
    [self.line2 removeFromSuperview];
    [self.line3 removeFromSuperview];
    [self.line4 removeFromSuperview];
    
    for (UIGestureRecognizer *gesture in self.gesM) {
      
        [self.imageView removeGestureRecognizer:gesture];
    }
}


@end
