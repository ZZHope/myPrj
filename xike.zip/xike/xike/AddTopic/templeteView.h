//
//  templeteView.h
//  xike
//
//  Created by shaker on 15/6/30.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EditImageView.h"

@protocol templeteViewDelegate <NSObject>

@optional
-(void)tapToChangePhoto:(UITapGestureRecognizer*)gesture;
-(void)tapToAddNewPages:(UITapGestureRecognizer*)gesture; //add new photo ,loop to albulm view
-(void)pressToAddWords; //add new words, loop to edit view
-(void)beginEditPhoto:(UIPinchGestureRecognizer*)gesture;

@end

@interface templeteView : UIView<templeteViewDelegate,EditImageViewDelegate>
@property(nonatomic,assign) id <templeteViewDelegate> myDelegate;
@property(nonatomic,strong) EditImageView *imgView;
@property(nonatomic, strong) UITextView *titleView;
@property(nonatomic, strong) UITextView *contentView;

-( void)buildStyle1WithImage:(UIImage*)img textColer:(UIColor*)textColor  title:(NSString*)title content:(NSString*)content vc:(id)vc fontRate:(float)rate;
-(void)buildStyle2WithImage:(UIImage*)img textColer:(UIColor*)textColor  title:(NSString*)title content:(NSString*)content vc:(id)vc fontRate:(float)rate;
-(void)buildStyle3WithImage:(UIImage*)img textColer:(UIColor*)textColor  title:(NSString*)title content:(NSString*)content vc:(id)vc fontRate:(float)rate;
-(void)buildStyle4WithImage:(UIImage*)img textColer:(UIColor*)textColor  title:(NSString*)title content:(NSString*)content vc:(id)vc fontRate:(float)rate;
-(void)buildStyle5WithTextColer:(UIColor*)textColor  title:(NSString*)title content:(NSString*)content fontRate:(float)rate vc:(id)vc;
-(void)buildStyle6WithTextColer:(UIColor*)textColor  title:(NSString*)title content:(NSString*)content fontRate:(float)rate vc:(id)vc;
-(void)buildStyle7WithTextColer:(UIColor*)textColor  title:(NSString*)title content:(NSString*)content fontRate:(float)rate vc:(id)vc;
-(void)buildStyle8WithImage:(UIImage*)img vc:(id)vc;

-(void)addNewPagesWithVC:(id)vc;

//url
-(void)buildStyle1WithImageWithUrl:(NSString*)imgUrl textColer:(UIColor*)textColor  title:(NSString*)title content:(NSString*)content vc:(id)vc fontRate:(float)rate;
-(void)buildStyle2WithImageWithUrl:(NSString*)imgUrl textColer:(UIColor*)textColor  title:(NSString*)title content:(NSString*)content vc:(id)vc fontRate:(float)rate;
-(void)buildStyle3WithImageWithUrl:(NSString*)imgUrl textColer:(UIColor*)textColor  title:(NSString*)title content:(NSString*)content vc:(id)vc fontRate:(float)rate;
-(void)buildStyle4WithImageWithUrl:(NSString*)imgUrl textColer:(UIColor*)textColor  title:(NSString*)title content:(NSString*)content vc:(id)vc fontRate:(float)rate;
-(void)buildStyle8WithImageWithUrl:(NSString*)imgUrl vc:(id)vc;




@end
