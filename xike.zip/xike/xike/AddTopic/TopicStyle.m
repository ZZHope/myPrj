//
//  TopicStyle.m
//  xike
//
//  Created by shaker on 15/6/30.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "TopicStyle.h"
#import "common.h"

@implementation TopicStyle
-(id)init{
    
    if (self = [super init]) {
        
        self.fontName = kHeitiSC;
        self.titleFontSize = 24.0f;
        self.contentFontSize = 13.0f;
        self.titleWordMargin = 2.0f;
        self.titleLineMargin = 35.0f;
        self.contentWordMargin = 1.0f;
        self.contentLineMargin = 13.0f;
        self.defaultImgName = @"";
        self.title = @"";
        self.content = @"";
        self.serialNumber = 0;
        self.temepleteNumber = 0;
    }
    
    return self;
}

@end
