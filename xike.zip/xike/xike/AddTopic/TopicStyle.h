//
//  TopicStyle.h
//  xike
//
//  Created by shaker on 15/6/30.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface TopicStyle : NSObject
@property(nonatomic, copy)   NSString *fontName;
@property(nonatomic, copy)   NSString *title;
@property(nonatomic, copy)   NSString *content;
@property(nonatomic, assign) float titleFontSize;
@property(nonatomic, assign) float contentFontSize;
@property(nonatomic, assign) float titleWordMargin;
@property(nonatomic, assign) float titleLineMargin;
@property(nonatomic, assign) float contentWordMargin;
@property(nonatomic, assign) float contentLineMargin;
@property(nonatomic, copy)   NSString *defaultImgName;
@property(nonatomic, assign) int *serialNumber;//版式的第几张
@property(nonatomic, assign) int *temepleteNumber; //版式的序号

@end
