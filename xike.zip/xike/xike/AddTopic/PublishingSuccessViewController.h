//
//  PublishingSuccessViewController.h
//  xike
//
//  Created by MarilynEric on 15/8/14.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "common.h"
@interface PublishingSuccessViewController : UIViewController
@property(nonatomic,copy)NSString *creatArticleId;
@property(nonatomic,copy)NSString *creatTopicId;

@end
