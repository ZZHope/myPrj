//
//  PublishingSuccessViewController.m
//  xike
//
//  Created by MarilynEric on 15/8/14.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "PublishingSuccessViewController.h"
#import "ShareEngine.h"
#import "contentViewController.h"
#import "TopicDetailController.h"
#import "userTopicViewController.h"
@interface PublishingSuccessViewController ()

@end

@implementation PublishingSuccessViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self buildNav];
    [self buildUI];
    self.view.backgroundColor = [UIColor whiteColor];
}

-(void)buildNav
{
    UIImage *backImg=[UIImage imageNamed:@"fanhui"];
    UIButton *backImgViewBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    //    backImgView.backgroundColor=[UIColor redColor];
    backImgViewBtn.frame=CGRectMake(0, 0, backImg.size.width, backImg.size.height);
    [backImgViewBtn setImage:backImg forState:UIControlStateNormal];
    [backImgViewBtn addTarget:self action:@selector(leftBackBtnClickP) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftItemCuston=[[UIBarButtonItem alloc]initWithCustomView:backImgViewBtn];
    self.navigationItem.leftBarButtonItem=leftItemCuston;
    
    UIImage *shareImage=[UIImage imageNamed:@"fenxiang1"];
    UIButton *shareImgViewBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    shareImgViewBtn.frame=CGRectMake(0, 0, shareImage.size.width, shareImage.size.height);
    [shareImgViewBtn setImage:shareImage forState:UIControlStateNormal];
    [shareImgViewBtn addTarget:self action:@selector(rightShareBtnClickP) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *rightItemCuston=[[UIBarButtonItem alloc]initWithCustomView:shareImgViewBtn];
    self.navigationItem.rightBarButtonItem=rightItemCuston;
}

//nav右面分享按钮响应
-(void)rightShareBtnClickP
{
    [self wechatSessionShare];
}
#pragma mark Share Button Actions
- (void)wechatSessionShare {
    NSString *theme = [@"testWechat" stringByAppendingString:@":"];
    // UIImage *image = [UIImage imageWithOriginImage:[UIImage imageNamed:@"3"] scaledToSize:CGSizeMake(220, 148)];
    //UIImage *image = [UIImage imageNamed:@"layout1_79122"];
    NSString *content = @"testtest";
    NSString *URLString = [[NSString alloc] initWithFormat:@"%@",@"http://v1.qzone.cc/pic/201507/02/21/05/559536ff424f2614.jpg!600x600.jpg"];
    [[ShareEngine sharedInstance] sendLinkContent:WXSceneSession :theme :content :[UIImage imageNamed:@"3"] :[NSURL URLWithString:URLString]];
    
}
//#pragma mark Share Button Actions
//- (void)wechatSessionShare {
//    NSString *theme = [@"testWechat" stringByAppendingString:@":"];
//    
//    NSString *content = @"testtest";
//    NSString *URLString = [[NSString alloc] initWithFormat:@"%@",[self.headerDicM objectForKey:@"logo"]];
//    [[ShareEngine sharedInstance] sendLinkContent:WXSceneSession :theme :content :[UIImage imageNamed:@"3"] :[NSURL URLWithString:URLString]];
//}

-(void)leftBackBtnClickP
{
    [self.navigationController popToRootViewControllerAnimated:YES];
}

-(void)buildUI
{
    
    UIImageView *topicImageView=[[UIImageView alloc]initWithFrame:CGRectMake(kWidth*0.35, kHeight*0.07, kWidth*0.3, kWidth*0.3)];
    topicImageView.backgroundColor=kColor(216, 216, 216);
    
    
    UIImage *topicImage=[UIImage imageNamed:@""];
    [topicImageView setImage:topicImage];
    [self.view addSubview:topicImageView];
    
    UILabel *partakeLabel=[[UILabel alloc]initWithFrame:CGRectMake(kWidth*0.25, topicImageView.frame.origin.y+topicImageView.frame.size.height+5, kWidth*0.5, 30)];
    partakeLabel.backgroundColor=[UIColor clearColor];
    partakeLabel.text=@"25人参与/20人关注";
    partakeLabel.font=[UIFont systemFontOfSize:9.0f];
    partakeLabel.textAlignment=NSTextAlignmentCenter;
    //[partakeLabel sizeToFit];
    [self.view addSubview:partakeLabel];
    
    UILabel *titleLabel=[[UILabel alloc]initWithFrame:CGRectMake(kWidth*0.05, partakeLabel.frame.origin.y+partakeLabel.frame.size.height+10, kWidth*0.9, 50)];
    titleLabel.backgroundColor=[UIColor clearColor];
    titleLabel.text=@"送我一支迷幻药帮我意淫与现实无关的事物离开现实表面";
    titleLabel.numberOfLines=2;
    titleLabel.textAlignment=NSTextAlignmentCenter;
    [self.view addSubview:titleLabel];
    
    UILabel *publishingSuccess=[[UILabel alloc]initWithFrame:CGRectMake(kWidth*0.3, kHeight*0.5, kWidth*0.4, 20)];
    publishingSuccess.text=@"发布成功！";
    publishingSuccess.textAlignment=NSTextAlignmentCenter;
    publishingSuccess.textColor=kColor(167, 167, 167);
    [self.view addSubview:publishingSuccess];
    
    UIButton *checkButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    checkButton.frame=CGRectMake(kWidth*0.2, kHeight*0.6, kWidth*0.6, kHeight*0.05);
    checkButton.backgroundColor=[UIColor orangeColor];
    [checkButton setTitle:@"查看" forState:UIControlStateNormal];
    [checkButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    checkButton.backgroundColor=kColor(0, 216, 165);
    checkButton.layer.cornerRadius=3.0f;
    [checkButton addTarget:self action:@selector(checkTopic) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:checkButton];
    
    
    UIButton *backTopicButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    backTopicButton.frame=CGRectMake(kWidth*0.2, kHeight*0.7, kWidth*0.6, kHeight*0.05);
    backTopicButton.backgroundColor=[UIColor orangeColor];
    [backTopicButton setTitle:@"回到话题" forState:UIControlStateNormal];
    [backTopicButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    backTopicButton.backgroundColor=kColor(0, 216, 165);
    backTopicButton.layer.cornerRadius=3.0f;
    [backTopicButton addTarget:self action:@selector(backTopic) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:backTopicButton];
}
// 点击 “查看” 去作品详情页
-(void)checkTopic
{
    contentViewController *contentVc = [[contentViewController alloc]init];
    contentVc.articleId = self.creatArticleId;
    [self.navigationController pushViewController:contentVc animated:YES];
}
// 点击 “回到话题”去？？
-(void)backTopic
{
    userTopicViewController *userTopic = [[userTopicViewController alloc]init];
    userTopic.listTopicId = self.creatTopicId;
    [self.navigationController pushViewController:userTopic animated:YES];
}


- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
