//
//  templeteView.m
//  xike
//
//  Created by shaker on 15/6/30.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "templeteView.h"
#import "common.h"
#import <CoreText/CoreText.h>
#import "UserSingleton.h"
#import "UIImageView+WebCache.h"

#define viewWidth   self.bounds.size.width
#define viewHeight  self.bounds.size.height
@implementation templeteView

-(id)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor whiteColor];
        self.clipsToBounds = YES;

    }
    
    return self;
}



//style1图文版
-(void)buildStyle1WithImage:(UIImage*)img textColer:(UIColor*)textColor  title:(NSString*)title content:(NSString*)content vc:(id)vc fontRate:(float)rate
{
    _imgView = [[EditImageView alloc]initWithFrame:CGRectMake(0, 0, viewWidth, 360*viewHeight/667)];
    _imgView.image =img;
    _imgView.clipsToBounds = YES;
    _imgView.backgroundColor =[UIColor whiteColor];
    _imgView.userInteractionEnabled = YES;
    UITapGestureRecognizer *changeTap = [[UITapGestureRecognizer alloc]initWithTarget:vc action:@selector(tapToChangePhoto:)];
    [_imgView addGestureRecognizer:changeTap];

    [self addSubview:_imgView];
    
    _titleView = [[UITextView alloc]initWithFrame:CGRectMake(30*rate, CGRectGetMaxY(_imgView.frame)+30*rate, viewWidth-60, 90*rate)];
    _titleView.text = title;
    _titleView.showsVerticalScrollIndicator = NO;
    _titleView.font = [UIFont fontWithName:[UserSingleton shareUserSingleton].fontName size:24.0f*rate];
    NSAttributedString *titleAttr = [self attributeStringWithText:_titleView.text lineMargin:17.0f*rate wordMargin:2.0f fontSize:24.0f*rate];
    _titleView.attributedText = titleAttr;
    _titleView.textColor = textColor;
   // _titleView.numberOfLines = 2;
    _titleView.scrollsToTop = YES;
    _titleView.delegate = vc;
    _titleView.userInteractionEnabled = YES;
    [self addSubview:_titleView];
    
    _contentView = [[UITextView alloc]initWithFrame:CGRectMake(30*rate, CGRectGetMaxY(_titleView.frame)+10*rate, viewWidth-60, 6*13*rate)];
    _contentView.text = content;
    _contentView.font = [UIFont fontWithName:[UserSingleton shareUserSingleton].fontName size:13.0f*rate];
    _contentView.textColor = textColor;
    _contentView.scrollsToTop = YES;
    _contentView.showsVerticalScrollIndicator = NO;
    NSAttributedString *contentAttr = [self attributeStringWithText:_contentView.text lineMargin:13.0f*rate wordMargin:1.0f fontSize:13.0f*rate];
    _contentView.attributedText = contentAttr;
    //_contentView.numberOfLines = 3;
    _contentView.delegate = vc;


    [self addSubview:_contentView];
    
    

}


-(void)buildStyle2WithImage:(UIImage*)img textColer:(UIColor*)textColor  title:(NSString*)title content:(NSString*)content vc:(id)vc fontRate:(float)rate
{
    _imgView = [[EditImageView alloc]initWithFrame:CGRectMake(0, 0, viewWidth, 200*viewHeight/667)];
    _imgView.image =img;
    _imgView.clipsToBounds = YES;
    _imgView.userInteractionEnabled = YES;
//    _imgView.backgroundColor = [UIColor whiteColor];
    UITapGestureRecognizer *changeTap = [[UITapGestureRecognizer alloc]initWithTarget:vc action:@selector(tapToChangePhoto:)];
    [_imgView addGestureRecognizer:changeTap];
    _imgView.delegate = vc;

    [self addSubview:_imgView];
    _titleView = [[UITextView alloc]initWithFrame:CGRectMake(30*rate, CGRectGetMaxY(_imgView.frame)+50*rate, viewWidth-60, 90*rate)];
    _titleView.text = title;
    _titleView.showsVerticalScrollIndicator = NO;
    _titleView.font = [UIFont fontWithName:[UserSingleton shareUserSingleton].fontName size:24.0f*rate];
    NSAttributedString *titleAttr = [self attributeStringWithText:_titleView.text lineMargin:17.0f*rate wordMargin:2.0f fontSize:24.0f*rate];
    _titleView.attributedText = titleAttr;
    _titleView.textColor = textColor;
    _titleView.delegate = vc;
//    _titleView.numberOfLines = 2;
    [self addSubview:_titleView];
    
    _contentView = [[UITextView alloc]initWithFrame:CGRectMake(30*rate, CGRectGetMaxY(_titleView.frame)+10*rate, viewWidth-60, 14*13*rate)];
    _contentView.text = content;
    _contentView.font = [UIFont fontWithName:[UserSingleton shareUserSingleton].fontName size:13.0f*rate];
    _contentView.textColor = textColor;
    _contentView.showsVerticalScrollIndicator = NO;
    NSAttributedString *contentAttr = [self attributeStringWithText:_contentView.text lineMargin:13.0f*rate wordMargin:1.0f fontSize:13.0f*rate];
    _contentView.attributedText = contentAttr;
    _contentView.delegate = vc;
//    _contentView.numberOfLines = 7;
    [self addSubview:_contentView];
}

-(void)buildStyle3WithImage:(UIImage*)img textColer:(UIColor*)textColor  title:(NSString*)title content:(NSString*)content vc:(id)vc fontRate:(float)rate
{
    _imgView = [[EditImageView alloc]initWithFrame:CGRectMake(25.5*rate, 25.5*rate, viewWidth-50*rate, viewWidth-50*rate)];
    
    _imgView.image =img;
    _imgView.clipsToBounds = YES;
//    _imgView.backgroundColor = [UIColor whiteColor];
    _imgView.userInteractionEnabled = YES;
    UITapGestureRecognizer *changeTap = [[UITapGestureRecognizer alloc]initWithTarget:vc action:@selector(tapToChangePhoto:)];
    [_imgView addGestureRecognizer:changeTap];
    _imgView.delegate = vc;

    [self addSubview:_imgView];
    _titleView = [[UITextView alloc]initWithFrame:CGRectMake(25.5*rate, CGRectGetMaxY(_imgView.frame)+30*rate, viewWidth-50*rate, 90*rate)];
    _titleView.text = title;
    _titleView.showsVerticalScrollIndicator = NO;
    _titleView.font = [UIFont fontWithName:[UserSingleton shareUserSingleton].fontName size:24.0f*rate];
    NSAttributedString *titleAttr = [self attributeStringWithText:_titleView.text lineMargin:17.0f*rate wordMargin:2.0f fontSize:24.0*rate];
    _titleView.attributedText = titleAttr;
    _titleView.textColor = textColor;
    [self addSubview:_titleView];
    
    _contentView = [[UITextView alloc]initWithFrame:CGRectMake(30*rate, CGRectGetMaxY(_titleView.frame)+10*rate, viewWidth-60, 13*6*rate)];
    _contentView.text = content;
    _contentView.font = [UIFont fontWithName:[UserSingleton shareUserSingleton].fontName size:13.0f*rate];
    _contentView.textColor = textColor;
    _contentView.showsVerticalScrollIndicator = NO;
    NSAttributedString *contentAttr = [self attributeStringWithText:_contentView.text lineMargin:13.0f*rate wordMargin:1.0f fontSize:13.0f*rate];
    _contentView.attributedText = contentAttr;
    
    [self addSubview:_contentView];
    


}

-(void)buildStyle4WithImage:(UIImage*)img textColer:(UIColor*)textColor  title:(NSString*)title content:(NSString*)content vc:(id)vc fontRate:(float)rate
{
    _imgView = [[EditImageView alloc]initWithFrame:CGRectMake(0, 0, viewWidth,viewHeight)];
    
    _imgView.image =img;
    _imgView.clipsToBounds = YES;
    _imgView.userInteractionEnabled = YES;
    UITapGestureRecognizer *changeTap = [[UITapGestureRecognizer alloc]initWithTarget:vc action:@selector(tapToChangePhoto:)];
    [_imgView addGestureRecognizer:changeTap];
    _imgView.delegate = vc;
//    UIView *maskView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, CGRectGetWidth(_imgView.frame), CGRectGetHeight(_imgView.frame))];
//    maskView.backgroundColor = [UIColor blackColor];
//    maskView.alpha = 0.6f;
//    [_imgView addSubview:maskView];
    [self addSubview:_imgView];
    _titleView = [[UITextView alloc]initWithFrame:CGRectMake(30*rate, 50*rate, viewWidth-60*rate, 90*rate)];
    _titleView.text = title;
    _titleView.backgroundColor = [UIColor clearColor];
    _titleView.showsVerticalScrollIndicator = NO;
    _titleView.font = [UIFont fontWithName:[UserSingleton shareUserSingleton].fontName size:24.0f*rate];
    NSAttributedString *titleAttr = [self attributeStringWithText:_titleView.text lineMargin:17.0f*rate wordMargin:2.0f fontSize:24.0f*rate];
    _titleView.attributedText = titleAttr;
    _titleView.textColor = textColor;
    _titleView.delegate = vc;
    [self addSubview:_titleView];
    
    
    _contentView = [[UITextView alloc]initWithFrame:CGRectMake(30*rate, CGRectGetMaxY(_titleView.frame)+40*rate, viewWidth-60, 26*13*rate)];
    _contentView.text = content;
    _contentView.showsVerticalScrollIndicator = NO;
    _contentView.backgroundColor = [UIColor clearColor];
    _contentView.font = [UIFont fontWithName:[UserSingleton shareUserSingleton].fontName size:13.0f*rate];
   
    NSAttributedString *contentAttr = [self attributeStringWithText:_contentView.text lineMargin:13.0f*rate wordMargin:1.0f fontSize:13.0f*rate];
    _contentView.attributedText = contentAttr;
     _contentView.textColor = textColor;
    _contentView.delegate = vc;
    
    [self addSubview:_contentView];
    

}

-(void)buildStyle5WithTextColer:(UIColor*)textColor title:(NSString*)title content:(NSString*)content fontRate:(float)rate vc:(id)vc
{
    
    UIView *line1 = [[UIView alloc]initWithFrame:CGRectMake(0, 40*rate, viewWidth, 3)];
    line1.backgroundColor = textColor;
    [self addSubview:line1];
    
    _titleView = [[UITextView alloc]initWithFrame:CGRectMake(30*rate, CGRectGetMaxY(line1.frame)+40*rate, viewWidth-60*rate, 90*rate)];
    _titleView.text = title;
    _titleView.showsVerticalScrollIndicator = NO;
    _titleView.font = [UIFont fontWithName:kHeitiSC size:24.0f*rate];
    NSAttributedString *titleAttr = [self attributeStringWithText:_titleView.text lineMargin:17.0f*rate wordMargin:2.0f fontSize:24.0f*rate];
    _titleView.attributedText = titleAttr;
    _titleView.textColor = textColor;
    _titleView.delegate = vc;
    [self addSubview:_titleView];
    
    
    _contentView = [[UITextView alloc]initWithFrame:CGRectMake(30*rate, CGRectGetMaxY(_titleView.frame)+60*rate, viewWidth-60*rate, 14*13*rate)];
    _contentView.text = content;
    _contentView.showsVerticalScrollIndicator = NO;
    _contentView.font = [UIFont fontWithName:[UserSingleton shareUserSingleton].fontName size:13.0f*rate];
    _contentView.textColor = textColor;
    NSAttributedString *contentAttr = [self attributeStringWithText:_contentView.text lineMargin:13.0f*rate wordMargin:1.0f fontSize:13.0f*rate];
    _contentView.attributedText = contentAttr;
    _contentView.delegate = vc;
    [self addSubview:_contentView];
    
    UIView *line2 = [[UIView alloc]initWithFrame:CGRectMake(0,viewHeight-40*rate, viewWidth, 3*rate)];
    line2.backgroundColor = textColor;
    [self addSubview:line2];
    
}




-(void)buildStyle6WithTextColer:(UIColor*)textColor  title:(NSString*)title content:(NSString*)content fontRate:(float)rate vc:(id)vc
{
    _titleView = [[UITextView alloc]initWithFrame:CGRectMake(30*rate, 50*rate, viewWidth-60*rate, 90*rate)];
    _titleView.text = title;
    _titleView.showsVerticalScrollIndicator = NO;
    _titleView.font = [UIFont fontWithName:[UserSingleton shareUserSingleton].fontName size:24.0f*rate];
    NSAttributedString *titleAttr = [self attributeStringWithText:_titleView.text lineMargin:17.0f*rate wordMargin:2.0f fontSize:24.0f*rate];
    _titleView.attributedText = titleAttr;
    _titleView.textColor = textColor;
    _titleView.delegate = vc;
    [self addSubview:_titleView];
    
    _contentView = [[UITextView alloc]initWithFrame:CGRectMake(30*rate, CGRectGetMaxY(_titleView.frame)+60*rate, viewWidth-60*rate, 26*13*rate)];
    _contentView.text = content;
    _contentView.showsVerticalScrollIndicator = NO;
    _contentView.font = [UIFont fontWithName:[UserSingleton shareUserSingleton].fontName size:13.0f*rate];
    _contentView.textColor = textColor;
    NSAttributedString *contentAttr = [self attributeStringWithText:_contentView.text lineMargin:13.0f*rate wordMargin:1.0f fontSize:13.0f*rate];
    _contentView.attributedText = contentAttr;
    _contentView.delegate = vc;
    [self addSubview:_contentView];

}

-(void)buildStyle7WithTextColer:(UIColor*)textColor  title:(NSString*)title content:(NSString*)content fontRate:(float)rate vc:(id)vc
{
    
    
    _contentView = [[UITextView alloc]initWithFrame:CGRectMake(30*rate,(viewHeight-26*13*rate)/2 , viewWidth-60*rate, 26*13*rate)];//y=50*rate
        _contentView.text = content;
    
    CGRect contentRect = [content boundingRectWithSize:CGSizeMake(self.contentView.bounds.size.width, MAXFLOAT) options:NSStringDrawingTruncatesLastVisibleLine|NSStringDrawingUsesFontLeading|NSStringDrawingUsesLineFragmentOrigin  attributes:@{NSFontAttributeName:[UIFont fontWithName:[UserSingleton shareUserSingleton].fontName size:13.0f*rate],NSForegroundColorAttributeName:textColor} context:nil];
    if (contentRect.size.height*2< 26*13*rate) {
     
        self.contentView.frame = CGRectMake(30*rate, (viewHeight-contentRect.size.height*2-20)/2,  viewWidth-60*rate, contentRect.size.height*2+20);
    }else{
        self.contentView.frame = CGRectMake(30*rate, (viewHeight-26*13*rate)/2,  viewWidth-60*rate, 26*13*rate);
    }
//    self.contentView.frame = CGRectMake(30*rate, (viewHeight-26*13*rate)/2,  viewWidth-60*rate, 26*13*rate);
    _contentView.showsVerticalScrollIndicator = NO;
    _contentView.font = [UIFont fontWithName:[UserSingleton shareUserSingleton].fontName size:13.0f*rate];
    _contentView.textColor = textColor;
    NSAttributedString *contentAttr = [self attributeStringWithText:_contentView.text lineMargin:13.0f*rate wordMargin:1.0f fontSize:13.0f*rate];
    _contentView.attributedText = contentAttr;
    _contentView.delegate = vc;
    [self addSubview:_contentView];
    
}


-(void)buildStyle8WithImage:(UIImage*)img vc:(id)vc
{
    
    _imgView = [[EditImageView alloc]initWithFrame:CGRectMake(0, (viewHeight-350-64)/2, viewWidth, 350)];
    _imgView.image =img;
    _imgView.clipsToBounds = YES;
    _imgView.userInteractionEnabled = YES;
    UITapGestureRecognizer *changeTap = [[UITapGestureRecognizer alloc]initWithTarget:vc action:@selector(tapToChangePhoto:)];
    [_imgView addGestureRecognizer:changeTap];
    _imgView.delegate = vc;

    [self addSubview:_imgView];
 
}


-(void)addNewPagesWithVC:(id)vc
{
    _imgView = [[EditImageView alloc]initWithFrame:CGRectMake(25.5, 25.5, viewWidth-50, viewWidth-50)];
    
    _imgView.image =[UIImage imageNamed:@"default"];
    _imgView.clipsToBounds = YES;
//    _imgView.backgroundColor = [UIColor whiteColor];
    _imgView.userInteractionEnabled = YES;
    UIImageView *take = [[UIImageView alloc]initWithFrame:CGRectMake((CGRectGetWidth(_imgView.frame)-38)/2, (CGRectGetHeight(_imgView.frame)-34)/2, 38, 34)];
    take.image = [UIImage imageNamed:@"xiangji"];
    [_imgView addSubview:take];
    UITapGestureRecognizer *tap= [[UITapGestureRecognizer alloc]initWithTarget:vc action:@selector(tapToAddNewPages:)];
    [_imgView addGestureRecognizer:tap];
    take.userInteractionEnabled = YES;
    _imgView.delegate = vc;
    [self addSubview:_imgView];
    UIButton *titleBtn = [[UIButton alloc]initWithFrame:CGRectMake(25.5, CGRectGetMaxY(_imgView.frame)+30, viewWidth-50, 60)];
    titleBtn.layer.borderWidth = 1.0f;
    titleBtn.layer.borderColor = [kColor(216, 216, 216) CGColor];
    [titleBtn setTitle:@"输入文本" forState:UIControlStateNormal];
    titleBtn.titleLabel.font = [UIFont fontWithName:[UserSingleton shareUserSingleton].fontName size:24.0f];
    [titleBtn addTarget:vc action:@selector(pressToAddWords) forControlEvents:UIControlEventTouchUpInside];
    [titleBtn setTitleColor:kColor(74, 74, 74) forState:UIControlStateNormal];
    [self addSubview:titleBtn];
    
}



#pragma mark -- tool
-(NSMutableAttributedString*)attributeStringWithText:(NSString*)text lineMargin:(float)lineMargin wordMargin:(float)wordMargin fontSize:(float)fontSize
{
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:text];
    
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    
    [paragraphStyle setLineSpacing:lineMargin];//调整行间距
    
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [text length])];
  
    
    [attributedString addAttributes:@{NSFontAttributeName:[UIFont fontWithName:[UserSingleton shareUserSingleton].fontName size:fontSize]} range:NSMakeRange(0, [text length])];
    return attributedString;
    
}


#pragma mark -- url 情况
//style1图文版
-(void)buildStyle1WithImageWithUrl:(NSString*)imgUrl textColer:(UIColor*)textColor  title:(NSString*)title content:(NSString*)content vc:(id)vc fontRate:(float)rate
{
    _imgView = [[EditImageView alloc]initWithFrame:CGRectMake(0, 0, viewWidth, 360*viewHeight/667)];
//    _imgView.image =img;
//    [_imgView.imageView sd_setImageWithURL:[NSURL URLWithString:imgUrl]];
    [_imgView.imageView sd_setImageWithURL:[NSURL URLWithString:imgUrl] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
//        _imgView.imageView.image = nil;
        _imgView.image = image;
    }];
    _imgView.clipsToBounds = YES;
    _imgView.backgroundColor =[UIColor whiteColor];
    _imgView.userInteractionEnabled = YES;
    UITapGestureRecognizer *changeTap = [[UITapGestureRecognizer alloc]initWithTarget:vc action:@selector(tapToChangePhoto:)];
    [_imgView addGestureRecognizer:changeTap];
    
    [self addSubview:_imgView];
    
    _titleView = [[UITextView alloc]initWithFrame:CGRectMake(30*rate, CGRectGetMaxY(_imgView.frame)+30*rate, viewWidth-60, 90*rate)];
    _titleView.text = title;
    _titleView.showsVerticalScrollIndicator = NO;
    _titleView.font = [UIFont fontWithName:[UserSingleton shareUserSingleton].fontName size:24.0f*rate];
    NSAttributedString *titleAttr = [self attributeStringWithText:_titleView.text lineMargin:17.0f*rate wordMargin:2.0f fontSize:24.0f*rate];
    _titleView.attributedText = titleAttr;
    _titleView.textColor = textColor;
    // _titleView.numberOfLines = 2;
    _titleView.scrollsToTop = YES;
    _titleView.delegate = vc;
    _titleView.userInteractionEnabled = YES;
    [self addSubview:_titleView];
    
    _contentView = [[UITextView alloc]initWithFrame:CGRectMake(30*rate, CGRectGetMaxY(_titleView.frame)+10*rate, viewWidth-60, 6*13*rate)];
    _contentView.text = content;
    _contentView.font = [UIFont fontWithName:[UserSingleton shareUserSingleton].fontName size:13.0f*rate];
    _contentView.textColor = textColor;
    _contentView.scrollsToTop = YES;
    _contentView.showsVerticalScrollIndicator = NO;
    NSAttributedString *contentAttr = [self attributeStringWithText:_contentView.text lineMargin:13.0f*rate wordMargin:1.0f fontSize:13.0f*rate];
    _contentView.attributedText = contentAttr;
    //_contentView.numberOfLines = 3;
    _contentView.delegate = vc;
    
    
    [self addSubview:_contentView];
    
    
    
}


-(void)buildStyle2WithImageWithUrl:(NSString*)imgUrl textColer:(UIColor*)textColor  title:(NSString*)title content:(NSString*)content vc:(id)vc fontRate:(float)rate
{
    _imgView = [[EditImageView alloc]initWithFrame:CGRectMake(0, 0, viewWidth, 200*viewHeight/667)];
//    _imgView.image =img;
//    [_imgView.imageView sd_setImageWithURL:[NSURL URLWithString:imgUrl]];
    [_imgView.imageView sd_setImageWithURL:[NSURL URLWithString:imgUrl] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        _imgView.imageView.image = nil;
        _imgView.image = image;
    }];

    _imgView.clipsToBounds = YES;
    _imgView.userInteractionEnabled = YES;
    //    _imgView.backgroundColor = [UIColor whiteColor];
    UITapGestureRecognizer *changeTap = [[UITapGestureRecognizer alloc]initWithTarget:vc action:@selector(tapToChangePhoto:)];
    [_imgView addGestureRecognizer:changeTap];
    _imgView.delegate = vc;
    
    [self addSubview:_imgView];
    _titleView = [[UITextView alloc]initWithFrame:CGRectMake(30*rate, CGRectGetMaxY(_imgView.frame)+50*rate, viewWidth-60, 90*rate)];
    _titleView.text = title;
    _titleView.showsVerticalScrollIndicator = NO;
    _titleView.font = [UIFont fontWithName:[UserSingleton shareUserSingleton].fontName size:24.0f*rate];
    NSAttributedString *titleAttr = [self attributeStringWithText:_titleView.text lineMargin:17.0f*rate wordMargin:2.0f fontSize:24.0f*rate];
    _titleView.attributedText = titleAttr;
    _titleView.textColor = textColor;
    _titleView.delegate = vc;
    //    _titleView.numberOfLines = 2;
    [self addSubview:_titleView];
    
    _contentView = [[UITextView alloc]initWithFrame:CGRectMake(30*rate, CGRectGetMaxY(_titleView.frame)+10*rate, viewWidth-60, 14*13*rate)];
    _contentView.text = content;
    _contentView.font = [UIFont fontWithName:[UserSingleton shareUserSingleton].fontName size:13.0f*rate];
    _contentView.textColor = textColor;
    _contentView.showsVerticalScrollIndicator = NO;
    NSAttributedString *contentAttr = [self attributeStringWithText:_contentView.text lineMargin:13.0f*rate wordMargin:1.0f fontSize:13.0f*rate];
    _contentView.attributedText = contentAttr;
    _contentView.delegate = vc;
    //    _contentView.numberOfLines = 7;
    [self addSubview:_contentView];
}

-(void)buildStyle3WithImageWithUrl:(NSString*)imgUrl textColer:(UIColor*)textColor  title:(NSString*)title content:(NSString*)content vc:(id)vc fontRate:(float)rate
{
    _imgView = [[EditImageView alloc]initWithFrame:CGRectMake(25.5*rate, 25.5*rate, viewWidth-50*rate, viewWidth-50*rate)];
    
//    _imgView.image =img;
//    [_imgView.imageView sd_setImageWithURL:[NSURL URLWithString:imgUrl]];
    [_imgView.imageView sd_setImageWithURL:[NSURL URLWithString:imgUrl] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        _imgView.imageView.image = nil;
        _imgView.image = image;
    }];

    _imgView.clipsToBounds = YES;
    //    _imgView.backgroundColor = [UIColor whiteColor];
    _imgView.userInteractionEnabled = YES;
    UITapGestureRecognizer *changeTap = [[UITapGestureRecognizer alloc]initWithTarget:vc action:@selector(tapToChangePhoto:)];
    [_imgView addGestureRecognizer:changeTap];
    _imgView.delegate = vc;
    
    [self addSubview:_imgView];
    _titleView = [[UITextView alloc]initWithFrame:CGRectMake(25.5*rate, CGRectGetMaxY(_imgView.frame)+30*rate, viewWidth-50*rate, 90*rate)];
    _titleView.text = title;
    _titleView.showsVerticalScrollIndicator = NO;
    _titleView.font = [UIFont fontWithName:[UserSingleton shareUserSingleton].fontName size:24.0f*rate];
    NSAttributedString *titleAttr = [self attributeStringWithText:_titleView.text lineMargin:17.0f*rate wordMargin:2.0f fontSize:24.0*rate];
    _titleView.attributedText = titleAttr;
    _titleView.textColor = textColor;
    [self addSubview:_titleView];
    
    _contentView = [[UITextView alloc]initWithFrame:CGRectMake(30*rate, CGRectGetMaxY(_titleView.frame)+10*rate, viewWidth-60, 13*6*rate)];
    _contentView.text = content;
    _contentView.font = [UIFont fontWithName:[UserSingleton shareUserSingleton].fontName size:13.0f*rate];
    _contentView.textColor = textColor;
    _contentView.showsVerticalScrollIndicator = NO;
    NSAttributedString *contentAttr = [self attributeStringWithText:_contentView.text lineMargin:13.0f*rate wordMargin:1.0f fontSize:13.0f*rate];
    _contentView.attributedText = contentAttr;
    
    [self addSubview:_contentView];
    
    
    
}

-(void)buildStyle4WithImageWithUrl:(NSString*)imgUrl textColer:(UIColor*)textColor  title:(NSString*)title content:(NSString*)content vc:(id)vc fontRate:(float)rate
{
    _imgView = [[EditImageView alloc]initWithFrame:CGRectMake(0, 0, viewWidth,viewHeight)];
    
//    _imgView.image =img;
//    [_imgView.imageView sd_setImageWithURL:[NSURL URLWithString:imgUrl]];
    [_imgView.imageView sd_setImageWithURL:[NSURL URLWithString:imgUrl] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        _imgView.imageView.image = nil;
        _imgView.image = image;
    }];

    _imgView.clipsToBounds = YES;
    _imgView.userInteractionEnabled = YES;
    UITapGestureRecognizer *changeTap = [[UITapGestureRecognizer alloc]initWithTarget:vc action:@selector(tapToChangePhoto:)];
    [_imgView addGestureRecognizer:changeTap];
    _imgView.delegate = vc;
    //    UIView *maskView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, CGRectGetWidth(_imgView.frame), CGRectGetHeight(_imgView.frame))];
    //    maskView.backgroundColor = [UIColor blackColor];
    //    maskView.alpha = 0.6f;
    //    [_imgView addSubview:maskView];
    [self addSubview:_imgView];
    _titleView = [[UITextView alloc]initWithFrame:CGRectMake(30*rate, 50*rate, viewWidth-60*rate, 90*rate)];
    _titleView.text = title;
    _titleView.backgroundColor = [UIColor clearColor];
    _titleView.showsVerticalScrollIndicator = NO;
    _titleView.font = [UIFont fontWithName:[UserSingleton shareUserSingleton].fontName size:24.0f*rate];
    NSAttributedString *titleAttr = [self attributeStringWithText:_titleView.text lineMargin:17.0f*rate wordMargin:2.0f fontSize:24.0f*rate];
    _titleView.attributedText = titleAttr;
    _titleView.textColor = textColor;
    _titleView.delegate = vc;
    [self addSubview:_titleView];
    
    
    _contentView = [[UITextView alloc]initWithFrame:CGRectMake(30*rate, CGRectGetMaxY(_titleView.frame)+40*rate, viewWidth-60, 26*13*rate)];
    _contentView.text = content;
    _contentView.showsVerticalScrollIndicator = NO;
    _contentView.backgroundColor = [UIColor clearColor];
    _contentView.font = [UIFont fontWithName:[UserSingleton shareUserSingleton].fontName size:13.0f*rate];
    
    NSAttributedString *contentAttr = [self attributeStringWithText:_contentView.text lineMargin:13.0f*rate wordMargin:1.0f fontSize:13.0f*rate];
    _contentView.attributedText = contentAttr;
    _contentView.textColor = textColor;
    _contentView.delegate = vc;
    
    [self addSubview:_contentView];
    
    
}

-(void)buildStyle8WithImageWithUrl:(NSString*)imgUrl vc:(id)vc
{
    
    _imgView = [[EditImageView alloc]initWithFrame:CGRectMake(0, (viewHeight-350-64)/2, viewWidth, 350)];
//    [_imgView.imageView sd_setImageWithURL:[NSURL URLWithString:imgUrl]];
    [_imgView.imageView sd_setImageWithURL:[NSURL URLWithString:imgUrl] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        _imgView.imageView.image = nil;
        _imgView.image = image;
    }];

    _imgView.clipsToBounds = YES;
    _imgView.userInteractionEnabled = YES;
    UITapGestureRecognizer *changeTap = [[UITapGestureRecognizer alloc]initWithTarget:vc action:@selector(tapToChangePhoto:)];
    [_imgView addGestureRecognizer:changeTap];
    _imgView.delegate = vc;
    
    [self addSubview:_imgView];
    
}





@end
