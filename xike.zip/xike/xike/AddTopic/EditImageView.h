//
//  EditImageView.h
//  PhotoEdit
//
//  Created by shaker on 15/5/19.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol EditImageViewDelegate;

@interface EditImageView : UIView

@property(nonatomic, strong) UIImageView *imageView;
@property(strong, nonatomic)UIImage *image;
@property(strong, nonatomic)UIImage *editImage;
@property(strong, nonatomic) id <EditImageViewDelegate> delegate;


- (void)setup;
- (UIImage*)finishEditing;
- (void)reset;
-(void)endEditPhoto;


@end


@protocol EditImageViewDelegate <NSObject>

@optional
- (void)imageEdit:(EditImageView *)editView didFinishCroppingWithImage:(UIImage *)image;
-(void)editPhoto;

@end

