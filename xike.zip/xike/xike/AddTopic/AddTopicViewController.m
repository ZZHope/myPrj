//
//  AddTopicViewController.m
//  xike
//
//  Created by shaker on 15/6/1.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "AddTopicViewController.h"
#import "UserSingleton.h"
#import "common.h"
//#import "UIImage+Blur.h"
#import "MYFocusButton.h"
#import "TopicDetailController.h"
#import "UIImage+Common.h"
#import "Topic.h"
#import "StartViewController.h"
#import "AFNetworking.h"
#import "Networking.h"
#import "MBProgressHUD+Add.h"
#import "EditImageView.h"
#import "MyAlertView.h"
@interface AddTopicViewController ()<UITextViewDelegate,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextFieldDelegate,UITabBarControllerDelegate,EditImageViewDelegate>

@property(nonatomic, strong) UIView *backView;
@property(nonatomic, strong) EditImageView *imgView;
@property(nonatomic, strong) UILabel *settingTextLabel;
@property(nonatomic, strong) UITextView *titleView;//限制为14个字
@property(nonatomic, strong) UILabel *titleHolder;
@property(nonatomic, strong) UITextView *contentView;//限制在50个字
@property(nonatomic, strong) UILabel *contentHolder;
@property(nonatomic, assign) NSInteger joinCount;
@property(nonatomic, strong) UIButton *setBtn;
@property(nonatomic, strong) UIView *settingPage;
@property(nonatomic, strong) UIView *blurCover;
@property(nonatomic, strong) Topic *topic;
@property(nonatomic, assign) NSInteger postsNumber;

@property(nonatomic, strong) NSMutableArray *sentPicArrM;
@end

@implementation AddTopicViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//记录点击的tabbarItem
    //DATA
    
    _sentPicArrM = [NSMutableArray array];
    _topic = [[Topic alloc]init];
    self.joinCount = 999;
    
    //navigation 的设置


    
    //方便上下移动
    [self creatBackView];
    
    [self creatSettingPage];
    
   
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self navigationSetting];
    self.tabBarController.tabBar.hidden = YES;
    self.tabBarController.delegate = self;
    _backView.frame = CGRectMake(0, 0, kWidth, kHeight);
    [MobClick beginLogPageView:@"AddTopicViewController"];
    

}

-(void)creatBackView
{
    if (_backView == nil) {
        _backView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kHeight)];
        
    }
    if (_imgView == nil) {
       _imgView = [[EditImageView alloc]initWithFrame:CGRectMake(37, 37, kWidth-37*2, (kWidth-37*2))];
    }
//    self.imgView.backgroundColor = kColor(216, 216, 216);
    self.imgView.backgroundColor = [UIColor clearColor];
    
    UITapGestureRecognizer *tapEndEdit = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(endEditImage)];
    [self.backView addGestureRecognizer:tapEndEdit];
    
    self.imgView.image = [UIImage imageNamed:@"default"];
    [self.backView addSubview:self.imgView];
    self.imgView.userInteractionEnabled = YES;
    
    //点击设置图片
    UITapGestureRecognizer *tapChangePic = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(choosePicture:)];
    [self.imgView addGestureRecognizer:tapChangePic];
    
    //设置按钮
    _setBtn = [[UIButton alloc]initWithFrame:CGRectMake((self.backView.bounds.size.width-150)*0.5, CGRectGetMaxY(self.imgView.frame)-43, 150, 30)];
    [_setBtn setImage:[UIImage imageNamed:@"Path"] forState:UIControlStateNormal];
    
    [_setBtn setTitle:[NSString stringWithFormat:@"话题设置（%ld人参与)",self.joinCount] forState:UIControlStateNormal];
    [_setBtn addTarget:self action:@selector(settingPersonNumber) forControlEvents:UIControlEventTouchUpInside];
//    _setBtn.backgroundColor = [UIColor blackColor];
    _setBtn.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.1];
    
    _setBtn.titleLabel.font = [UIFont systemFontOfSize:10.0];
    [_setBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 15, 0, 0)];
    [self.backView addSubview:_setBtn];

    
    //输入标题和内容
    
    _titleView = [[UITextView alloc]initWithFrame:CGRectMake(CGRectGetMinX(self.imgView.frame), CGRectGetMaxY(self.imgView.frame)+42, CGRectGetWidth(self.imgView.frame), 40)];
    self.titleView.font = [UIFont fontWithName:kHeitiSC size:20.0f];
    self.titleView.textColor = kColor(74, 74, 74);
    self.titleView.layer.borderColor = [kColor(216, 216, 216) CGColor];
    self.titleView.layer.borderWidth = 0.5f;
    self.titleView.delegate = self;
    
    self.titleHolder = [[UILabel alloc]initWithFrame:CGRectMake(5, 0, 100, 40)];
    self.titleHolder.text = @"输入标题";
    self.titleHolder.textAlignment = NSTextAlignmentLeft;
    self.titleHolder.font = [UIFont fontWithName:kHeitiSC size:20.0f];
    self.titleHolder.textColor = kColor(74, 74, 74);
    [self.titleView addSubview:self.titleHolder];
    [self.backView addSubview:self.titleView];
    
    _contentView = [[UITextView alloc]initWithFrame:CGRectMake(CGRectGetMinX(self.imgView.frame), CGRectGetMaxY(self.titleView.frame)+20, CGRectGetWidth(self.imgView.frame), 40)];
    self.contentView.textColor = kColor(167, 167, 167);
    self.contentView.font = [UIFont boldSystemFontOfSize:12.0f];
    self.contentView.layer.borderColor = [kColor(216, 216, 216) CGColor];
    self.contentView.layer.borderWidth = 0.5f;
    self.contentView.delegate = self;
    
    self.contentHolder = [[UILabel alloc]initWithFrame:CGRectMake(5, 0, 100, 40)];
    self.contentHolder.text = @"输入内容";
    self.contentHolder.textAlignment = NSTextAlignmentLeft;
    self.contentHolder.font = [UIFont fontWithName:kHeitiSC size:12.0f];
    self.contentHolder.textColor = kColor(74, 74, 74);
    [self.contentView addSubview:self.contentHolder];
    [self.backView addSubview:self.contentView];

    
    [self.view addSubview:self.backView];
}

//navigation 的设置
-(void)navigationSetting
{
    
    UIButton *rightBtn = [self customButtonOnNavigationWithTitle:@"创建" tag:1001];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
    UIButton *leftBtn = [self customButtonOnNavigationWithTitle:@"取消" tag:1002];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    //textView
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 60, 15)];
    titleLabel.text = @"创建话题";
    titleLabel.font = [UIFont boldSystemFontOfSize:15.0f];
    self.navigationItem.titleView = titleLabel;
    self.navigationController.navigationBar.translucent = NO;
    
}

//button
-(UIButton *)customButtonOnNavigationWithTitle:(NSString *)title tag:(NSInteger)tag
{
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 30, 15)];
    
    [btn setTitle:title forState:UIControlStateNormal];
    [btn setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
    btn.tag = tag;
    btn.titleLabel.font = [UIFont systemFontOfSize:15.0];
    [btn addTarget:self action:@selector(naviItemClick:) forControlEvents:UIControlEventTouchUpInside];
    return btn;
    
}


#pragma click event

//确定键
-(void)makeSureClick
{
    UITextField *textField = (UITextField*)[self.settingPage viewWithTag:3001];
    
    self.joinCount =  [textField.text integerValue];
    if (self.postsNumber-2001 == 0) {
        self.joinCount = 999;
    }else if(self.postsNumber-2001 == 1){
        self.joinCount = 0;
    }else{
        
        self.joinCount = [textField.text integerValue];
    }

    if (self.joinCount == 0) {
        [_setBtn setTitle:[NSString stringWithFormat:@"话题设置（仅自己)"] forState:UIControlStateNormal];
    }else{
        
        [_setBtn setTitle:[NSString stringWithFormat:@"话题设置（%ld人参与)",self.joinCount] forState:UIControlStateNormal];
    }

    [self hideSettingView];

}


//navigation 上的点击事件
-(void)naviItemClick:(UIButton *)sender
{
    switch (sender.tag) {
        case 1001://右视图创建
        {
            [self endEditImage];
            self.topic.topicOriginPic = [UIImage imageCapture:self.imgView];
//            self.topic.topicOriginPic = self.imgView.image;
            self.topic.topicTitle = self.titleView.text;
            self.topic.topicContent = self.contentView.text;
//            sender.userInteractionEnabled = NO;
            
            if (![[NSUserDefaults standardUserDefaults]boolForKey:isLogin]) {
                    StartViewController *startVC = [[StartViewController alloc]init];
                    startVC.hidesBottomBarWhenPushed = YES;
                    [self.navigationController pushViewController:startVC animated:YES];
            }else {
            
                if (self.titleView.text.length || self.contentView.text.length) {

                    [self creatTopicToService];
                }else{
                    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"标题和内容不可以同时为空" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                    [alert show];
                    self.tabBarController.tabBar.hidden = NO;
                }
                
                
            }

            
            
        }
            
            break;
            
        case 1002://左视图
        {
            int  index = [[UserSingleton shareUserSingleton].tabItemIndex intValue];
            self.tabBarController.selectedViewController = self.tabBarController.viewControllers[index];
        }
            break;

            
        default:
            break;
    }

}


//人数设置
NSInteger selTag = 2001;

-(void)selectPersonNumber:(MYFocusButton*)sender
{
    MYFocusButton *btn = (MYFocusButton *)[self.settingPage viewWithTag:selTag];
    //[btn setSelFlag:NO andImg:@"duihao" highLightImg:@"duihao"];
    btn.backgroundColor = [UIColor whiteColor];
    [sender setSelFlag:YES andImg:@"duihao" highLightImg:@"duihao"];
    sender.backgroundColor = kColor(0, 216, 165);
    self.postsNumber = sender.tag;
    selTag = sender.tag;
}

#pragma mark -- 设置人数和创建设置界面
//设置人数
-(void)settingPersonNumber
{
    self.settingPage.backgroundColor = [[UIColor blackColor]colorWithAlphaComponent:0.6f];
    [UIView animateWithDuration:0.0f animations:^{
   
        [self.view addSubview:self.blurCover];
        _settingPage.frame = CGRectMake(0, 0, kWidth, kHeight+49+64);
        
    }];

}


//设置界面

-(void)creatSettingPage
{
    _settingPage = [[UIView alloc]initWithFrame:CGRectMake(0, kHeight+49, kWidth, kHeight+49+64)];
    _blurCover = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kHeight+64)];
    _blurCover.layer.contents =  (id)[self getBlurImageWithCGRect:CGRectMake(0, -64, kWidth, kHeight)].CGImage;
    self.settingPage.backgroundColor = [[UIColor blackColor]colorWithAlphaComponent:0.6f];

    
    UITapGestureRecognizer *tapCancel = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(hideSettingView)];
    [self.settingPage addGestureRecognizer:tapCancel];

    //subview
    
    [self creatSettingSubPage];

//    [self.view addSubview:self.blurCover];
    [[[[UIApplication sharedApplication] delegate] window] addSubview:self.settingPage];
    
}


-(void)creatSettingSubPage
{
    CGFloat subHeight = kWidth-37*2;
    UIImageView *subViewSet = [[UIImageView alloc]initWithFrame:CGRectMake(37, (kHeight-subHeight)*0.5, subHeight, subHeight)];
    subViewSet.userInteractionEnabled = YES;
    subViewSet.backgroundColor = [UIColor whiteColor];
    subViewSet.alpha = 1.0f;
    
    UILabel *firstLabel = [[UILabel alloc]initWithFrame:CGRectMake(28, 40, 60, 15)];
    firstLabel.text = @"话题设置";
    firstLabel.textColor = kColor(74, 74, 74);
    firstLabel.font = [UIFont boldSystemFontOfSize:15.0f];
    [subViewSet addSubview:firstLabel];
    
    
    UILabel *countLabel = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMinX(firstLabel.frame), CGRectGetMaxY(firstLabel.frame)+39, 72, 13)];
    countLabel.text = @"设置参与人数";
    countLabel.textColor = kColor(155, 155, 155);
    countLabel.font = [UIFont systemFontOfSize:12.0f];
    [subViewSet addSubview:countLabel];
    
    
    UITextField *textField = [[UITextField alloc]initWithFrame:CGRectMake(CGRectGetWidth(subViewSet.frame)-33-51, CGRectGetMaxY(countLabel.frame)-25, 51, 25)];
    textField.placeholder = @"输入人数";
    textField.textAlignment = NSTextAlignmentCenter;
    textField.font = [UIFont systemFontOfSize:10.0f];
    textField.textColor = kColor(216, 216, 216);
    textField.layer.borderColor = [kColor(231, 231, 231) CGColor];
    textField.layer.borderWidth = 0.5;
    textField.tag = 3001;
    textField.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
    textField.delegate = self;
    [subViewSet addSubview:textField];
    
    
    UIView *line1 = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(countLabel.frame)+11, subViewSet.bounds.size.width, 1)];
    line1.backgroundColor = kColor(231, 231, 231);
    [subViewSet addSubview:line1];
    
    
    UILabel *noLimitLabel = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMinX(firstLabel.frame), CGRectGetMaxY(line1.frame)+20, 72, 13)];
    noLimitLabel.text = @"不限参与人数";
    noLimitLabel.textColor = kColor(155, 155, 155);
    noLimitLabel.font = [UIFont systemFontOfSize:12.0f];
    [subViewSet addSubview:noLimitLabel];
    
    
    MYFocusButton *selCount = [[MYFocusButton alloc]initWithFrame:CGRectMake(CGRectGetWidth(subViewSet.frame)-48-19, CGRectGetMaxY(noLimitLabel.frame)-19, 19, 19)];
    
    selCount.tag = 2001;
    selCount.layer.borderWidth = 1.0f;
    selCount.layer.borderColor = [kColor(231, 231, 231) CGColor];
    [selCount setSelFlag:YES andImg:@"duihao" highLightImg:@"duihao"];
    selCount.backgroundColor = kColor(0, 216, 165);
    [selCount addTarget:self action:@selector(selectPersonNumber:) forControlEvents:UIControlEventTouchUpInside];
    [subViewSet addSubview:selCount];
    
    
    UIView *line2 = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(noLimitLabel.frame)+11, subViewSet.bounds.size.width, 1)];
    line2.backgroundColor = kColor(231, 231, 231);
    [subViewSet addSubview:line2];
    
    
    
    UILabel *limitLabel = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMinX(firstLabel.frame), CGRectGetMaxY(line2.frame)+20, 36, 13)];
    limitLabel.text = @"仅自己";
    limitLabel.textColor = kColor(155, 155, 155);
    limitLabel.font = [UIFont systemFontOfSize:12.0f];
    [subViewSet addSubview:limitLabel];
    
    MYFocusButton *onlyOwn = [[MYFocusButton alloc]initWithFrame:CGRectMake(CGRectGetWidth(subViewSet.frame)-48-19, CGRectGetMaxY(limitLabel.frame)-19, 19, 19)];
    
    onlyOwn.tag = 2002;
    onlyOwn.layer.borderWidth = 1.0f;
    onlyOwn.layer.borderColor = [kColor(231, 231, 231) CGColor];
    [onlyOwn addTarget:self action:@selector(selectPersonNumber:) forControlEvents:UIControlEventTouchUpInside];
    [subViewSet addSubview:onlyOwn];

    UIView *line3 = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(limitLabel.frame)+11, subViewSet.bounds.size.width, 1)];
    line3.backgroundColor = kColor(231, 231, 231);
    [subViewSet addSubview:line3];

    
    UIButton *sureBtn = [[UIButton alloc]initWithFrame:CGRectMake((subViewSet.frame.size.width-35)*0.5, subViewSet.frame.size.height-35, 35, 15)];
    [sureBtn setTitle:@"确定" forState:UIControlStateNormal];
    sureBtn.titleLabel.font = [UIFont boldSystemFontOfSize:15.0f];
    [sureBtn setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
    [sureBtn addTarget:self action:@selector(makeSureClick) forControlEvents:UIControlEventTouchUpInside];
    
    [subViewSet addSubview:sureBtn];
    
    
    [self.settingPage addSubview:subViewSet];
    
    
}


#pragma mark -- textViewDelegate

-(void)textViewDidBeginEditing:(UITextView *)textView
{
    if (textView == self.titleView) {
        [self.titleHolder removeFromSuperview];
    }else{
        [self.contentHolder removeFromSuperview];
    }
    [UIView animateWithDuration:0.5f animations:^{
        
      self.backView.frame = CGRectMake(0, 0-216, kWidth, kHeight-64);
        
    }];
    
}



-(void)textViewDidEndEditing:(UITextView *)textView
{
    if (textView == self.contentView) {
        [UIView animateWithDuration:0.5f animations:^{
            self.backView.frame = CGRectMake(0, 0, kWidth, kHeight-64);
        }];
        if ([textView.text isEqualToString:@""]) {
            textView.text = @"输入内容";
        }
       
    }else{
        if ([textView.text isEqualToString:@""]) {
            textView.text = @"输入标题";
        }
    }
    
    
    CGRect titleSize = [self.titleView.text boundingRectWithSize:CGSizeMake(self.titleView.bounds.size.width, 0) options:NSStringDrawingTruncatesLastVisibleLine|NSStringDrawingUsesFontLeading|NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:20.0f],NSForegroundColorAttributeName:kColor(74, 74, 74)} context:nil];
    CGRect titleF = self.titleView.frame;
    titleF.size.height = titleSize.size.height+30;
    self.titleView.frame = titleF;
    
    CGRect contentRect = [self.contentView.text boundingRectWithSize:CGSizeMake(self.titleView.bounds.size.width, 0) options:NSStringDrawingTruncatesLastVisibleLine|NSStringDrawingUsesFontLeading|NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:12.0f],NSForegroundColorAttributeName:kColor(74, 74, 74)} context:nil];
    CGRect contentF = self.contentView.frame;
    contentF.size.height = contentRect.size.height+20;
    contentF.origin.y = CGRectGetMaxY(self.titleView.frame)+20;
    self.contentView.frame = contentF;

    
    
}

-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if (range.length+range.location > textView.text.length) {
        return NO;
    }
    if (textView == self.titleView &&self.titleView.text.length>14) {
        
        return NO;
    }else  if (self.contentView.text.length >50) {
        return NO;
    }

    return YES;
}

//点击屏幕
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [UIView animateWithDuration:0.5f animations:^{
            self.backView.frame = CGRectMake(0, 0, kWidth, kHeight-64);
        }];
    

    [self.titleView resignFirstResponder];
    [self.contentView resignFirstResponder];
}

-(void)hideSettingView
{
    self.settingPage.backgroundColor = [[UIColor blackColor]colorWithAlphaComponent:0.0f];
    [UIView animateWithDuration:0.5f animations:^{
        
        [self.blurCover removeFromSuperview];

        _settingPage.frame = CGRectMake(0, kHeight+49+64, kWidth, kHeight+49+64);//CHANGE
    }];
    
    [[[[UIApplication sharedApplication]delegate]window] endEditing:YES];
    
}

#pragma mark-- 手势
//点击选择图片

-(void)choosePicture:(UITapGestureRecognizer *)tap
{

        UIActionSheet *actionSheet = [[UIActionSheet alloc]initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"拍照上传",@"从照片库获取", nil];
        
        [actionSheet showInView:self.view];

        


}

-(void)endEditImage
{
    [self.imgView endEditPhoto];
    
    
    
}

#pragma mark -- actionSheet

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex) {
        case 0://take photo
            
            [self pickImageByType:UIImagePickerControllerSourceTypeCamera];
            
            break;
        case 1://local photo
            
            [self pickImageByType:UIImagePickerControllerSourceTypePhotoLibrary];
            break;

            
        default:
            break;
    }
}


#pragma mark -- 拍照上传或者从照片库获取图片

-(void)pickImageByType:(UIImagePickerControllerSourceType)sourceType
{
    UIImagePickerController *picker = [[UIImagePickerController alloc]init];
    picker.delegate =self;
    picker.allowsEditing =YES;

    if (sourceType == UIImagePickerControllerSourceTypeCamera) {
        
        if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
            
            UIAlertView *alerView = [[UIAlertView alloc]initWithTitle:@"无法拍照" message:@"此设备拍照功能不可用" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
            [alerView show];

        }else{
            picker.sourceType =sourceType;
            [self presentViewController:picker animated:YES completion:nil];
        }
        
    }else{
    picker.sourceType =sourceType;
    [self presentViewController:picker animated:YES completion:nil];
    }
}

#pragma mark --  picker delegate


-(void)imagePickerController:(UIImagePickerController*)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    [picker dismissViewControllerAnimated:YES completion:^(){
        UIImage* image = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
        self.imgView.image = image;
    }];
    
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    NSLog(@"您取消了选择图片");
    [picker dismissViewControllerAnimated:YES completion:nil];
    
}


#pragma mark -- textfield

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    
        [textField becomeFirstResponder];
        MYFocusButton *btnNolimit = (MYFocusButton*)[self.settingPage viewWithTag:2001];
        MYFocusButton *btnOnly = (MYFocusButton*)[self.settingPage viewWithTag:2002];
        btnNolimit.backgroundColor = [UIColor whiteColor];
        btnOnly.backgroundColor = [UIColor whiteColor];

    
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    NSString * toBeString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    if ([toBeString length] > 3) {
            textField.text = [toBeString substringToIndex:3];
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"最大参与人数为999" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
            [alert show];
            return NO;
    }else{
         return YES;
    }
    
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    
    [textField resignFirstResponder];
    self.joinCount = [textField.text integerValue];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}


#pragma mark -- 模糊处理

- (UIImage *)getBlurImageWithCGRect:(CGRect)rect {

    CIContext *context = [CIContext contextWithOptions:nil];
    self.view.backgroundColor = [UIColor whiteColor];
    self.titleView.layer.borderColor = [[UIColor clearColor] CGColor];
    self.contentView.layer.borderColor = [[UIColor clearColor] CGColor];
    self.titleView.backgroundColor = [UIColor clearColor];
    self.contentView.backgroundColor = [UIColor clearColor];
    UIImage *img = [UIImage imageCaptureWithRect:rect view:self.view];
//    CGRect rect = CGRectMake(0, 0, kWidth, kHeight+64);
//    UIImage *img = [UIImage imageCaptureWithRect:rect];
    self.titleView.layer.borderColor = [kColor(216, 216, 216) CGColor];
    self.contentView.layer.borderColor = [kColor(216, 216, 216) CGColor];
    self.titleView.backgroundColor = [UIColor whiteColor];
    self.contentView.backgroundColor = [UIColor whiteColor];

    NSData *imageData = UIImageJPEGRepresentation(img, 1.0f);
    CIImage *image = [CIImage imageWithData:imageData];
    CIFilter *filter = [CIFilter filterWithName:@"CIGaussianBlur"];
    [filter setValue:image forKey:kCIInputImageKey];
    [filter setValue:@3.0f forKey: @"inputRadius"];
    CIImage *result = [filter valueForKey:kCIOutputImageKey];
    CGImageRef outImage = [context createCGImage: result fromRect:[result extent]];
    UIImage * blurImage = [UIImage imageWithCGImage:outImage];
    
    return blurImage;
    
}

#pragma mark--load data
-(void)creatTopicToService
{
    [MBProgressHUD showMessage:@"正在创建话题..." toView:[[UIApplication sharedApplication] keyWindow]];
    NSData *originData = UIImageJPEGRepresentation(self.topic.topicOriginPic, 1.0f);
    
    NSInteger limitNum = 0;
    if (self.joinCount == 999) {
        limitNum = -1;
    }else if (self.joinCount == 0){
        limitNum = -2;
    }else{
        limitNum = self.joinCount;
    }
    
    NSDictionary *parameter = @{@"authCode":[[NSUserDefaults standardUserDefaults] objectForKey:kAuthCode],
                                @"deviceToken":[[NSUserDefaults standardUserDefaults]objectForKey:kDeviceToken],
                                @"title":self.topic.topicTitle,
                                @"content":self.topic.topicContent,
                                @"postLimit":[NSNumber numberWithInteger:limitNum]   //人数需要判断
                            };
    NSString *strUrl = [NSString stringWithFormat:@"%@%@",HOST,@"topic/add"];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager POST:strUrl parameters:parameter constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
       
        NSDictionary *dic =@{@"name":@"logoImage",@"file":originData};
        NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
        [formatter setDateFormat:@"YYYY-MM-dd hh:mm:ss"];
        NSString *date = [formatter stringFromDate:[NSDate date]];
        
        
            [formData appendPartWithFileData:[dic objectForKey:@"file"] name:[dic objectForKey:@"name"] fileName:date mimeType:@"image/jpeg"];

    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
       
        [MBProgressHUD hideHUDForView:[[UIApplication sharedApplication] keyWindow]  animated:YES];
        
        if ([[responseObject objectForKey:@"code"] intValue]==1) {
            if (![[responseObject objectForKey:@"data"] isEqual:[NSNull null]]) {
            
                TopicDetailController *topicDetail = [[TopicDetailController alloc]init];
                topicDetail.fromTopic = CompleteTopic;
                topicDetail.hidesBottomBarWhenPushed = YES;
                topicDetail.listTopicId = [[responseObject objectForKey:@"data"] objectForKey:@"id"];
                [self.navigationController pushViewController:topicDetail animated:YES];

            }

        }else{

            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[responseObject objectForKey:@"msg"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];

        }
        NSLog(@"creat :%@ %@",responseObject,[responseObject objectForKey:@"msg"]);
       
        
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
            [MBProgressHUD hideHUDForView:[[UIApplication sharedApplication] keyWindow]  animated:YES];
            NSLog(@"topic creat error:%@",error);
            
            [MyAlertView showMessageToView:[[UIApplication sharedApplication] keyWindow]];
            
        
    }];
    

}




-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [MBProgressHUD hideHUDForView:self.backView  animated:YES];
    self.tabBarController.tabBar.hidden = NO;
    [MobClick endLogPageView:@"AddTopicViewController"];
    
}


#pragma mark -- editView Delegate



@end
