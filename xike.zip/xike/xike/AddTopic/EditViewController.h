//
//  EditViewController.h
//  xike
//
//  Created by shaker on 15/7/1.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^textBlock) (NSDictionary *textDic);
@interface EditViewController : UIViewController
@property(nonatomic,copy)textBlock textBlock;


-(void)returnEditedText:(textBlock)textBlock;

@end
