//
//  Topic.h
//  xike
//
//  Created by shaker on 15/6/26.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface Topic : NSObject
@property (nonatomic, assign) int topicId;
@property (nonatomic, assign) int concernsNum;//关注数
@property (nonatomic, assign) int  postsNum;//参与人数
@property (nonatomic, strong) UIImage *topicOriginPic;//图片
@property (nonatomic, strong) UIImage *topicCropPic;
@property (nonatomic, copy) NSString *topicTitle;
@property (nonatomic, copy) NSString *topicContent;
@property (nonatomic, copy) NSString *creatorName;
@property (nonatomic, copy) NSString *creatorPhoto;
@property (nonatomic, assign) int creatorUserId;
@property (nonatomic, assign) NSArray *articleArr;//作品数量







@end
