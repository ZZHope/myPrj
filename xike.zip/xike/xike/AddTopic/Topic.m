//
//  Topic.m
//  xike
//
//  Created by shaker on 15/6/26.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "Topic.h"

@implementation Topic
-(id)init
{
    self = [super init];
    if (self) {
       
        _topicId = 0;
        _concernsNum = 0;
        _postsNum = 0;
        _topicOriginPic = [[UIImage alloc]init];
        _topicCropPic = [[UIImage alloc]init];
        _topicTitle = @"";
        _topicContent = @"";
        _creatorName = @"";
        _creatorPhoto = @"";
        _creatorUserId = 0;
        _articleArr = [NSArray array];
    }
    
    return self;
}

@end
