//
//  CreatStyleFrameController.m
//  xike
//
//  Created by shaker on 15/6/18.
//  Copyright (c) 2015年 shaker. All rights reserved.
//


/*
 
 说明：数字：100x -- navigation item
           200x -- bottom bar
           300x -- temeplete view
           10x -- styleScroll imgview
 */

#import "CreatStyleFrameController.h"
#import "common.h"
#import "ObtainPictureViewController.h"
#import "templeteView.h"
#import "EditViewController.h"
#import "UIImage+Common.h"
#import "AFNetworking.h"
#import "Networking.h"
#import <CoreText/CoreText.h>
#import "UserSingleton.h"
#import "MBProgressHUD+Add.h"
#import "MyAlertView.h"
#import "ShakerDataBaseManager.h"

typedef NS_ENUM(NSInteger, REUSEVIEW)
{
    DEFAULTVIEW=200,
    STYLEVIEW,
    ADDNEWVIEW,
    EDITVIEW,
    WORDSTYLE,
    HAVEADDED,
    IMAGEEDIT,
    DELETEVIEW
};


#define kImage @"image"
#define kStyle @"style"
#define kTitle @"title"
#define kTitleLineNum @"titleLineNum"
#define kContentLineNum @"contentLineNum"
#define kContent    @"content"
#define kWordsName  @"wordsName"
#define isDownload  @"isDownload"
#define typeFaceUrl @"typeFaceUrl"
#define isSelStyle @"isSelStyle"
#define kWordsNameSel @"wordsNameSel"
#define kRealWordsName @"realWordsName"
#define kDownLoadKey @"downLoadKey"
#define kTypeFileName @"typeFileName"

#define kCropViewImg @"cropViewImg"
#define kCropOriginImg @"cropOriginImg"

@interface CreatStyleFrameController ()<UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout,templeteViewDelegate,UITableViewDataSource,UITableViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,EditImageViewDelegate,UITextViewDelegate,UIScrollViewDelegate>

@property(nonatomic,strong)   UICollectionView *collectionView;
@property (nonatomic, strong) NSMutableArray *templeteViewM;
@property (nonatomic, strong) NSMutableArray *haveCropImgM;
@property (nonatomic, strong) NSMutableArray *deleteAddedM;

@property (nonatomic, strong) UIToolbar *toolBar;
@property (nonatomic, strong) UIScrollView *styleScrollview;
@property (nonatomic, strong) UIScrollView *haveAdddedScrollView;
@property (nonatomic, strong) UIButton *deleBtn;
@property (nonatomic, strong) UILabel *alreadyCountLabel;
@property (nonatomic, strong) UIView *addedBgView;

@property (nonatomic, assign) NSInteger addCount;
@property (nonatomic, assign) NSInteger viewFlag;
@property (nonatomic, assign) NSInteger insertFlag;
@property (nonatomic, assign) float pinchRate;


@property (nonatomic, strong) UITableView *downloadView;
@property (nonatomic, strong) NSMutableArray *downWordsM;
@property (nonatomic, strong) UIProgressView *fProgressView;

//navigation
@property (nonatomic, strong) UILabel *titleLabe;
@property (nonatomic, strong) UIButton *leftBtn;
@property (nonatomic, strong) UIButton *rightBtn;

//@property (strong, nonatomic)  UIProgressView *fProgressView;
//@property (strong, nonatomic)  NSString *errorMessage;
@property (strong, nonatomic)  UIButton *tempBtn;

@property (strong, nonatomic) UIView *wordsCover;
@property (strong, nonatomic) UIView *templeteCover;
@property (strong, nonatomic) UIView *deleteCover;
@property (strong, nonatomic) UIView *addedCover;

@property (strong, nonatomic) UIImage *coverCropImage;

//@property (strong, nonatomic) NSURLSession *typeFaceSession;
@property (strong, nonatomic) NSURL *fontUrl;



@end

BOOL isHtiSel = YES;
static NSString *creatCell = @"creatCell";
@implementation CreatStyleFrameController


-(void)viewDidLoad
{
    
    self.view.backgroundColor = kColor(216, 216, 216);
    
    //data
    
    _templeteViewM = [NSMutableArray array];
    _downWordsM = [NSMutableArray array];
    _haveCropImgM = [NSMutableArray array];
    _deleteAddedM = [NSMutableArray array];
    
    [self.downWordsM addObject:@{kWordsName:@"lanting",kWordsNameSel:@"lantingSel", isDownload:[NSNumber numberWithBool:[[[NSUserDefaults standardUserDefaults] objectForKey:kIsLantingD]boolValue]],isSelStyle:@NO,kRealWordsName:@"FZLTXHK--GBK1-0",typeFaceUrl:HOSTZITIQH,kDownLoadKey:kIsLantingD,kTypeFileName:@"QH.TTF"}];//FZLTXHK
    [self.downWordsM addObject:@{kWordsName:@"songti",kWordsNameSel:@"songtiSel",isDownload:[NSNumber numberWithBool:[[[NSUserDefaults standardUserDefaults] objectForKey:kIsSongD]boolValue]],isSelStyle:@NO,kRealWordsName:@"STSongti-SC-Regular",typeFaceUrl:HOSTZITISONG,kDownLoadKey:kIsSongD,kTypeFileName:@"SONG.TTF"}];//STSong
    [self.downWordsM addObject:@{kWordsName:@"fangsong",kWordsNameSel:@"fangsongSel",isDownload:[NSNumber numberWithBool:[[[NSUserDefaults standardUserDefaults] objectForKey:kIsFangSongD]boolValue]],isSelStyle:@NO,kRealWordsName:@"STFangsong",typeFaceUrl:HOSTZITIFS,kDownLoadKey:kIsFangSongD,kTypeFileName:@"FZFSK.TTF"}];//STFangsong  FZFSK--GBK1-0
    
//    [self originTypeFace];
    
    [self creatTempleteData];
    
    self.addCount = 0;
    self.insertFlag = 0;
    //collection
    UICollectionViewFlowLayout *flowout = [[UICollectionViewFlowLayout alloc]init];
    [flowout setScrollDirection:UICollectionViewScrollDirectionHorizontal];
    _collectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kHeight) collectionViewLayout:flowout];
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    [self.collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:creatCell];
    self.collectionView.pagingEnabled = YES;
    self.collectionView.backgroundColor = kColor(216, 216, 216);
    self.collectionView.showsHorizontalScrollIndicator = NO;
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.collectionView];
    
    //nav
    [self settingNavBar];
    
    [self creatBottomBar];
    [self creatBottomStyleView];


    //delete button
    
    _deleteCover = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kHeight)];
    _deleBtn = [[UIButton alloc]initWithFrame:CGRectMake((kWidth-40)/2, kHeight-100-20, 40, 40)];
    [self.deleBtn setImage:[UIImage imageNamed:@"delete"] forState:UIControlStateNormal];
    [self.deleBtn addTarget:self action:@selector(deleteView) forControlEvents:UIControlEventTouchUpInside];
    [self.deleteCover addSubview:self.deleBtn];
    
    _wordsCover = [[UIView alloc]initWithFrame:CGRectMake(0, 64, kWidth, kHeight)];
    _downloadView = [[UITableView alloc]initWithFrame:CGRectMake(0, kHeight-295*kHeight/667, kWidth, 295*kHeight/667) style:UITableViewStyleGrouped];
    self.downloadView.backgroundColor = [UIColor whiteColor];
    self.downloadView.dataSource = self;
    self.downloadView.delegate = self;
    [self.wordsCover addSubview:self.downloadView];
    
    //haveAddedView
    _addedCover = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kHeight)];
    _addedBgView = [[UIView alloc]initWithFrame:CGRectMake(0, kHeight-(150*kHeight/667+15)-64-20-5, kWidth, 150*kHeight/667+30)];
    self.addedBgView.backgroundColor = [UIColor whiteColor];
    _haveAdddedScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(2,12,CGRectGetWidth(self.addedBgView.frame)-4, CGRectGetHeight(self.addedBgView.frame))];
    self.haveAdddedScrollView.showsVerticalScrollIndicator = NO;
    self.haveAdddedScrollView.showsHorizontalScrollIndicator = NO;
    self.haveAdddedScrollView.scrollEnabled = YES;
    self.haveAdddedScrollView.backgroundColor = [UIColor whiteColor];
    [self.addedBgView addSubview:self.haveAdddedScrollView];
    [self.addedCover addSubview:self.addedBgView];
    
    //progress
    //progressView
    _fProgressView = [[UIProgressView alloc]initWithProgressViewStyle:UIProgressViewStyleDefault];
    self.fProgressView.frame  =CGRectMake(0, 17, 22, 5);
    self.fProgressView.progressTintColor = kColor(216, 216, 216);
    self.fProgressView.trackTintColor = [UIColor whiteColor];//kColor(0, 216, 165);
    

    
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [MobClick beginLogPageView:@"CreatStyleFrameController"];
}

#pragma mark -- creatTempleteData
-(void)creatTempleteData
{
    //图片存储路径
    NSString *path = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)[0] stringByAppendingPathComponent:kOriginalPhotoImages];

    
    for (int i=0; i<self.originalPhotoArr.count+1; i++) {
        if (i==0) {
            
            NSString *photoPath = [path stringByAppendingPathComponent:[self.originalPhotoArr[0] objectForKey:kImgName]];
            [self.templeteViewM addObject:@{kImage:[UIImage imageWithContentsOfFile:photoPath],
                                            kStyle:@"1",
                                            kTitle:@"输入标题",
                                            kContent:@"输入内容",
                                            kTitleLineNum:@2,
                                            kContentLineNum:@3}];

            
        
        }else if (i==1){


        [self.templeteViewM addObject:@{kImage:[UIImage imageNamed:@"default"],
                                            kStyle:@"7",
                                            kTitle:@"输入标题",
                                            kContent:@"输入内容",
                                        kTitleLineNum:@0,
                                        kContentLineNum:@13}];

        }else if (i==2){
           
        NSString *photoPath = [path stringByAppendingPathComponent:[self.originalPhotoArr[1] objectForKey:kImgName]];
        [self.templeteViewM addObject:@{kImage:[UIImage imageWithContentsOfFile:photoPath],
                                            kStyle:@"8",
                                            kTitle:@"输入标题",
                                            kContent:@"输入内容",
                                        kTitleLineNum:@0,
                                        kContentLineNum:@0}];


        }else{
            
            NSString *photoPath = [path stringByAppendingPathComponent:[self.originalPhotoArr[i-1] objectForKey:kImgName]];
            [self.templeteViewM addObject:@{kImage:[UIImage imageWithContentsOfFile:photoPath],
                                            kStyle:@"1",
                                            kTitle:@"输入标题",
                                            kContent:@"输入内容",
                                            kTitleLineNum:@2,
                                            kContentLineNum:@3}];
            


        }
    }
}

#pragma mark -- nav setting

-(void)settingNavBar
{
    _leftBtn = [self customNaviButtonWithFrame:CGRectMake(0, 0, 50, 30) title:@"取消" tag:1001];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithCustomView:_leftBtn];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    _rightBtn = [self customNaviButtonWithFrame:CGRectMake(0, 0, 50, 30) title:@"发布" tag:1002];
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc]initWithCustomView:self.rightBtn];
    self.navigationItem.rightBarButtonItem = rightItem;
    
    _titleLabe = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 60, 30)];
    self.titleLabe.text=@"创建作品";
    self.titleLabe.textAlignment = NSTextAlignmentCenter;
    self.titleLabe.font = [UIFont systemFontOfSize:15.0f];
    self.navigationItem.titleView = self.titleLabe;
    self.navigationController.navigationBar.translucent = NO;
    
}

//custom button
-(UIButton *)customNaviButtonWithFrame:(CGRect)frame title:(NSString *)title tag:(NSInteger)tag
{
    UIButton *btn = [[UIButton alloc]initWithFrame:frame];
    [btn setTitle:title forState:UIControlStateNormal];
    [btn setTitleColor: kColor(0, 216, 165) forState:UIControlStateNormal];
    btn.tag = tag;
    btn.titleLabel.font = [UIFont systemFontOfSize:15.0f];
    [btn addTarget:self action:@selector(creatNaviItemClick:) forControlEvents:UIControlEventTouchUpInside];
    
    return btn;
    
}

#pragma mark -- navi click

-(void)creatNaviItemClick:(UIButton *)sender
{
    switch (sender.tag) {
        case 1001://leftBtn
        {
           
            if (self.viewFlag == ADDNEWVIEW) {
                
                [self cancelAddNewPage];
                
            }else if (self.viewFlag == STYLEVIEW){
                
                [self cancelStyleView];
                
            }else if (self.viewFlag == EDITVIEW){
                

            }else if (self.viewFlag == HAVEADDED){
                [self makeSureAddedView];
                
            }else if(self.viewFlag == DELETEVIEW){
                
                [self cancelDelete];
                
            }else if(self.viewFlag == WORDSTYLE){
                
                [self cancelShowWordStyle];
                
            }else if (self.viewFlag == IMAGEEDIT){
                
                [self cancelToEditPhoto];
                
            }else{
                
                [self.navigationController popViewControllerAnimated:YES];
            }
        }
            
            break;
        case 1002://rightBtn
        {
            if (self.viewFlag == ADDNEWVIEW) {
                
                int tempTag = (int)ceil(self.collectionView.contentOffset.x/self.collectionView.bounds.size.width);
                if ([[self.templeteViewM[tempTag] objectForKey:kStyle] isEqualToString:@"0"]){
                    
                    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"您未做任何编辑" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                    [alert show];
                    
                }else{
                    
                    self.addCount = 0;
                    [self.view addSubview:self.toolBar];
                    self.titleLabe.text = @"创建作品";
                    [self.rightBtn setTitle:@"发布" forState:UIControlStateNormal];

                }
                
                
                
            }else if (self.viewFlag == STYLEVIEW){
                [self cancelStyleView];
                
            }else if (self.viewFlag == EDITVIEW){
                
                
            }else if (self.viewFlag == HAVEADDED){
                [self makeSureAddedView];
                
            }else if(self.viewFlag == DELETEVIEW){
                [self sureDelete];
                
            }else if(self.viewFlag == WORDSTYLE){
                
                [self cancelShowWordStyle];
                
            }else if (self.viewFlag == IMAGEEDIT){
                
                [self sureToEditPhoto];
                
            }else{
                [self creatArticleToService];
            }

        }
            
            break;

            
        default:
            break;
    }
}

#pragma mark -- collection dataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.templeteViewM.count;
}


- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:creatCell forIndexPath:indexPath];
    
    if (nil == cell) {
        cell =  [[UICollectionViewCell alloc]init];
    }
    
    [cell.contentView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    templeteView *templete;
    if (self.collectionView.frame.origin.y<0){
        self.pinchRate = 0.8;
        templete = [[templeteView alloc]initWithFrame:CGRectMake((kWidth-(CGRectGetWidth(cell.contentView.frame)-20)*self.pinchRate)/2, (kHeight-(CGRectGetHeight(cell.contentView.frame)-10-40)*self.pinchRate)/2+fabsf((float)self.collectionView.frame.origin.y)/2, (CGRectGetWidth(cell.contentView.frame)-20)*self.pinchRate, (CGRectGetHeight(cell.contentView.frame)-10-40)*self.pinchRate-50)];
        
        
    }else{
        templete = [[templeteView alloc]initWithFrame:CGRectMake(10, 5, CGRectGetWidth(cell.contentView.frame)-20, CGRectGetHeight(cell.contentView.frame)-10-40)];
        self.pinchRate = 1.0;
    }

        templete.clipsToBounds = YES;
        templete.myDelegate = self;
        UILongPressGestureRecognizer *longPress= [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(longPressToDelete:)];
        [templete addGestureRecognizer:longPress];
        templete.userInteractionEnabled = YES;
    
    [self customLayoutTemplete:templete withIndex:[[self.templeteViewM[indexPath.row] objectForKey:kStyle] integerValue] withOrder:(int)indexPath.row rate:kHeight/667.0*self.pinchRate];
    
        [cell.contentView addSubview:templete];
        templete.tag = 3001+indexPath.row;
    
    return cell;
}

#pragma mark --UICollectionViewDelegateFlowLayout
//定义每个UICollectionView 大小
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
        return CGSizeMake(CGRectGetWidth(collectionView.frame), CGRectGetHeight(collectionView.frame));

    
}

-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}


////bottom bar
-(void)creatBottomBar
{
    _toolBar = [[UIToolbar alloc]initWithFrame:CGRectMake(0, kHeight-44-64, kWidth, 44)];
    
    UIBarButtonItem *wordBar = [[UIBarButtonItem alloc]initWithImage:[[UIImage imageNamed:@"ziti"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] style:UIBarButtonItemStylePlain target:self action:@selector(chooseToEdit:)];
    wordBar.tag = 2000;

    
    UIBarButtonItem *styleBar = [[UIBarButtonItem alloc]initWithImage:[[UIImage imageNamed:@"banshi1"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] style:UIBarButtonItemStylePlain target:self action:@selector(chooseToEdit:)];
    styleBar.tag = 2001;
    UIBarButtonItem *addView = [[UIBarButtonItem alloc]initWithImage:[[UIImage imageNamed:@"tianjiayemian1"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] style:UIBarButtonItemStylePlain target:self action:@selector(chooseToEdit:)];
    addView.tag = 2002;
    UIBarButtonItem *haveAdded = [[UIBarButtonItem alloc]initWithImage:[[UIImage imageNamed:@"yitianjia1"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] style:UIBarButtonItemStylePlain target:self action:@selector(chooseToEdit:)];
    haveAdded.tag = 2003;
    UIBarButtonItem *fixed = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    fixed.width = 24*kWidth/375;
    
    UIBarButtonItem *flexItem = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    
    self.toolBar.items = @[fixed,wordBar,flexItem,styleBar,flexItem,addView,flexItem,haveAdded,fixed];
    self.toolBar.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.toolBar];
    
}


#pragma mark -- choose one part

-(void)chooseToEdit:(UIBarButtonItem *)item
{
    switch (item.tag) {
        case 2000://word change
        {
            [self showWordStyle];
        }
            
            break;
        case 2001://style change
        {
            [self selectTemplete];
        }
            
            break;
        case 2002://to add
        {
            [self addNewPages];
        }
            
            break;
        case 2003://added
        {
            [self showAddedView];
        }
            
            break;

        default:
            break;
    }
}

//style Scrollview
-(void)creatBottomStyleView{
    
    float styleHeight = 150*kHeight/667;
    _templeteCover = [[UIView alloc]initWithFrame:CGRectMake(0, kHeight, kWidth, kHeight)];
//    self.templeteCover.backgroundColor = [UIColor whiteColor];

    _styleScrollview = [[UIScrollView alloc]initWithFrame:CGRectMake(0, kHeight-styleHeight-64-20, kWidth, styleHeight+18+20)];
    
    self.styleScrollview.contentSize = CGSizeMake(8*styleHeight*98/150, styleHeight+18);
    self.styleScrollview.showsVerticalScrollIndicator = NO;
    self.styleScrollview.showsHorizontalScrollIndicator = NO;
    self.styleScrollview.backgroundColor = [UIColor whiteColor];
    
    for (int i=0; i<8; i++) {
        UIImageView *imgView = [[UIImageView alloc]initWithFrame:CGRectMake((98*kWidth/375+10)*i, 10, 98*kWidth/375, 150*kHeight/667)];
        if (i==0) {
            imgView.layer.borderColor = [kColor(0, 216, 165) CGColor];
            imgView.layer.borderWidth = 2.0f;
            
        }
        imgView.image = [UIImage imageNamed:[NSString stringWithFormat:@"style%d",(i+1)]];
        imgView.userInteractionEnabled = YES;
        imgView.tag = 101+i;
        UITapGestureRecognizer *tapGes = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(selectStylePages:)];
        imgView.layer.borderColor = [[UIColor darkGrayColor] CGColor];
        imgView.layer.borderWidth = 2.0f;
        
        [imgView addGestureRecognizer:tapGes];
        
        [self.styleScrollview addSubview:imgView];
    }
    [self.templeteCover addSubview:self.styleScrollview];
    [self.view addSubview:self.templeteCover];
}


NSInteger styleTag = 101;//底部imageView.tag
-(void)selectStylePages:(UITapGestureRecognizer *)guesture
{
    UIImageView *imageView = (UIImageView*)[self.styleScrollview viewWithTag:styleTag];
    imageView.layer.borderColor = [[UIColor darkGrayColor] CGColor];
//    imageView.layer.borderWidth = 0.1f;
    
    guesture.self.view.layer.borderWidth = 2.0f;
    guesture.self.view.layer.borderColor = [kColor(0, 216, 165) CGColor];

    styleTag= guesture.self.view.tag;
    [self finishSelStyleTemplete];
    [self.collectionView reloadData];
    

    
}




NSInteger cellTag;
//sel teplete
-(void)selectTemplete
{
    
    //tag
    cellTag = (NSInteger)ceil(self.collectionView.contentOffset.x/self.collectionView.bounds.size.width)+3001;
    self.viewFlag = STYLEVIEW;
    self.titleLabe.text = @"版式";
    [self.rightBtn setTitle:@"完成" forState:UIControlStateNormal];
    float styleHeight = 150*kHeight/667;
    [self.toolBar removeFromSuperview];
    [UIView animateWithDuration:0.5f animations:^{
//        _styleScrollview.frame =CGRectMake(10, kHeight-styleHeight-15, kWidth-20, styleHeight+18);
        _templeteCover.frame = CGRectMake(0, 0, kWidth, kHeight);

        self.styleScrollview.contentSize = CGSizeMake(10*styleHeight*98/150, styleHeight+18);
        self.collectionView.frame = CGRectMake(0, 0-(150*kHeight/667-25), kWidth, kHeight); //CGRectMake(3, 20, kWidth-6, kHeight-150*kHeight/667-25);
        self.collectionView.scrollEnabled = NO;
        [self.collectionView reloadData];


    }];
    
}

-(void)finishSelStyleTemplete
{

    if (cellTag-3001!=0 ) {
        
        NSMutableDictionary *tempDic = [[NSMutableDictionary alloc]initWithDictionary:self.templeteViewM[cellTag-3001]];
        [tempDic setObject:[NSString stringWithFormat:@"%ld",styleTag-101+1] forKey:kStyle];
        if (![[self.templeteViewM[cellTag-3001] objectForKey:kTitle] length]) {
            [tempDic setObject:@"输入标题" forKey:kTitle];
        }
        
        if (![[self.templeteViewM[cellTag-3001] objectForKey:kContent] length]) {
            [tempDic setObject:@"输入内容" forKey:kContent];
        }
        switch (styleTag-100) {
            case 1:
            {
                [tempDic setObject:@2 forKey:kTitleLineNum];
                [tempDic setObject:@3 forKey:kContentLineNum];
            }
                break;
            case 2:
            {
                [tempDic setObject:@2 forKey:kTitleLineNum];
                [tempDic setObject:@7 forKey:kContentLineNum];
            }
                break;
            case 3:
            {
                [tempDic setObject:@2 forKey:kTitleLineNum];
                [tempDic setObject:@3 forKey:kContentLineNum];
            }
                break;
            case 4:
            {
                [tempDic setObject:@2 forKey:kTitleLineNum];
                [tempDic setObject:@13 forKey:kContentLineNum];
            }
                break;
            case 5:
            {
                [tempDic setObject:@2 forKey:kTitleLineNum];
                [tempDic setObject:@7 forKey:kContentLineNum];
            }
                break;
            case 6:
            {
                [tempDic setObject:@2 forKey:kTitleLineNum];
                [tempDic setObject:@13 forKey:kContentLineNum];
            }
                break;
            case 7:
            {
                [tempDic setObject:@0 forKey:kTitleLineNum];
                [tempDic setObject:@13 forKey:kContentLineNum];//改成与6一样的字数
            }
                break;
            case 8:
            {
                [tempDic setObject:@0 forKey:kTitleLineNum];
                [tempDic setObject:@0 forKey:kContentLineNum];
            }
                break;
                
            default:
                break;
        }
        
        [self.templeteViewM replaceObjectAtIndex:(cellTag-3001) withObject:tempDic];
        

    }else{
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"" message:@"作品首页不可更改版式" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    
    
}

-(void)cancelStyleView
{
    self.titleLabe.text = @"创建作品";
    [self.rightBtn setTitle:@"发布" forState:UIControlStateNormal];
    self.viewFlag = DEFAULTVIEW;
    [UIView animateWithDuration:0.5f animations:^{
        //float styleHeight = 150*kHeight/667;
        self.collectionView.frame = CGRectMake(0, 0, kWidth, kHeight); //CGRectMake(3, 0, kWidth-4, kHeight);
        //self.styleScrollview.frame = CGRectMake(10, kHeight, kWidth-20, styleHeight+15);
        self.templeteCover.frame = CGRectMake(0, kHeight, kWidth, kHeight);
        self.collectionView.scrollEnabled = YES;
        [self.view addSubview:self.toolBar];
    }];
    [self.collectionView reloadData];

}


//add new page
-(void)addNewPages
{
    //CGPoint center = self.collectionView.center;
    self.collectionView.frame = CGRectMake(0, 0, kWidth, kHeight); //CGRectMake(3, 0, kWidth-4, kHeight);
    [self.collectionView reloadData];
    self.titleLabe.text = @"添加页面";
    [self.rightBtn setTitle:@"完成" forState:UIControlStateNormal];
    self.viewFlag = ADDNEWVIEW;
    [self.toolBar removeFromSuperview];
    int tag = ceil(self.collectionView.contentOffset.x/self.collectionView.bounds.size.width);
    NSDictionary *addDic =@{kImage:[UIImage imageNamed:@"default"],
                             kStyle:@"0",
                             kTitle:@"输入文本",
                             kContent:@"输入内容"};
    [self.templeteViewM insertObject:addDic atIndex:tag+1];
    self.insertFlag = tag+1;
    [self.collectionView reloadData];
    [self.view addSubview:self.toolBar];
    [UIView animateWithDuration:0.5f animations:^{
        
    self.collectionView.contentOffset = CGPointMake((tag+1)*CGRectGetWidth(self.collectionView.frame), 0);

    }];
    
    
}

-(void)cancelAddNewPage
{
    [self.view addSubview:self.toolBar];
    self.viewFlag = DEFAULTVIEW;
    self.titleLabe.text = @"创建作品";
    [self.rightBtn setTitle:@"发布" forState:UIControlStateNormal];
    
    if (self.addCount == 0) {
        
        int tag = ceil(self.collectionView.contentOffset.x/self.collectionView.bounds.size.width);
        [UIView animateWithDuration:0.5f animations:^{
            
            self.collectionView.contentOffset = CGPointMake((tag-1)*CGRectGetWidth(self.collectionView.frame), 0);
        }];
         [self.templeteViewM removeObjectAtIndex:self.insertFlag];
        
        
    }else{
        for (int i =0; i<self.addCount; i++) {
            [self.templeteViewM removeObjectAtIndex:self.insertFlag+i];
        }

    }
    
    
    [self.collectionView reloadData];
    
}


#pragma mark -- templete Delegate

//take one photo once
-(void)tapToChangePhoto:(UITapGestureRecognizer*)gesture
{
    ObtainPictureViewController *obtainVC = [[ObtainPictureViewController alloc]init];
    obtainVC.loopFlag = kReplaceOnePic;
    NSString *path = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)[0] stringByAppendingPathComponent:kOriginalPhotoImages];
    NSInteger tempTag =(NSInteger)ceil((self.collectionView.contentOffset.x/self.collectionView.bounds.size.width));
    
    [obtainVC returnNewPhoto:^(NSArray *photoArr) {
        
            NSString *photoPath = [path stringByAppendingPathComponent:[photoArr[0] objectForKey:kImgName]];
            NSDictionary *tempDic = @{kImage:[UIImage imageWithContentsOfFile:photoPath],
                                      kStyle:@"1",
                                      kTitle:@"输入标题",
                                      kContent:@"输入内容"};
        [self.templeteViewM replaceObjectAtIndex:tempTag withObject:tempDic];
        
        [self.collectionView reloadData];
        
    }];
    
    [self.navigationController pushViewController:obtainVC animated:YES];
}
//loop to edit vc and add new words
-(void)pressToAddWords
{
    EditViewController *editVC = [[EditViewController alloc]init];
    
    [editVC returnEditedText:^(NSDictionary *textDic) {
        [self.templeteViewM removeObjectAtIndex:self.insertFlag];

        self.titleLabe.text = @"创建作品";
        [self.rightBtn setTitle:@"发布" forState:UIControlStateNormal];
        self.viewFlag = DEFAULTVIEW;
        
        NSDictionary *dic;
        if (![[textDic objectForKey:@"title"] length]) {
            int num = ceil([[textDic objectForKey:@"content"] length]/154.0);
            for (int i =0; i<num ; i++) {
                NSString *subText =  [[textDic objectForKey:@"content"] substringWithRange:NSMakeRange(i*154, ([[textDic objectForKey:@"content"] length]-i*154)>153?153:[[textDic objectForKey:@"content"] length]-i*154)];
            dic = @{kImage:[UIImage imageNamed:@"default"],
                        kStyle:@"7",
                        kTitle:[textDic objectForKey:@"title"],
                        kContent:subText,
                    kTitleLineNum:@0,
                    kContentLineNum:@13
                        };
            [self.templeteViewM insertObject:dic atIndex:self.insertFlag+i];

            }

            

            
        }else{
            
            int num = (int)ceil([[textDic objectForKey:@"content"] length]/154.0);
            for (int i =0; i<num ; i++) {
                NSString *subText =  [[textDic objectForKey:@"content"] substringWithRange:NSMakeRange(i*154, ([[textDic objectForKey:@"content"] length]-i*154)>153?153:[[textDic objectForKey:@"content"] length]-i*154)];
                dic = @{kImage:[UIImage imageNamed:@"default"],
                        kStyle:@"6",
                        kTitle:[textDic objectForKey:@"title"],
                        kContent:subText,
                        kTitleLineNum:@2,
                        kContentLineNum:@13
        
                        };

                [self.templeteViewM insertObject:dic atIndex:self.insertFlag+i];
                
            }

            
        }
        
        
        [self.collectionView reloadData];
        
    }];
    
    [self.navigationController pushViewController:editVC animated:YES];
}

//loop to album vc and add new photos
-(void)tapToAddNewPages:(UITapGestureRecognizer *)gesture
{

    [self.templeteViewM removeObjectAtIndex:self.insertFlag];
    ObtainPictureViewController *obtainVC = [[ObtainPictureViewController alloc]init];
    obtainVC.loopFlag = kAddPhotos;
    //图片存储路径
    NSString *path = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)[0] stringByAppendingPathComponent:kOriginalPhotoImages];
    

    [obtainVC returnNewPhoto:^(NSArray *photoArr) {
        
        self.addCount = photoArr.count;
        for (int i=0; i<photoArr.count; i++) {
        
            NSString *photoPath = [path stringByAppendingPathComponent:[photoArr[i] objectForKey:kImgName]];
         NSDictionary *tempDic = @{kImage:[UIImage imageWithContentsOfFile:photoPath],
                                  kStyle:@"1",
                                  kTitle:@"输入标题",
                                  kContent:@"输入内容",
                            kTitleLineNum:@2,
                            kContentLineNum:@3};
            [self.templeteViewM insertObject:tempDic atIndex:self.insertFlag+i];
        
        }
        [self.collectionView reloadData];
        
    }];
    [self.navigationController pushViewController:obtainVC animated:YES];

    
}

//long press delete
-(void)longPressToDelete:(UILongPressGestureRecognizer *)longPress
{
    
    int delTag = self.collectionView.contentOffset.x/self.collectionView.bounds.size.width;
    if (longPress.state == UIGestureRecognizerStateBegan) {
        
        if (delTag != 0) {
          
            self.titleLabe.text = @"删除页面";
            [self.rightBtn setTitle:@"确定" forState:UIControlStateNormal];
            self.viewFlag = DELETEVIEW;
            [self.toolBar removeFromSuperview];
            [UIView animateWithDuration:0.5f animations:^{
                
                self.collectionView.frame = CGRectMake(0, 0-(150*kHeight/667-25), kWidth, kHeight);
                [self.collectionView reloadData];
            }];
            self.collectionView.scrollEnabled = NO;

            [self.view addSubview:self.deleteCover];

        }

        
    }

}

#pragma mark -- imgview delegate
-(void)editPhoto
{
    self.viewFlag = IMAGEEDIT;
    self.titleLabe.text = @"编辑图片";
    [self.rightBtn setTitle:@"完成" forState:UIControlStateNormal];
}



#pragma mark -- sure or cancel
#pragma mark -- 4 parts


-(void)sureDelete
{
    self.titleLabe.text = @"创建作品";
    [self.rightBtn setTitle:@"发布" forState:UIControlStateNormal];
    self.viewFlag = DEFAULTVIEW;
    [self.deleteCover removeFromSuperview];
    [UIView animateWithDuration:0.5f animations:^{
        
        self.collectionView.frame = CGRectMake(0, 0, kWidth, kHeight); //CGRectMake(3, 0, kWidth-4, kHeight);
        self.collectionView.scrollEnabled = YES;
        [self.collectionView reloadData];
        [self.view addSubview:self.toolBar];
    }];
   
}

-(void)cancelDelete
{
    self.titleLabe.text = @"创建作品";
    [self.rightBtn setTitle:@"发布" forState:UIControlStateNormal];
    self.viewFlag = DEFAULTVIEW;
    [self.deleteCover removeFromSuperview];
    [UIView animateWithDuration:0.5f animations:^{
        
        self.collectionView.frame = CGRectMake(0, 0, kWidth, kHeight); //CGRectMake(3, 0, kWidth-4, kHeight);
        self.collectionView.scrollEnabled = YES;
        [self.collectionView reloadData];
        [self.view addSubview:self.toolBar];
    }];
    [self.collectionView reloadData];

}

#pragma mark --



//delete button click
-(void)deleteView
{
    int delTag = self.collectionView.contentOffset.x/self.collectionView.bounds.size.width;
    [self.templeteViewM removeObjectAtIndex:delTag];
    self.collectionView.scrollEnabled = YES;
    [self.deleteCover removeFromSuperview];
    [self cancelDelete];
    [self.collectionView reloadData];
}


//WORD STYLE
-(void)showWordStyle
{
    self.viewFlag = WORDSTYLE;
    self.titleLabe.text = @"选择字体";
    [self.rightBtn setTitle:@"完成" forState:UIControlStateNormal];
    [self.toolBar removeFromSuperview];
    UIWindow *window = [[[UIApplication sharedApplication]delegate] window];
    [window addSubview:self.wordsCover];
    
    [UIView animateWithDuration:0.5f animations:^{
        
        self.collectionView.frame = CGRectMake(0, 0-(295*kHeight/667-20), kWidth, kHeight);

        [self.collectionView reloadData];//0821
    }];
    self.collectionView.scrollEnabled = NO;
   

}

-(void)cancelShowWordStyle
{
    [self.view addSubview:self.toolBar];
    self.viewFlag = DEFAULTVIEW;
    self.titleLabe.text = @"创建作品";
    [self.rightBtn setTitle:@"发布" forState:UIControlStateNormal];
    [self.wordsCover removeFromSuperview];
    
    
    [UIView animateWithDuration:0.5f animations:^{
        
        self.collectionView.frame = CGRectMake(0, 0, kWidth, kHeight);
        [self.collectionView reloadData];
        
    }];
    self.collectionView.scrollEnabled = YES;

}


//确定按钮
-(void)makeSureSelectWordStyle
{

    [self cancelShowWordStyle];
    //to do some ziti select
}

//download
-(void)downloadWordsStyle:(UIButton *)sender
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:self.downWordsM[sender.tag-301]];
    if ([[dic objectForKey:isDownload] boolValue]) {
        [dic setObject:@NO forKey:isDownload];//需要删除本地文件
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:[dic objectForKey:kRealWordsName]];
        [[NSUserDefaults standardUserDefaults] synchronize];
        [self.downWordsM replaceObjectAtIndex:(sender.tag-301) withObject:dic];
        [self.downloadView reloadData];
        
    }else{



        [self asynchronouslySetFontName:[dic objectForKey:kRealWordsName] index:(sender.tag-301) button:sender];
       

        
        
    }
    
    
}



//haveAdded
-(void)layoutHaveAddedView
{
    [self.haveAdddedScrollView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    self.haveAdddedScrollView.contentSize = CGSizeMake((self.templeteViewM.count+2)*(150*kHeight/667)*98/150,CGRectGetHeight(self.addedBgView.frame));
    if (_alreadyCountLabel == nil) {
        _alreadyCountLabel = [[UILabel alloc]initWithFrame:CGRectMake(5, 2, kWidth, 15)];
    }
    
    self.alreadyCountLabel.text = [NSString stringWithFormat:@"已添加%ld页",self.templeteViewM.count];
    self.alreadyCountLabel.textColor = kColor(74, 74, 74);
    self.alreadyCountLabel.textAlignment = NSTextAlignmentLeft;
    self.alreadyCountLabel.font = [UIFont fontWithName:kHeitiSC size:13.0f];
    [self.addedBgView addSubview:self.alreadyCountLabel];
    for (int i =0; i<self.templeteViewM.count; i++) {
        
        templeteView *templete = [[templeteView alloc]initWithFrame:CGRectMake((10+98*kWidth/375)*i, 30, 98*kWidth/375, 150*kHeight/667-30)];
        templete.userInteractionEnabled = NO;
        templete.clipsToBounds = YES;
        [self customLayoutTemplete:templete withIndex:[[self.templeteViewM[i] objectForKey:kStyle] integerValue] withOrder:i rate:0.25f*0.7];
        templete.imgView.userInteractionEnabled = NO;
        self.haveAdddedScrollView.userInteractionEnabled = YES;
        
        if (i==0) {
            self.coverCropImage = nil;
            self.coverCropImage = [UIImage imageCaptureWithRect:templete.frame view:templete];
            
        }
        //delete button
        if (i != 0) {
            
            UIButton *deleBtn = [[UIButton alloc]initWithFrame:CGRectMake((CGRectGetWidth(templete.frame)-20)/2+i*(CGRectGetWidth(templete.frame)+10), CGRectGetMaxY(templete.frame)+5, 20, 20)];
            [deleBtn setImage:[UIImage imageNamed:@"delete"] forState:UIControlStateNormal];
            [deleBtn addTarget:self action:@selector(deleteAddedView:) forControlEvents:UIControlEventTouchUpInside];
            deleBtn.tag = 501+i;
            [self.haveAdddedScrollView addSubview:deleBtn];

        }
        
        [self.haveAdddedScrollView addSubview:templete];
        
        
    }
}

//added pages

-(void)showAddedView
{
    self.titleLabe.text = @"已添加";
    [self.rightBtn setTitle:@"完成" forState:UIControlStateNormal];
    self.viewFlag = HAVEADDED;
    
    [self layoutHaveAddedView];
    
    
    [UIView animateWithDuration:0.5f animations:^{
        
        self.collectionView.frame = CGRectMake(0, 0-(150*kHeight/667-25), kWidth, kHeight);
        [self.collectionView reloadData];
    }];
    [self.toolBar removeFromSuperview];
    
    [self.view addSubview:self.addedCover];//0810
}

-(void)deleteAddedView:(UIButton *)sender
{
    
    [self.templeteViewM removeObjectAtIndex:sender.tag-501];
    [sender removeFromSuperview];
    [self layoutHaveAddedView];
    [self.view addSubview:self.addedCover];//0810
    
}

//added view make sure
-(void)makeSureAddedView
{
    self.viewFlag = DEFAULTVIEW;
    self.titleLabe.text = @"创建作品";
    [self.rightBtn setTitle:@"发布" forState:UIControlStateNormal];
    [self.addedCover removeFromSuperview];
    [UIView animateWithDuration:0.5f animations:^{
        
        self.collectionView.frame = CGRectMake(0, 0, kWidth, kHeight); //CGRectMake(3, 0, kWidth-4, kHeight);
        [self.collectionView reloadData];
        self.collectionView.scrollEnabled = YES;
        [self.view addSubview:self.toolBar];
    }];
    
    [self.collectionView reloadData];
    
}


//edit image make sure
-(void)sureToEditPhoto
{
    self.viewFlag = DEFAULTVIEW;
    self.titleLabe.text = @"创建作品";
    [self.rightBtn setTitle:@"发布" forState:UIControlStateNormal];
    int tempTag = (int)ceil(self.collectionView.contentOffset.x/self.collectionView.bounds.size.width)+3001;
    templeteView *templete = (templeteView*)[self.collectionView viewWithTag:tempTag];
    [templete.imgView endEditPhoto];
    
    UIImage *finishedImg = [UIImage imageCapture:templete.imgView];
    
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:self.templeteViewM[tempTag-3001]];
    [dic setObject:finishedImg forKey:kImage];
    [self.templeteViewM replaceObjectAtIndex:tempTag-3001 withObject:dic];
    [self.collectionView reloadData];
}

-(void)cancelToEditPhoto
{
    self.viewFlag = DEFAULTVIEW;
    self.titleLabe.text = @"创建作品";
    [self.rightBtn setTitle:@"发布" forState:UIControlStateNormal];
    [self.collectionView reloadData];
    
}


#pragma  mark -- table delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.downWordsM.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *downCell = @"downCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:downCell];
    
    if (nil == cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:downCell];
    }
    

    UIButton *nameBtn = [[UIButton alloc]initWithFrame:CGRectMake((kWidth-100)/2, 0, 100, 54)];
    if ([[self.downWordsM[indexPath.row] objectForKey:isDownload] boolValue]&&[[self.downWordsM[indexPath.row] objectForKey:isSelStyle] boolValue]) {
        [nameBtn setImage:[UIImage imageNamed:[self.downWordsM[indexPath.row] objectForKey:kWordsNameSel]] forState:UIControlStateNormal];
        cell.imageView.image = [UIImage imageNamed:@"right"];
    }else{
        
        [nameBtn setImage:[UIImage imageNamed:[self.downWordsM[indexPath.row] objectForKey:kWordsName]]forState:UIControlStateNormal];
        cell.imageView.image = nil;
    }
   
    [cell.contentView addSubview:nameBtn];
    //selBtn
    
    
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 22, 22)];
    
    if ([[self.downWordsM[indexPath.row] objectForKey:isDownload] boolValue]) {
        btn.backgroundColor =[UIColor whiteColor];
        btn.layer.borderColor = [kColor(216, 216, 216) CGColor];
        btn.layer.borderWidth = 1.0f;
        [btn setImage:[UIImage imageNamed:@"shanchu"] forState:UIControlStateNormal];
    }else{
        btn.backgroundColor = kColor(0, 216, 165);
        [btn setImage:[UIImage imageNamed:@"xiazai"] forState:UIControlStateNormal];
        btn.layer.borderWidth = 0.0f;
    }
    btn.tag = indexPath.row+301;
    [btn addTarget:self action:@selector(downloadWordsStyle:) forControlEvents:UIControlEventTouchUpInside];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.accessoryView = btn;
    return cell;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50.0f;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 60.0f;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *backView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kWidth, 60)];
    backView.backgroundColor = [UIColor whiteColor];
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake((kWidth-120)/2, 5, 120, 20)];
    label.font = [UIFont systemFontOfSize:13.0f];
    label.text= @"作品已选用黑体";
    label.textAlignment = NSTextAlignmentCenter;
    label.backgroundColor = kColor(0, 216, 165);
    label.textColor = [UIColor whiteColor];
    [backView addSubview:label];
    
    UIButton *sureBtn = [[UIButton alloc]initWithFrame:CGRectMake(CGRectGetMaxX(backView.frame)-60, 0, 50, 40)];
    [sureBtn setTitle:@"确定" forState:UIControlStateNormal];
    [sureBtn setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
    sureBtn.titleLabel.font = [UIFont fontWithName:kHeitiSC size:13.0f];
    sureBtn.backgroundColor = [UIColor whiteColor];
    [sureBtn addTarget:self action:@selector(makeSureSelectWordStyle) forControlEvents:UIControlEventTouchUpInside];
     [backView addSubview:sureBtn];
    UIButton *wordName = [[UIButton alloc]initWithFrame:CGRectMake(50, CGRectGetHeight(backView.frame)-20, kWidth-100, 20)];

    [wordName setImage:[UIImage imageNamed:@"heitiSel"] forState:UIControlStateNormal];
    [backView addSubview:wordName];
    
    UIButton *imgBtn = [[UIButton alloc]initWithFrame:CGRectMake(15, CGRectGetMinY(wordName.frame), 20, 20)];
    imgBtn.tag = 30;
    imgBtn.backgroundColor =[UIColor whiteColor];
    if (isHtiSel) {
       [imgBtn setImage:[UIImage imageNamed:@"right"] forState:UIControlStateNormal];
    }else{
        [imgBtn setImage:nil forState:UIControlStateNormal];
    }
    
    [imgBtn addTarget:self action:@selector(selHei:) forControlEvents:UIControlEventTouchUpInside];
    [backView addSubview:imgBtn];
    
    return backView;
}

 NSInteger selTypeFace = 0;
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:self.downWordsM[indexPath.row]];
    if ([[dic objectForKey:isDownload] boolValue]) {
       
#pragma warning 这样做在数据少的情况下可以，多了会影响效率，应该记录上一个选中的字体，由于第一个在header当中所以暂时这么做了，之后再改进
        for (int i=0; i<self.downWordsM.count; i++) {
            NSMutableDictionary *dicM = [NSMutableDictionary dictionaryWithDictionary:self.downWordsM[i]];
            [dicM setObject:@NO forKey:isSelStyle];
            [self.downWordsM replaceObjectAtIndex:i withObject:dicM];
        }
        
        isHtiSel = NO;
        
        
        [dic setObject:@YES forKey:isSelStyle];
        
            if ([self isFontDownloaded:[dic objectForKey:kRealWordsName]]) {
            [UserSingleton shareUserSingleton].fontName = [dic objectForKey:kRealWordsName];
            [self.downWordsM replaceObjectAtIndex:indexPath.row withObject:dic];
            [self.downloadView reloadData];
            [self.collectionView reloadData];

        }else{
            
            [self matchingFontWithFontName:[dic objectForKey:kRealWordsName] dictionary:(NSDictionary*)dic index:indexPath.row];
        }

        

    }

}


-(void)selHei:(UIButton*)sender
{
    if (!isHtiSel) {
        
        for (int i=0; i<self.downWordsM.count; i++) {
                NSMutableDictionary *dicM = [NSMutableDictionary dictionaryWithDictionary:self.downWordsM[i]];
                [dicM setObject:@NO forKey:isSelStyle];
                [self.downWordsM replaceObjectAtIndex:i withObject:dicM];
            }

        isHtiSel = YES;
        [UserSingleton shareUserSingleton].fontName = kHeitiSC;
    }
    [self.downloadView reloadData];
    [self.collectionView reloadData];
}

#pragma mark -- creat article service data
-(void)creatArticleToService
{
    [self layoutHaveAddedView];
    NSData *coverData = UIImageJPEGRepresentation(self.coverCropImage, 1.0);

    [MBProgressHUD showMessage:@"正在创建作品,请稍后..." toView:[[UIApplication sharedApplication]keyWindow]];
    NSString *strUrl = [NSString stringWithFormat:@"%@%@",HOST,@"works/add"];//host
   
    NSMutableArray  *titleArr = [NSMutableArray array];
    NSMutableArray *contentArr = [NSMutableArray array];
    NSMutableArray *styleArr = [NSMutableArray array];
    for (NSDictionary *dic in self.templeteViewM) {
        [titleArr addObject:[dic objectForKey:kTitle]];
        [contentArr addObject:[dic objectForKey:kContent]];
        [styleArr addObject:[dic objectForKey:kStyle]];
        
    }
    
    
    NSDictionary *para = @{kAuthCode:[[NSUserDefaults standardUserDefaults]objectForKey:kAuthCode],
                        kDeviceToken:[[NSUserDefaults standardUserDefaults]objectForKey:kDeviceToken],
                          @"topicId": [NSNumber numberWithInteger: [self.topicIdFromCreat integerValue]],
                       @"worksTitle":titleArr,
                     @"worksContent":contentArr,
                            @"plate":styleArr
                        
                           };//coverImage
    

    
    NSMutableDictionary *dicPar = [NSMutableDictionary dictionary];
        [dicPar addEntriesFromDictionary:para];

        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        [manager POST:strUrl parameters:para constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
            
            for (int i=0; i<self.templeteViewM.count; i++) {
                NSData *originData = UIImageJPEGRepresentation([self.templeteViewM[i] objectForKey:kImage], 1.0f);
                NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
                [formatter setDateFormat:@"YYYY-MM-dd hh:mm:ss"];
                NSString *date = [formatter stringFromDate:[NSDate date]];

                [formData appendPartWithFileData:originData name:@"logoImage" fileName:[NSString stringWithFormat:@"%@%@",date,@"logoImage"] mimeType:@"image/jpeg"];//
                
                if (i==0) {
                    [formData appendPartWithFileData:coverData name:@"coverImage" fileName:[NSString stringWithFormat:@"%@cover",date] mimeType:@"image/jpeg"];
                }

            }
            

            
        } success:^(AFHTTPRequestOperation *operation, id responseObject) {
            [MBProgressHUD hideHUDForView:[[UIApplication sharedApplication]keyWindow]];
            
            if ([[responseObject objectForKey:@"code"]intValue] == 1) {
                
                if (![[responseObject objectForKey:@"data"]isEqual:[NSNull null]]) {
                    PublishingSuccessViewController *publish=[[PublishingSuccessViewController alloc]init];
                    publish.creatArticleId = [[responseObject objectForKey:@"data"] objectForKey:@"id"];
                    publish.creatTopicId = self.topicIdFromCreat;
                    [self.navigationController pushViewController:publish animated:YES];

                }
            }else{
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[responseObject objectForKey:@"msg"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                [alert show];

            }
            NSLog(@"creat article:%@ msg:%@",responseObject,[responseObject objectForKey:@"msg"]);
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSLog(@"creat article error:%@",error);
            [MBProgressHUD hideHUDForView:[[UIApplication sharedApplication]keyWindow]];
            UIWindow *window = [[UIApplication sharedApplication] keyWindow];
            [MyAlertView showMessageToView:window];
            
        }];
    }

#pragma mark -- textViewDelegate

-(void)textViewDidBeginEditing:(UITextView *)textView
{

    if (self.collectionView.frame.origin.y >= 0) {
        [UIView animateWithDuration:0.5f animations:^{
        
            self.collectionView.frame = CGRectMake(0, 0-216, kWidth, kHeight);
                
        }];

        [self.collectionView reloadData];
    }
    

    int viewTag = (int)ceil(self.collectionView.contentOffset.x/kWidth)+3001;
    templeteView *templete = (templeteView*)[self.collectionView viewWithTag:viewTag];

    if (textView == templete.titleView) {
        if ([textView.text isEqualToString:@"输入标题"]) {
            
            textView.text = @"";
        }
    }else{

        if ([textView.text isEqualToString:@"输入内容"]) {
            
            textView.text = @"";
        }

    }
    
    
}



-(void)textViewDidEndEditing:(UITextView *)textView
{
    
    NSInteger viewTag = (NSInteger) ceil (self.collectionView.contentOffset.x/kWidth)+3001;
    templeteView *templete = (templeteView*)[self.collectionView viewWithTag:viewTag];
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:self.templeteViewM[viewTag-3001]];
    
    if (textView == templete.titleView ) {
        if (textView.text.length) {
           [dic setObject:textView.text forKey:kTitle];
        }else{
            [dic setObject:@"输入标题" forKey:kTitle];
            //[textView resignFirstResponder];
        }
        
        [self.templeteViewM replaceObjectAtIndex:viewTag-3001 withObject:dic];
        
    }else{
        
        if (textView.text.length) {
           [dic setObject:textView.text forKey:kContent];
        }else{
            [dic setObject:@"输入内容" forKey:kContent];
        }
        [self.templeteViewM replaceObjectAtIndex:viewTag-3001 withObject:dic];
        [self.collectionView reloadData];
        [textView resignFirstResponder];
        textView.scrollEnabled = NO;

    }


    
}

-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    textView.scrollsToTop = YES;
    NSInteger viewTag = (NSInteger)ceil(self.collectionView.contentOffset.x/self.collectionView.bounds.size.width)+3001;
    templeteView *templete = (templeteView*)[self.collectionView viewWithTag:viewTag];
        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:self.templeteViewM[viewTag-3001]];
    if (textView == templete.titleView) {
        if (textView.contentSize.height >([[dic objectForKey:kTitleLineNum] intValue]*2)*24.0) {
            textView.text = [textView.text substringToIndex:[textView.text length]-1];
            return NO;
        }
    }else{
        if (textView.contentSize.height >([[dic objectForKey:kContentLineNum] intValue]*2+1)*13.0 ) {
            //删除最后一行的第一个字符，以便减少一行。
            textView.text = [textView.text substringToIndex:[textView.text length]-1];
            return NO;
        }
    }
    
    return YES;
}

#pragma mark -- custom layout
-(void)customLayoutTemplete:(templeteView*)templete withIndex:(NSInteger)index withOrder:(int)orderNum rate:(float)rate
{
    UIView *inputView = [self buildTextAccessoryView];
    switch (index) {
        case 1:
        {
            [templete buildStyle1WithImage:[self.templeteViewM[orderNum]objectForKey:kImage ] textColer:kColor(74, 74, 74) title:[self.templeteViewM[orderNum] objectForKey:kTitle] content:[self.templeteViewM[orderNum]objectForKey:kContent] vc:self fontRate:rate];
            templete.imgView.delegate = self;
            templete.titleView.inputAccessoryView = inputView;
            templete.contentView.inputAccessoryView = inputView;
        }
            break;
        case 2:
        {
            [templete buildStyle2WithImage:[self.templeteViewM[orderNum]objectForKey:kImage ] textColer:kColor(74, 74, 74) title:[self.templeteViewM[orderNum] objectForKey:kTitle] content:[self.templeteViewM[orderNum]objectForKey:kContent] vc:self fontRate:rate];
            templete.imgView.delegate = self;
            templete.titleView.inputAccessoryView = inputView;
            templete.contentView.inputAccessoryView = inputView;

        }
            break;
            
        case 3:
        {
            [templete buildStyle3WithImage:[self.templeteViewM[orderNum]objectForKey:kImage ] textColer:kColor(74, 74, 74) title:[self.templeteViewM[orderNum] objectForKey:kTitle] content:[self.templeteViewM[orderNum] objectForKey:kContent] vc:self fontRate:rate];
            templete.imgView.delegate = self;
            templete.titleView.inputAccessoryView = inputView;
            templete.contentView.inputAccessoryView = inputView;

        }
            
            break;
        case 4:
        {
            [templete buildStyle4WithImage:[self.templeteViewM[orderNum]objectForKey:kImage ] textColer:[UIColor whiteColor] title:[self.templeteViewM[orderNum] objectForKey:kTitle] content:[self.templeteViewM[orderNum] objectForKey:kContent] vc:self fontRate:rate];
            templete.imgView.delegate = self;
            templete.titleView.inputAccessoryView = inputView;
            templete.contentView.inputAccessoryView = inputView;

        }
            
            break;
        case 5:
        {
            
            [templete buildStyle5WithTextColer:kColor(74, 74, 74) title:[self.templeteViewM[orderNum]objectForKey:kTitle] content:[self.templeteViewM[orderNum]objectForKey:kContent] fontRate:rate vc:self];
            templete.titleView.inputAccessoryView = inputView;
            templete.contentView.inputAccessoryView = inputView;

        }
            
            break;
            
        case 6:
        {
            
            [templete buildStyle6WithTextColer:kColor(74, 74, 74) title:[self.templeteViewM[orderNum]objectForKey:kTitle] content:[self.templeteViewM[orderNum] objectForKey:kContent] fontRate:rate vc:self];
            templete.titleView.inputAccessoryView = inputView;
            templete.contentView.inputAccessoryView = inputView;

        }
            
            break;
        case 7:
        {
            
            [templete buildStyle7WithTextColer:kColor(74, 74, 74) title:[self.templeteViewM[orderNum]objectForKey:kTitle]content:[self.templeteViewM[orderNum]objectForKey:kContent]fontRate:rate vc:self];
            templete.contentView.inputAccessoryView = inputView;

        }
            
            break;
            
        case 8:
        {
            [templete buildStyle8WithImage:[self.templeteViewM[orderNum]objectForKey:kImage] vc:self];
            templete.imgView.delegate = self;
        }
            
            break;
            
        case 0:
        {
            [templete addNewPagesWithVC:self];
        }
            break;
        default:
            break;
    }

}



-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    UIWindow *window = [[UIApplication sharedApplication] keyWindow];
    [window endEditing:YES];
    [UIView animateWithDuration:0.5f animations:^{
        
        self.collectionView.frame = CGRectMake(0, 0, kWidth, kHeight);//CGRectMake(3, 5, kWidth-4, kHeight);
        [self.wordsCover removeFromSuperview];
        _templeteCover.frame = CGRectMake(0, kHeight, kWidth, kHeight);
        [_deleteCover removeFromSuperview];
        [_addedCover removeFromSuperview];
        [self.view addSubview:self.toolBar];
        [self.leftBtn setTitle:@"取消" forState:UIControlStateNormal];
        [self.rightBtn setTitle:@"发布" forState:UIControlStateNormal];
        self.viewFlag = DEFAULTVIEW;
        self.titleLabe.text = @"创建作品";
        [self.rightBtn setTitle:@"发布" forState:UIControlStateNormal];
        [self.collectionView reloadData];
    }];

}

#pragma mark -- 键盘
- (UIView *)buildTextAccessoryView  {
    //增加一个inputAccessory，可以点击返回键盘
    
    UIView *inputView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kWidth, 30)];
    inputView.backgroundColor = [UIColor whiteColor];
    UIButton *doneBtn = [[UIButton alloc]initWithFrame:CGRectMake(kWidth-80, 1, 70, 28)];
    [doneBtn setTitle:@"完成" forState:UIControlStateNormal];
    doneBtn.backgroundColor = kColor(0, 216, 216);
    [doneBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    doneBtn.titleLabel.font = [UIFont boldSystemFontOfSize:15.0f];
    [doneBtn addTarget:self action:@selector(resignKeyBoard) forControlEvents:UIControlEventTouchUpInside];
    [inputView addSubview:doneBtn];
    return inputView;
}

-(void)resignKeyBoard
{
   UIWindow *window  = [[UIApplication sharedApplication] keyWindow];
    [window endEditing:YES];

    [UIView animateWithDuration:0.5f animations:^{
        
        self.collectionView.frame = CGRectMake(0, 0, kWidth, kHeight);//CGRectMake(3, 5, kWidth-4, kHeight);
        [self.collectionView reloadData];
        
    }];


}


#pragma mark -- Download typeface
#pragma mark -- 为了方便同样的代码逻辑拆开写了两次

- (void)asynchronouslySetFontName:(NSString *)fontName  index:(NSInteger)index button:(UIButton *)btn
{
    UIFont* aFont = [UIFont fontWithName:fontName size:12.0f];
        if (aFont && ([aFont.fontName compare:fontName] == NSOrderedSame || [aFont.familyName compare:fontName] == NSOrderedSame)) {
        
        return;
    }
    
    NSMutableDictionary *attrs = [NSMutableDictionary dictionaryWithObjectsAndKeys:fontName, kCTFontNameAttribute, nil];
    
    // Create a new font descriptor reference from the attributes dictionary.
    CTFontDescriptorRef desc = CTFontDescriptorCreateWithAttributes((__bridge CFDictionaryRef)attrs);
    
    NSMutableArray *descs = [NSMutableArray arrayWithCapacity:0];
    [descs addObject:(__bridge id)desc];
    CFRelease(desc);
    
    __block BOOL errorDuringDownload = NO;
    
    
    CTFontDescriptorMatchFontDescriptorsWithProgressHandler( (__bridge CFArrayRef)descs, NULL,  ^(CTFontDescriptorMatchingState state, CFDictionaryRef progressParameter) {
        
        double progressValue = [[(__bridge NSDictionary *)progressParameter objectForKey:(id)kCTFontDescriptorMatchingPercentage] doubleValue];
        
        if (state == kCTFontDescriptorMatchingDidBegin) {
            dispatch_async( dispatch_get_main_queue(), ^ {
                [btn addSubview:self.fProgressView];
                
                NSLog(@"Begin Matching");
            });
        } else if (state == kCTFontDescriptorMatchingDidFinish) {
            dispatch_async( dispatch_get_main_queue(), ^ {
                
                if (!errorDuringDownload) {
                    NSLog(@"%@ downloaded", fontName);
                    dispatch_async( dispatch_get_main_queue(), ^ {

                        _fProgressView.hidden = YES;
                        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:self.downWordsM[index]];
                        [dic setValue:@YES forKey:isDownload];
                        [[NSUserDefaults standardUserDefaults] setBool:@YES forKey:[NSString stringWithFormat:@"%@%@",fontName,@"IsD"]];
                        [[NSUserDefaults standardUserDefaults] synchronize];
                        [self.downWordsM replaceObjectAtIndex:index withObject:dic];
                        [self.downloadView reloadData];
                    });
                    
                    
                }
            });
        } else if (state == kCTFontDescriptorMatchingWillBeginDownloading) {
            dispatch_async( dispatch_get_main_queue(), ^ {
                // Show a progress bar
                _fProgressView.progress = 0.0;
                _fProgressView.hidden = NO;
                NSLog(@"Begin Downloading");
            });
        } else if (state == kCTFontDescriptorMatchingDidFinishDownloading) {
            dispatch_async( dispatch_get_main_queue(), ^ {
                // Remove the progress bar
                _fProgressView.hidden = YES;
                NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:self.downWordsM[index]];
                [dic setValue:@YES forKey:isDownload];
                [[NSUserDefaults standardUserDefaults] setBool:@YES forKey:[NSString stringWithFormat:@"%@%@",fontName,@"IsD"]];
                [[NSUserDefaults standardUserDefaults] synchronize];
                [self.downWordsM replaceObjectAtIndex:index withObject:dic];
                [self.downloadView reloadData];
                
                NSLog(@"Finish downloading");
            });
        } else if (state == kCTFontDescriptorMatchingDownloading) {
            dispatch_async( dispatch_get_main_queue(), ^ {
                // Use the progress bar to indicate the progress of the downloading
                [_fProgressView setProgress:progressValue / 100.0 animated:YES];
                NSLog(@"Downloading %.0f%% complete", progressValue);
                
                
                
            });
        } else if (state == kCTFontDescriptorMatchingDidFailWithError) {
            NSError *error = [(__bridge NSDictionary *)progressParameter objectForKey:(id)kCTFontDescriptorMatchingError];
            if (error != nil) {

            } else {

            }
            // Set our flag
            errorDuringDownload = YES;
            
            dispatch_async( dispatch_get_main_queue(), ^ {
                _fProgressView.hidden = YES;

            });
        }
        
        return (bool)YES;
    });
    
}


- (BOOL)isFontDownloaded:(NSString *)fontName {
    UIFont* aFont = [UIFont fontWithName:fontName size:12.0];
    if (aFont && ([aFont.fontName compare:fontName] == NSOrderedSame
                  || [aFont.familyName compare:fontName] == NSOrderedSame)) {
        return YES;
    } else {
        return NO;
    }
}


-(void)matchingFontWithFontName:(NSString*)fontName dictionary:(NSDictionary*)dic index:(NSInteger)index
{
    
    // 用字体的PostScript名字创建一个Dictionary
    NSMutableDictionary *attrs = [NSMutableDictionary dictionaryWithObjectsAndKeys:fontName, kCTFontNameAttribute, nil];
    
    // 创建一个字体描述对象CTFontDescriptorRef
    CTFontDescriptorRef desc = CTFontDescriptorCreateWithAttributes((__bridge CFDictionaryRef)attrs);
    
    // 将字体描述对象放到一个NSMutableArray中
    NSMutableArray *descs = [NSMutableArray arrayWithCapacity:0];
    [descs addObject:(__bridge id)desc];
    CFRelease(desc);
    
    __block BOOL errorDuringDownload = NO;
    
    CTFontDescriptorMatchFontDescriptorsWithProgressHandler( (__bridge CFArrayRef)descs, NULL,  ^(CTFontDescriptorMatchingState state, CFDictionaryRef progressParameter) {
        
        double progressValue = [[(__bridge NSDictionary *)progressParameter objectForKey:(id)kCTFontDescriptorMatchingPercentage] doubleValue];
        
        if (state == kCTFontDescriptorMatchingDidBegin) {
            NSLog(@"字体已经匹配");
        } else if (state == kCTFontDescriptorMatchingDidFinish) {
            if (!errorDuringDownload) {
                NSLog(@"字体%@ 下载完成", fontName);

                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    [UserSingleton shareUserSingleton].fontName = fontName;
                    [self.downWordsM replaceObjectAtIndex:index withObject:dic];
                    [self.downloadView reloadData];
                    [self.collectionView reloadData];
                });
            }
        } else if (state == kCTFontDescriptorMatchingWillBeginDownloading) {
            NSLog(@"字体开始下载");
        } else if (state == kCTFontDescriptorMatchingDidFinishDownloading) {
            NSLog(@"字体下载完成");
            dispatch_async( dispatch_get_main_queue(), ^ {
                // 可以在这里修改UI控件的字体
            });
        } else if (state == kCTFontDescriptorMatchingDownloading) {
            NSLog(@"下载进度 %.0f%% ", progressValue);
        } else if (state == kCTFontDescriptorMatchingDidFailWithError) {
            NSError *error = [(__bridge NSDictionary *)progressParameter objectForKey:(id)kCTFontDescriptorMatchingError];
            if (error != nil) {
               
            } else {
               
            }
            // 设置标志
            errorDuringDownload = YES;

        }
        
        return (BOOL)YES;
    });

}


-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    UIWindow *window  = [[UIApplication sharedApplication] keyWindow];
    [window endEditing:YES];
    [MobClick endLogPageView:@"CreatStyleFrameController"];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
   
}



@end
