//
//  EditViewController.m
//  xike
//
//  Created by shaker on 15/7/1.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "EditViewController.h"
#import "common.h"
#import "EditImageView.h"
#import "UserSingleton.h"


#define keyboardShowName  @"keyboardShow"
#define keyboardHideName  @"keyboardHide"


@interface EditViewController ()<UITextViewDelegate>
@property(nonatomic, strong) UITextView *titleTextView;
@property(nonatomic, strong) UITextView *contentView;

@end

@implementation EditViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self settingNavBar];
    self.view.backgroundColor = [UIColor whiteColor];
    
    _titleTextView = [self customTextViewWithFrame:CGRectMake(15, 0, kWidth-30, 40) placeHolderPlaceTag:101 font:24.0f placeHolder:@"输入标题"];
    
    [self.view addSubview:self.titleTextView];
        
    _contentView = [self customTextViewWithFrame:CGRectMake(15, CGRectGetMaxY(self.titleTextView.frame)+2, kWidth-30, kHeight-40) placeHolderPlaceTag:102 font:13.0f placeHolder:@"输入内容"];
    
    [self.view addSubview:self.contentView];
    
}


-(void)settingNavBar
{
    UIButton *leftBtn = [self customNaviButtonWithFrame:CGRectMake(0, 0, 50, 30) title:@"取消" tag:1001];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    UIButton *rightBtn = [self customNaviButtonWithFrame:CGRectMake(0, 0, 50, 30) title:@"发布" tag:1002];
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
    self.navigationItem.rightBarButtonItem = rightItem;
    
    UILabel *titleLabe = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 60, 30)];
    titleLabe.text=@"文本编辑";
    titleLabe.textAlignment = NSTextAlignmentCenter;
    titleLabe.font = [UIFont systemFontOfSize:15.0f];
    self.navigationItem.titleView = titleLabe;
    self.navigationController.navigationBar.translucent = NO;
    
}



//custom textView

-(UITextView*)customTextViewWithFrame:(CGRect)frame placeHolderPlaceTag:(NSInteger)tag font:(float)fontSize placeHolder:(NSString *)placeHolder
{
    UITextView *titleTextView = [[UITextView alloc]initWithFrame:frame];
    titleTextView.delegate = self;
    titleTextView.showsVerticalScrollIndicator = YES;
    titleTextView.font = [UIFont fontWithName:[UserSingleton shareUserSingleton].fontName size:fontSize];
    UILabel *placeLabel = [[UILabel alloc]initWithFrame:CGRectMake(0,CGRectGetMinY(titleTextView.frame)+5, 100, 40)];
    placeLabel.text = placeHolder;
    placeLabel.tag = tag;
    placeLabel.font = [UIFont systemFontOfSize:fontSize];
    placeLabel.textColor = [UIColor grayColor];
    placeLabel.textAlignment = NSTextAlignmentCenter;
    [titleTextView addSubview:placeLabel];
    titleTextView.backgroundColor = [UIColor whiteColor];
    UIToolbar *topBar = [[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, kWidth, 30)];
    UIBarButtonItem *completeItem =[[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(hideKeyboard)];
    UIBarButtonItem *flexItem = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil];
    topBar.items = @[flexItem,completeItem];
    [titleTextView setInputAccessoryView:topBar];
    titleTextView.returnKeyType = UIReturnKeyDefault;
    titleTextView.scrollEnabled = YES;
    
    return titleTextView;

}

//custom button
-(UIButton *)customNaviButtonWithFrame:(CGRect)frame title:(NSString *)title tag:(NSInteger)tag
{
    UIButton *btn = [[UIButton alloc]initWithFrame:frame];
    [btn setTitle:title forState:UIControlStateNormal];
    [btn setTitleColor: kColor(0, 216, 165) forState:UIControlStateNormal];
    btn.tag = tag;
    btn.titleLabel.font = [UIFont systemFontOfSize:15.0f];
    [btn addTarget:self action:@selector(editNaviItemClick:) forControlEvents:UIControlEventTouchUpInside];
    
    return btn;
    
}

-(void)editNaviItemClick:(UIButton*)sender
{
    switch (sender.tag) {
        case 1001://取消
        {
            [self.navigationController popViewControllerAnimated:YES];
        }
            break;
        case 1002://完成
        {

            
            if (self.textBlock) {
                if ([self.contentView.text length]) {
                    self.textBlock(@{@"title":self.titleTextView.text.length? self.titleTextView.text:@"",
                                     @"content":self.contentView.text});
                    
                    [self.navigationController popViewControllerAnimated:YES];
  
                }else{
                    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"内容不能为空" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                    [alert show];
                }
            }
            
        }
            break;
            
        default:
            break;
    }

}

#pragma mark -- text view delegate
-(void)textViewDidBeginEditing:(UITextView *)textView
{
    
    if (textView == self.titleTextView) {
        UILabel *label = (UILabel*)[self.titleTextView viewWithTag:101];
        [label removeFromSuperview];
       textView.frame = CGRectMake(0, 0, kWidth, 50);
    }else {
        UILabel *label = (UILabel*)[self.contentView viewWithTag:102];
        [label removeFromSuperview];
        

    }
    
}


//hide keyBoard click
-(void)hideKeyboard
{
    self.titleTextView.frame = CGRectMake(0, 0, kWidth, 40);
    [self.titleTextView resignFirstResponder];
    self.contentView.frame =CGRectMake(15, CGRectGetMaxY(self.titleTextView.frame)+2, kWidth-30, kHeight-40);
    [self.contentView resignFirstResponder];
}


//block

-(void)returnEditedText:(textBlock)textBlock
{
    self.textBlock = textBlock;
}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
