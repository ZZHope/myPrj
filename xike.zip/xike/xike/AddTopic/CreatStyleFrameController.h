//
//  CreatStyleFrameController.h
//  xike
//
//  Created by shaker on 15/6/18.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PublishingSuccessViewController.h"
@interface CreatStyleFrameController : UIViewController
@property (nonatomic, strong) NSMutableArray *originalPhotoArr;
@property (nonatomic, copy)  NSString *topicIdFromCreat;
@end
