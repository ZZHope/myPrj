//
//  ObtainPictureViewController.h
//  xike
//
//  Created by shaker on 15/6/16.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^ReturnPhotoBlock) (NSArray *photoArr);
@interface ObtainPictureViewController : UIViewController
@property (nonatomic, copy) NSString *loopFlag;
@property (nonatomic, copy) NSString *creatTopicId;
@property (nonatomic, copy) ReturnPhotoBlock selectPhotoBlock;

-(void)returnNewPhoto:(ReturnPhotoBlock)selectPhotoBlock;


@end
