//
//  GuideViewController.m
//  xike
//
//  Created by shaker on 15/6/1.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "GuideViewController.h"
#import "ShakerManager.h"
#import "common.h"

@interface GuideViewController ()
@property(nonatomic, strong) UIButton *startBtn;

@end

@implementation GuideViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _startBtn = [[UIButton alloc]initWithFrame:CGRectMake((kWidth-100)*0.5, kHeight-200, 100, 60)];
    _startBtn.backgroundColor = [UIColor redColor];
    [self.startBtn addTarget:self action:@selector(startMain) forControlEvents:UIControlEventTouchUpInside];
    [self.startBtn setTitle:@"开启稀客" forState:UIControlStateNormal];

    [self.view addSubview:self.startBtn];
    
    self.view.backgroundColor = [UIColor yellowColor];
    
}


-(void)startMain
{

    [ShakerManager presentViewControllerWithType:SHAKERMAIN];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
