//
//  likeNumberViewController.m
//  xike
//
//  Created by a on 15/6/29.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "likeNumberViewController.h"
#import "AFNetworking.h"
#import "Networking.h"
#import "common.h"
#import "UIImageView+WebCache.h"

typedef NS_ENUM(NSInteger, VIEWTYPE)
{
    COMMENTNUM=0,
    LIKENUM
};
@interface likeNumberViewController ()<UITableViewDelegate,UITableViewDataSource,UITextViewDelegate>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)UIScrollView *scrollView;
@property(nonatomic,strong)UIView *backView;
@property(nonatomic,strong)UIView *inputFieldView;
@property(nonatomic,strong)NSMutableArray *userBrowseArrM;
@property(nonatomic,strong)NSMutableArray *userLikeArrM;
@property(nonatomic,strong)NSMutableArray *userCommentArrM;


@end

@implementation likeNumberViewController
{
    UIButton *comment;
    UIButton *like;
    UITextView *textView1;
    UIGestureRecognizer *resignTap;
    NSMutableAttributedString *placeholder;
    NSInteger keyboardHeight;
    CGSize kbSize;
}



- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationController.navigationBarHidden=YES;
    
    [self buildNavView];
    
    [self buildTableView];
    
    [self buildInputFieldView];
 
    [self prefersStatusBarHidden];
    
    _userBrowseArrM=[NSMutableArray array];
    _userLikeArrM=[NSMutableArray array];
    _userCommentArrM=[NSMutableArray array];
    
     resignTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(resignKeyBoard)];
    if (self.viewFlag==COMMENTNUM) {
        [UIView animateWithDuration:0.5f delay:0.5f options:UIViewAnimationOptionBeginFromCurrentState animations:^{
            
            [_inputFieldView setFrame:CGRectMake(0, kHeight-49, kWidth, 49)];
        } completion:^(BOOL finished) {
            
        }];
    }
    
    //增加监听，当键盘出现或改变时收出消息
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardWillShowNotification
                                               object:nil];
    
//    //增加监听，当键退出时收出消息
//    [[NSNotificationCenter defaultCenter] addObserver:self
//                                             selector:@selector(keyboardWillHide:)
//                                                 name:UIKeyboardWillHideNotification
//                                               object:nil];
    
}
- (BOOL)prefersStatusBarHidden
{
    return YES;//隐藏为YES，显示为NO
}
-(void)buildNavView
{
    UIView *navView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWidth, 44)];
    navView.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:navView];
    
    UIView *backGround=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 40, 44)];
    
    UIImage *backImg=[UIImage imageNamed:@"fanhui"];
    UIImageView *backImgView=[[UIImageView alloc]initWithImage:backImg];
    backImgView.frame=CGRectMake(10, 10, backImg.size.width, backImg.size.height);
    [backGround addSubview:backImgView];
    
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(backTap:)];
    backImgView.userInteractionEnabled = YES;
    [backGround addGestureRecognizer:tap];
    tap.numberOfTapsRequired = 1; // 单击
    
    
    [navView addSubview:backGround];
    comment=[self buttonWithFrame:CGRectMake(40, 0, (kWidth-backImgView.frame.size.width)/2, 44) title:@"评论100" tag:101 ];
    if (self.viewFlag == 0) {
        [comment setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
        [like setTitleColor:kColor(216, 216, 216) forState:UIControlStateNormal];
    }

    [navView addSubview:comment];
    
    like=[self buttonWithFrame:CGRectMake(backImgView.frame.size.width+comment.frame.size.width, 0, (kWidth-backImgView.frame.size.width)/2, 44) title:@"喜欢" tag:102];
    if (self.viewFlag == 1) {
        [like setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
        [comment setTitleColor:kColor(216, 216, 216) forState:UIControlStateNormal];
    }
    [navView addSubview:like];
    
    UIView *lineView=[[UIView alloc]initWithFrame:CGRectMake(0, 43, kWidth, 1)];
    lineView.backgroundColor=kColor(216, 216, 216);
    [navView addSubview:lineView];

    
}

-(void)buildInputFieldView
{
    _inputFieldView=[[UIView alloc]initWithFrame:CGRectMake(0, kHeight+49, kWidth, 49)];
    _inputFieldView.backgroundColor=[UIColor whiteColor];
    
    UIView *lineView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWidth, 1)];
//    lineView.backgroundColor=kColor(216, 216, 216);
    lineView.backgroundColor=kColor(216, 216, 216);
    [_inputFieldView addSubview:lineView];
    
    
    
    textView1=[[UITextView alloc]initWithFrame:CGRectMake(15, 10, kWidth-15-60, 30)];
    [textView1.layer setMasksToBounds:YES];
    [textView1.layer setCornerRadius:3.0];
    textView1.delegate = self;
    textView1.backgroundColor = kColor(231, 231, 231);
    placeholder = [[NSMutableAttributedString alloc] initWithString:@"说点什么吧..."];
    [placeholder addAttribute:NSForegroundColorAttributeName value:kColor(167, 167, 167) range:NSMakeRange(0, placeholder.length)];
    [placeholder addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:12] range:NSMakeRange(0, placeholder.length)];
    textView1.attributedText = placeholder;
    self.automaticallyAdjustsScrollViewInsets = NO;
    [_inputFieldView addSubview:textView1];
    
    UIButton *sendButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    sendButton.frame=CGRectMake(textView1.frame.origin.x+textView1.frame.size.width, 10, kWidth-(textView1.frame.origin.x+textView1.frame.size.width), 30);
    [sendButton setTitle:@"发送" forState:UIControlStateNormal];
    [sendButton setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
    [sendButton addTarget:self action:@selector(sendCommentMessage:) forControlEvents:UIControlEventTouchUpInside];
    [_inputFieldView addSubview:sendButton];
    
    [self.view addSubview:_inputFieldView];
}

-(void)backTap:(UITapGestureRecognizer*)tap
{
    //contentViewController *content=[[contentViewController alloc]init];
    self.navigationController.navigationBarHidden=NO;
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)buildTableView
{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 44, kWidth, kHeight-44) style:UITableViewStyleGrouped];
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;//取消分割线
     _tableView.showsVerticalScrollIndicator=NO;
    _tableView.delegate=self;
    _tableView.dataSource=self;
    
    [self.view addSubview:_tableView];
    
}

//设置有几个section  默认为1
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

//绘制tableViewCell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (self.viewFlag==COMMENTNUM) {
        static NSString *identifier1=@"ident1";
        commentNumberCell *cell=[tableView dequeueReusableCellWithIdentifier:identifier1];
        if (cell==nil) {
            cell=[[NSBundle mainBundle] loadNibNamed:@"commentNumberCell" owner:self options:nil][0];
        }
        CALayer *lay =cell.commentFaceImage.layer;
        [lay setMasksToBounds:YES];
        [lay setCornerRadius:4.0];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
//        [cell.commentFaceImage sd_setImageWithURL:[NSURL URLWithString:[self.userCommentArrM[indexPath.row]objectForKey:@"userPhoto"]]];
//        cell.commentContentLabel.text=[self.userCommentArrM[indexPath.row]objectForKey:@"userName"];
//        cell.commentTime.text=[self.userCommentArrM[indexPath.row]objectForKey:@"commentDate"];
//        
//        cell.commentContentLabel.text=[self.userCommentArrM[indexPath.row]objectForKey:@"commentContent"];
    
        return cell;
    }else{
        static NSString *identifier = @"ident";
        likeCommentTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (nil == cell) {
            cell =  [[NSBundle mainBundle] loadNibNamed:@"likeCommentTableViewCell" owner:self options:nil][0];
        }
        
        CALayer *lay  = cell.faceImage.layer;//获取ImageView的层
        [lay setMasksToBounds:YES];
        [lay setCornerRadius:4.0];//值越大，角度越圆
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
//临时===========================================================================
       // [cell.faceImage sd_setImageWithURL:[NSURL URLWithString:[self.userLikeArrM[indexPath.row]objectForKey:@"photo"]]];
//        cell.nameLabel.text=[self.userLikeArrM[indexPath.row]objectForKey:@"userName"];
//===============================================================================

        return cell;
    }
}
//设置每个section中有多少个cell
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section==0) {
        return 0;
    }else{
        return 2;
    }
}

#pragma mark -- UITableViewDelegate
//设置每个cell的高度
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.viewFlag==COMMENTNUM) {
        return kHeight*0.15;
    }else
    {
    return kHeight*0.11;
    }
}

//设置section header的高度
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section==0) {
        return _tableView.frame.size.height*0.24;
    }else{
        return _tableView.frame.size.height*0.1;
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.1;
}

//设置头视图中的view；
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (section==0) {
        _backView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWidth, _tableView.frame.size.height*0.25)];
        _backView.backgroundColor=[UIColor whiteColor];
        UILabel *label=[[UILabel alloc]initWithFrame:CGRectMake(10,kHeight*0.24*0.2, 100, 20)];
        label.text=@"500人看过";
        label.backgroundColor=[UIColor clearColor];
        [_backView addSubview:label];
        
        _scrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0, kHeight*0.24*0.45, kWidth, _tableView.frame.size.height*0.1)];
        _scrollView.showsHorizontalScrollIndicator=NO;
        _scrollView.backgroundColor=[UIColor clearColor];
        
        for (NSInteger i = 0; i < self.userBrowseArrM.count; i++) {
            UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(15+i * kWidth*0.15+i*15, _scrollView.frame.size.height*0.05, _scrollView.frame.size.height*0.9,_scrollView.frame.size.height*0.9)];
            CALayer *lay  = imgView.layer;//获取ImageView的层
            [lay setMasksToBounds:YES];
            [lay setCornerRadius:4.0];//值越大，角度越圆
//            imgView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%ld",i+1]];
//===============================================================================
//            [imgView sd_setImageWithURL:[NSURL URLWithString:[self.userBrowseArrM[i]objectForKey:@"photo"]]];
//===============================================================================
            [_scrollView addSubview:imgView];
        }
        _scrollView.contentSize = CGSizeMake(kWidth * self.userBrowseArrM.count, _tableView.frame.size.height*0.1);
        [_backView addSubview:_scrollView];
        
        
        
        return _backView;
    }else{
        UIView *view1=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWidth, _tableView.frame.size.height*0.1)];
        view1.backgroundColor=[UIColor whiteColor];
        UIView *view2=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWidth, 1)];
        view2.backgroundColor=kColor(216, 216, 216);
        [view1 addSubview:view2];
        
        
        UILabel *label1=[[UILabel alloc]initWithFrame:CGRectMake(10, kHeight*0.1*0.5, 100, 20)];
        if (self.viewFlag==LIKENUM) {
            label1.text=@"500人喜欢";
        }else{
            label1.text=@"500人评论";
        }
        
        label1.backgroundColor=[UIColor clearColor];
        [view1 addSubview:label1];
        return view1;
    }
    
}
#pragma mark ---custom button

-(UIButton *)buttonWithFrame:(CGRect)frame title:(NSString *)title tag:(NSInteger)tag
{
    UIButton *topic1Button=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    topic1Button.frame=frame;
    [topic1Button setTitle:title forState:UIControlStateNormal];
    topic1Button.backgroundColor=[UIColor whiteColor];
    topic1Button.titleLabel.font=[UIFont systemFontOfSize:14.0f];
    topic1Button.titleLabel.font=[UIFont boldSystemFontOfSize:15.0];
    [topic1Button setTitleColor:kColor(216, 216, 216) forState:UIControlStateNormal];
    [topic1Button addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    topic1Button.tag = tag;
    
    
    return topic1Button;
}
NSInteger btnTag = 101;
-(void)btnClick:(UIButton *)sender
{
    UIButton *cusBtn = (UIButton *)[self.view viewWithTag:btnTag];
    [cusBtn setTitleColor:kColor(216, 216, 216) forState:UIControlStateNormal];
    switch (sender.tag) {
        case 101:
        {
            [sender setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
            [like setTitleColor:kColor(216, 216, 216) forState:UIControlStateNormal];
            self.viewFlag = COMMENTNUM;
//            [self loadComentDataFromServer:1];
            [self.tableView reloadData];
            [UIView animateWithDuration:0.3f delay:0.3f options:UIViewAnimationOptionBeginFromCurrentState animations:^{

                [_inputFieldView setFrame:CGRectMake(0, kHeight-49, kWidth, 49)];
                            } completion:^(BOOL finished) {
                
            }];
        }
            break;
            case 102:
        {
            [sender setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
            [comment setTitleColor:kColor(216, 216, 216) forState:UIControlStateNormal];
            [self resignKeyBoard];
            self.viewFlag = LIKENUM;
//            [self loadLikeDataFromServer:1];
            [self.tableView reloadData];
            [UIView animateWithDuration:0.3f delay:0.3f options:UIViewAnimationOptionBeginFromCurrentState animations:^{

                [_inputFieldView setFrame:CGRectMake(0, kHeight+49, kWidth, 49)];
            } completion:^(BOOL finished) {
                
            }];
        }
            break;
        default:
            break;
    }
    btnTag = sender.tag;
}

- (void)resignKeyBoard {
    [textView1 resignFirstResponder];
    [self.tableView removeGestureRecognizer:resignTap];
}

-(void)sendCommentMessage:(UITextView *)textView
{
   
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"评论成功" message:nil delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
    [alert show];
    textView1.text = @"";
    [self resignKeyBoard];
    [UIView animateWithDuration:0.3f animations:^{
        [_inputFieldView setFrame:CGRectMake(0, kHeight-49, kWidth, 49)];
    }];
}
#pragma mark TextViewDelegate
- (void)textViewDidBeginEditing:(UITextView *)textView {
    [self.tableView addGestureRecognizer:resignTap];
    [textView becomeFirstResponder];
    if ([textView1.text isEqualToString:placeholder.string]) {
        textView1.text = @"";
    }

  //    NSLog(@"%d",keyboardHeight);

        [_inputFieldView setFrame:CGRectMake(0, kHeight-49-216, kWidth, 49)];
    if (kbSize.height==252) {
        [UIView animateWithDuration:0.3f animations:^{
           [_inputFieldView setFrame:CGRectMake(0, kHeight-49-252, kWidth, 49)];
        }];
        
    }
    

}

- (void)textViewDidEndEditing:(UITextView *)textView {
    if ([textView1.text isEqualToString:@""]) {
        textView1.attributedText = placeholder;
    }
    [self resignKeyBoard];
    [UIView animateWithDuration:0.3f animations:^{
        [_inputFieldView setFrame:CGRectMake(0, kHeight-49, kWidth, 49)];
    }];
}

//-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
//{
//    return YES;
//}



#pragma mark -- load data
//获喜欢此作品的用户列表信息
-(void)loadLikeDataFromServer:(int)worksId
{
    NSString *strUrl = [NSString stringWithFormat:@"%@%@",HOST,@"works/like/list"];
    NSDictionary *para = @{
                           kWorksId:[NSNumber numberWithInt:worksId] //参数是动态获取的
                           };
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:strUrl parameters:para success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [self.userLikeArrM removeAllObjects];
        for (NSDictionary *dic in [[responseObject objectForKey:@"data"] objectForKey:@"rows"]) {
            
            [self.userLikeArrM addObject:dic];
            
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
    
}
//获取用户的评论列表信息
-(void)loadComentDataFromServer:(int)worksId
{
    NSString *strUrl = [NSString stringWithFormat:@"%@%@",HOST,@"works/comment/list"];
    NSDictionary *para = @{
                           kWorksId:[NSNumber numberWithInt:worksId] //参数是动态获取的
                           };
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [manager GET:strUrl parameters:para success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"comment :%@",responseObject);
        
        [self.userCommentArrM removeAllObjects];
        for (NSDictionary *dic in [[responseObject objectForKey:@"data"] objectForKey:@"rows"]) {
            
            [self.userCommentArrM addObject:dic];
            
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"comment error:%@",error);
    }];
    
}
//作品浏览记录
//int pageNumber = 0;
-(void)loadTopicDataFromServer:(int)worksId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSString *strUrl = [NSString stringWithFormat:@"%@%@",HOST,@"works/browse/list"];
    NSDictionary *para = @{kWorksId:[NSNumber numberWithInt:worksId],
                          // @"page":[NSNumber numberWithInt:pageNumber]
                           };
    [manager GET:strUrl parameters:para success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"topic :%@",responseObject);
        
            [self.userBrowseArrM removeAllObjects];
            
            //pageNumber+=1;
            for (NSDictionary *dic in [[responseObject objectForKey:@"data"] objectForKey:@"rows"]) {
                
                [self.userBrowseArrM addObject:dic];
        
            }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        NSLog(@"topic error:%@",error);

        
    }];
}

//当键盘出现或改变时调用
- (void)keyboardWillShow:(NSNotification *)aNotification
{
    //获取键盘的高度
    NSDictionary *userInfo = [aNotification userInfo];
    NSValue *aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect keyboardRect = [aValue CGRectValue];
    keyboardHeight = keyboardRect.size.height;
    
    kbSize = [[userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;//得到鍵盤的高度
    NSLog(@"hight_hitht:%f",kbSize.height);
    if (kbSize.height==252) {
        [UIView animateWithDuration:0.3f animations:^{
            [_inputFieldView setFrame:CGRectMake(0, kHeight-49-kbSize.height, kWidth, 49)];
        }];
    }

}

-(void)textViewDidChange:(UITextView *)textView
{
    if (kbSize.height==216) {
        [UIView animateWithDuration:0.3f animations:^{
            [_inputFieldView setFrame:CGRectMake(0, kHeight-49-kbSize.height-36, kWidth, 49)];
        }];
    }else{
        [UIView animateWithDuration:0.3f animations:^{
            [_inputFieldView setFrame:CGRectMake(0, kHeight-49-kbSize.height, kWidth, 49)];
             }];
    }
    
    
    
}



-(void)viewWillDisappear:(BOOL)animated
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
