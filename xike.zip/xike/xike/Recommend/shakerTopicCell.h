//
//  shakerTopicCell.h
//  xike
//
//  Created by MarilynEric on 15/7/10.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "common.h"
@class shakerTopicCell;

@protocol ShakerTopicCellDelegate <NSObject>

@optional
-(void)shakerTopicCellFocusClickWithButton:(UIButton *)sender;

@end


@interface shakerTopicCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *articleCoverView;
@property (weak, nonatomic) IBOutlet UILabel *textlabel;
@property (weak, nonatomic) IBOutlet UIButton *attentionButton;
@property (weak, nonatomic) IBOutlet UIButton *creatorName;
@property (weak, nonatomic) IBOutlet UILabel *timeDuration;

@property (weak, nonatomic) IBOutlet UIImageView *profileCreator;

@property (weak, nonatomic) IBOutlet UILabel *topicTitle;
@property (weak, nonatomic) IBOutlet UILabel *commentNumL;
@property (weak, nonatomic) IBOutlet UILabel *likeNumL;

@property (weak, nonatomic) IBOutlet UILabel *pagesNumL;

@property(nonatomic,assign) id<ShakerTopicCellDelegate> delegate;
@end
