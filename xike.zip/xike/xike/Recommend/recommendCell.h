//
//  recommendCell.h
//  xike
//
//  Created by a on 15/6/25.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "common.h"
@interface recommendCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *recommendImage;


@end
