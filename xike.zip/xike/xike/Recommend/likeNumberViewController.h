//
//  likeNumberViewController.h
//  xike
//
//  Created by a on 15/6/29.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "common.h"
#import "likeCommentTableViewCell.h"
#import "contentViewController.h"
#import "commentNumberCell.h"
#import "ShareEngine.h"
#import "AFNetworking.h"
#import "Networking.h"
@interface likeNumberViewController : UIViewController
@property(nonatomic,assign)NSInteger viewFlag;
@end
