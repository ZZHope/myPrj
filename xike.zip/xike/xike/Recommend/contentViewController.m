//
//  contentViewController.m
//  xike
//
//  Created by a on 15/6/26.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "contentViewController.h"
#import "ShareEngine.h"
#import "Networking.h"
#import "ShareEngine.h"
#import "AFNetworking.h"
#import "templeteView.h"
#import "common.h"
#import "UIImageView+WebCache.h"

#define kStyle @"style"
#define kTitle @"title"
#define kContent  @"content"
#define kImage @"logo"


@interface contentViewController ()<UIScrollViewDelegate>

@property(nonatomic, strong)test *imgOutSide;
@property(nonatomic, strong)UIView *imgInner;

@property(nonatomic,strong)UIScrollView *scrollView;
@property(nonatomic,strong)UIImageView *imgView;
@property(nonatomic, strong) NSMutableArray *templeteViewM;
@property(nonatomic, strong) UILabel *navLabel;
@end

@implementation contentViewController
{
    UIImageView *likeImage;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationController.navigationBar.translucent= NO;
    self.view.backgroundColor = [UIColor whiteColor];
    
     self.navigationController.navigationBarHidden=NO;
    
    [self buildUnderView];
    
    [self loadingAnimation];
    
    [self prefersStatusBarHidden];
    
    self.navigationController.navigationBar.alpha = 1;
    
    [self loadArticleDetailWithArticleId:self.articleId];
    [self buildNav];


    
    //data
    
    _templeteViewM = [NSMutableArray array];
    
}
- (BOOL)prefersStatusBarHidden
{
    return YES;//隐藏为YES，显示为NO
}

-(void)buildNav
{
    UIImage *backImg=[UIImage imageNamed:@"fanhui"];
    UIButton *backImgView=[UIButton buttonWithType:UIButtonTypeCustom];

    backImgView.frame=CGRectMake(0, 0, backImg.size.width, backImg.size.height);
    [backImgView setImage:backImg forState:UIControlStateNormal];
    [backImgView addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftItemCuston=[[UIBarButtonItem alloc]initWithCustomView:backImgView];
    self.navigationItem.leftBarButtonItem=leftItemCuston;
    
    
    
     _navLabel=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, 50, 20)];
//    self.title = [NSString stringWithFormat:@"%d/%ld",1,self.templeteViewM.count];
//    self.navLabel.text=self.title;
    self.navLabel.textColor=kColor(167, 167, 167);
    self.navigationItem.titleView=self.navLabel;
    
    UIImage *shareImg=[UIImage imageNamed:@"fenxiang1"];
    UIButton *imgView=[[UIButton alloc]init];

    imgView.frame=CGRectMake(0, 0, shareImg.size.width, shareImg.size.height);
    [imgView setImage:shareImg forState:UIControlStateNormal];
    [imgView addTarget:self action:@selector(shareArticle) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *rightItemCuston=[[UIBarButtonItem alloc]initWithCustomView:imgView];
    
    self.navigationItem.rightBarButtonItem=rightItemCuston;
}

-(void)buildUnderView
{
    UIView *view=[[UIView alloc]initWithFrame:CGRectMake(0, kHeight-49-44, kWidth, 49)];
    view.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:view];
    
    UIButton *userNameBtn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    [userNameBtn setTitle:@"Howard Morgan" forState:UIControlStateNormal];
    [userNameBtn setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
    userNameBtn.frame=CGRectMake(10, 10, kWidth/3, view.frame.size.height) ;
    [userNameBtn sizeToFit];
    [userNameBtn addTarget:self action:@selector(goOtherUserClick) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:userNameBtn];
    
    UIImageView *commentImage=[[UIImageView alloc]initWithFrame:CGRectMake(kWidth*0.65, view.frame.size.height*0.35, kWidth*0.05, view.frame.size.height*0.35)];
    commentImage.image=[UIImage imageNamed:@"pinglun"];
    [view addSubview:commentImage];
    
    UILabel *commentLabel=[[UILabel alloc]initWithFrame:CGRectMake(commentImage.frame.origin.x+commentImage.frame.size.width+10, commentImage.frame.origin.y, kWidth*0.09, commentImage.frame.size.height)];
    commentLabel.backgroundColor=[UIColor clearColor];
    commentLabel.text=@"10";
    commentLabel.textColor=kColor(167, 167, 167);
    UITapGestureRecognizer *commentTap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(golikeTap:)];
    commentLabel.tag=101;
    commentLabel.userInteractionEnabled = YES;
    [commentLabel addGestureRecognizer:commentTap];
    commentTap.numberOfTapsRequired = 1;
    [view addSubview:commentLabel];
    

    
    likeImage=[[UIImageView alloc]initWithFrame:CGRectMake(commentLabel.frame.origin.x+commentLabel.frame.size.width, commentLabel.frame.origin.y, commentImage.frame.size.width, commentImage.frame.size.height)];
    likeImage.image=[UIImage imageNamed:@"xihuan"];
    UITapGestureRecognizer *likeImageTap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(addlikeTap:)];
    likeImage.userInteractionEnabled = YES;
    [likeImage addGestureRecognizer:likeImageTap];
    likeImageTap.numberOfTapsRequired = 1;
    [view addSubview:likeImage];
    
    UILabel *likeLabel=[[UILabel alloc]initWithFrame:CGRectMake(likeImage.frame.origin.x+likeImage.frame.size.width+10, commentLabel.frame.origin.y, commentLabel.frame.size.width, commentLabel.frame.size.height)];
    likeLabel.backgroundColor=[UIColor clearColor];
    likeLabel.text=@"10";
    likeLabel.textColor=kColor(167, 167, 167);
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(golikeTap:)];
    likeLabel.tag=102;
    likeLabel.userInteractionEnabled = YES;
    [likeLabel addGestureRecognizer:tap];
    tap.numberOfTapsRequired = 1; //
    [view addSubview:likeLabel];
    
    
    
    
    UIView *lineView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWidth, 1)];
    lineView.backgroundColor=kColor(216, 216, 216);
    [view addSubview:lineView];
}

-(void)loadingAnimation
{
    //背景
    _imgOutSide = [[test alloc]initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width*0.15, self.view.bounds.size.height*0.13)];
    _imgOutSide.backgroundColor= kColor(216, 216, 216);
    _imgOutSide.color = kColor(0, 216, 165);
    _imgOutSide.x=0.9;
    _imgOutSide.y=1.2;
    _imgOutSide.radius=1.5;
    _imgOutSide.startAngle=-0.49;
    _imgInner = [self imgViewWithFrame:CGRectMake(self.view.bounds.size.width*0.43, self.view.bounds.size.height*0.35, self.view.bounds.size.width*0.15, self.view.bounds.size.height*0.13)];
    
    self.imgOutSide.progressRate = 0.1f;
    UIImageView *coverView=[self imgViewWithFrame:CGRectMake(3, 3, self.view.bounds.size.width*0.15-6, self.view.bounds.size.height*0.13-6)];
    //coverView.backgroundColor=[UIColor whiteColor];
    coverView.image=[UIImage imageNamed:@"Fill4"];
    [self.imgInner addSubview:self.imgOutSide];
    [self.imgInner addSubview:coverView];
    [self.view addSubview:self.imgInner];
    
}

-(void)buildScrollView
{
    if (_scrollView == nil) {
        
        _scrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(kWidth,50,kWidth-50,kHeight-44-100)];
    }
    self.scrollView.showsHorizontalScrollIndicator = NO;
    self.scrollView.pagingEnabled = YES;
    self.scrollView.backgroundColor = [UIColor whiteColor];
    self.scrollView.delegate = self;

    
    [self.scrollView.subviews makeObjectsPerformSelector:@selector(removeAllObjects)];
    
    UIImageView *tempView = [[UIImageView alloc]init];
    
    [tempView sd_setImageWithURL:[NSURL URLWithString:[self.templeteViewM[0] objectForKey:kImage]] placeholderImage:nil options:SDWebImageLowPriority progress:^(NSInteger receivedSize, NSInteger expectedSize) {
        
        self.imgOutSide.progressRate = receivedSize*1.0/expectedSize;
        [self.imgOutSide setNeedsDisplay];

        if (self.imgOutSide.progressRate == 1.0) {
            [self pushScrollView];
        }
        
    } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        self.imgOutSide.progressRate = 1.0f;
        [self.imgOutSide setNeedsDisplay];
        [self pushScrollView];
        NSLog(@"error:%@",error);
    }];
    
    for (int i = 0; i < self.templeteViewM.count+1; i++) {
        if (i<self.templeteViewM.count) {
            templeteView *templete = [[templeteView alloc]initWithFrame:CGRectMake(i * kWidth, 0, kWidth, _scrollView.frame.size.height)];
            //index --- 版式   order--- 第几个
            templete.imgView.contentMode = UIViewContentModeScaleAspectFill;
            
            [self customLayoutTemplete:templete withIndex:[[self.templeteViewM[i] objectForKey:@"plate"] integerValue] withOrder:i  rate:1.0f];
            [templete.imgView.imageView sd_setImageWithURL:[self.templeteViewM[i] objectForKey:kImage]];
            UIView *coverView = [[UIView alloc]initWithFrame:templete.bounds];
            coverView.backgroundColor = [[UIColor blackColor]colorWithAlphaComponent:0.0f];
            [templete addSubview:coverView];
            [_scrollView addSubview:templete];
            
        }else{
            
            
            UIImageView *profileView = [[UIImageView alloc]initWithFrame:CGRectMake(self.templeteViewM.count*kWidth+kWidth*0.35, _scrollView.frame.size.height*0.15, kWidth*0.3, kWidth*0.3)];
            
            
            UILabel *partakeLabel=[[UILabel alloc]initWithFrame:CGRectMake(kWidth*self.templeteViewM.count+kWidth*0.25, profileView.frame.origin.y+profileView.frame.size.height+5, kWidth*0.5, 30)];
            partakeLabel.backgroundColor=[UIColor clearColor];
            partakeLabel.text=@"25人参与/20人关注";
            partakeLabel.font=[UIFont systemFontOfSize:9.0f];
            partakeLabel.textAlignment=NSTextAlignmentCenter;
            //[partakeLabel sizeToFit];
            [_scrollView addSubview:partakeLabel];
            UILabel *titleLabel=[[UILabel alloc]initWithFrame:CGRectMake(kWidth*self.templeteViewM.count+kWidth*0.05, partakeLabel.frame.origin.y+partakeLabel.frame.size.height+10, kWidth*0.9, 50)];
            titleLabel.backgroundColor=[UIColor clearColor];
            titleLabel.text=@"送我一支迷幻药帮我意淫与现实无关的事物离开现实表面";
            titleLabel.numberOfLines=2;
            titleLabel.textAlignment=NSTextAlignmentCenter;
            [_scrollView addSubview:titleLabel];
            
            
            UIButton *backTopicButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];
            backTopicButton.frame=CGRectMake(kWidth*self.templeteViewM.count+kWidth*0.2, _scrollView.frame.size.height*0.7, kWidth*0.6, _scrollView.frame.size.height*0.06);
            backTopicButton.backgroundColor=[UIColor orangeColor];
            [backTopicButton setTitle:@"回到话题" forState:UIControlStateNormal];
            [backTopicButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            backTopicButton.backgroundColor=kColor(0, 216, 165);
            backTopicButton.layer.cornerRadius=3.0f;
            [backTopicButton addTarget:self action:@selector(backTopic) forControlEvents:UIControlEventTouchUpInside];
            [_scrollView addSubview:backTopicButton];
            
            
            UIButton *nextButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];
            nextButton.frame=CGRectMake(kWidth*self.templeteViewM.count+kWidth*0.2, _scrollView.frame.size.height*0.8, kWidth*0.6, _scrollView.frame.size.height*0.06);
            nextButton.backgroundColor=[UIColor orangeColor];
            [nextButton setTitle:@"下一篇" forState:UIControlStateNormal];
            [nextButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            nextButton.backgroundColor=kColor(0, 216, 165);
            nextButton.layer.cornerRadius=3.0f;
            [nextButton addTarget:self action:@selector(nextOpus) forControlEvents:UIControlEventTouchUpInside];
            [_scrollView addSubview:nextButton];
            
            
        }
        
    }

    
    [self.view addSubview:_scrollView];
}


-(void)shareArticle
{
    //[self sinaWeiboShare];
    [self wechatSessionShare];
}

#pragma mark Share Button Actions
- (void)wechatSessionShare {
    NSString *theme = [@"testWechat" stringByAppendingString:@":"];
    NSString *content = @"testtest";
    NSString *URLString = [[NSString alloc] initWithFormat:@"%@",@"http://v1.qzone.cc/pic/201507/02/21/05/559536ff424f2614.jpg!600x600.jpg"];
    [[ShareEngine sharedInstance] sendLinkContent:WXSceneSession :theme :content :[UIImage imageNamed:@"3"] :[NSURL URLWithString:URLString]];
    
}

//- (void)wechatTimelineShare {
//    NSString *theme = [_topic.title stringByAppendingString:@":"];
//    UIImage *image = [UIImage imageWithOriginImage:_topic.topicImage scaledToSize:CGSizeMake(220, 140)];
//    //UIImage *image = [UIImage imageNamed:@"layout1_79122"];
//    NSString *content = _topic.content.length >10 ?[[_topic.content substringToIndex:10] stringByAppendingString:@"..."] : _topic.content;
//    NSString *URLString = [[NSString alloc] initWithFormat:@"%@%@%@",HOST,@"/entity/",_topic.UUID];
//    [[ShareEngine sharedInstance] sendLinkContent:WXSceneTimeline :theme :content :image :[NSURL URLWithString:URLString]];
//}

#pragma mark -- share weibo
- (void)sinaWeiboShare {
   
    NSString *content = @"test";
    NSString *URLString = [[NSString alloc] initWithFormat:@"%@%@%@",@"http://v2.shaker.mobi",@"/entity/",@"a6618832-39f5-4e04-91ff-7ed57f40d2be"];
    [[ShareEngine sharedInstance] sendWBLinkeContent:content :@"shaker test" :[UIImage imageNamed:@"xiangji"] :[NSURL URLWithString:URLString]];
}


-(void)golikeTap:(UITapGestureRecognizer*)tap
{
    likeNumberViewController *likeNumber=[[likeNumberViewController alloc]init];
    likeNumber.hidesBottomBarWhenPushed = YES;

    switch (tap.self.view.tag) {
        case 101:
            likeNumber.viewFlag = 0;
            break;
        case 102:
            likeNumber.viewFlag = 1;
            break;

            
        default:
            break;
    }
    
    [self.navigationController pushViewController:likeNumber animated:YES];
}

BOOL isLike = YES;

-(void)addlikeTap:(UITapGestureRecognizer *)likeImageTap
{
    isLike = !isLike;
    
    
    if (isLike) {
       
        [self cancelLikeToServiceWithCancelId:1];
        
    }else{
       
        [self likeToServiceWithid:1];//1这个需要动态改变
    }
    
}
-(void)goOtherUserClick
{
    otherUserViewController *otherUser=[[otherUserViewController alloc]init];
    UIBarButtonItem *backitem = [[UIBarButtonItem alloc]init];
    backitem.title = @"";
    
    self.navigationItem.backBarButtonItem = backitem;
    self.navigationController.navigationBar.tintColor = kColor(0, 216, 165);
    [self.navigationController pushViewController:otherUser animated:YES];
}

-(UIImageView*)imgViewWithFrame:(CGRect)frame
{
    UIImageView *imgView = [[UIImageView alloc]initWithFrame:frame];
    
    imgView.layer.cornerRadius = frame.size.width*0.01;
    imgView.clipsToBounds = YES;
    imgView.layer.borderColor =[UIColor purpleColor].CGColor;
    //imgView.layer.borderWidth = 1.0f;
   // [imgView setNeedsDisplay]; //write to progress dowmload
    
    return imgView;

}

-(void)pushScrollView
{
    [UIScrollView beginAnimations:@"xcodeImageViewAnimation" context:(__bridge void *)(_scrollView)];
    //设置动画时间为1s
    [UIScrollView setAnimationDuration:1.0f];
    //接受动画代理
    [UIScrollView setAnimationDelegate:self];
    
    /* 设置ScrollView推过来 */
    [_scrollView setFrame:CGRectMake(0,50,kWidth-50,kHeight-44-100)];
    
    [UIView animateWithDuration:1.0f delay:1.0f options:UIViewAnimationOptionBeginFromCurrentState animations:^{
         [_scrollView setFrame:CGRectMake(0,0,kWidth,kHeight-49)];
            _scrollView.contentSize = CGSizeMake(kWidth *(self.templeteViewM.count+1), kHeight-49);

        
    } completion:^(BOOL finished) {
        

    }];
    //提交动画
    [UIScrollView commitAnimations];
}

    

#pragma mark -- load data

//喜欢作品
-(void)likeToServiceWithid:(int)likeId
{
    NSString *likeUrl = [NSString stringWithFormat:@"%@%@",HOST,@"works/like"];
    NSDictionary *parameter = @{@"id":[NSNumber numberWithInt:likeId],//这个值要根据作品获取
                                kAuthCode:[[NSUserDefaults standardUserDefaults] objectForKey:kAuthCode],
                                kDeviceToken:[[NSUserDefaults standardUserDefaults] objectForKey:kDeviceToken]};
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc]init];
    [manager POST:likeUrl parameters:parameter success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"%@",responseObject);
        if ([[responseObject objectForKey:@"code"] intValue] == 1) {
            
            likeImage.image=[UIImage imageNamed:@"like1"];

        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"like error:%@",error);
    }];
}

//取消喜欢
-(void)cancelLikeToServiceWithCancelId:(int)cancelId
{
    NSString *cancelStr = [NSString stringWithFormat:@"%@%@",HOST,@"topic/concern/dislike"];
    NSDictionary *parameter = @{@"id":[NSNumber numberWithInt:cancelId],//这个值要根据作品获取
                                kAuthCode:[[NSUserDefaults standardUserDefaults] objectForKey:kAuthCode],
                                kDeviceToken:[[NSUserDefaults standardUserDefaults] objectForKey:kDeviceToken]};
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager POST:cancelStr parameters:parameter success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if ([[responseObject objectForKey:@"code"] intValue]==1) {
            
            likeImage.image=[UIImage imageNamed:@"xihuan"];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        NSLog(@"cancel error:%@",error);
    }];
}

//作品
-(void)loadArticleDetailWithArticleId:(NSString*)articleId
{
    NSString *strUrl = [NSString stringWithFormat:@"%@%@%@",HOST,@"works/",articleId];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:strUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject)
    {
        if ([[responseObject objectForKey:@"code"] integerValue] == 1) {
            if (![[responseObject objectForKey:@"data"]isEqual:[NSNull null]]) {
                
                for (NSDictionary *dic in [[responseObject objectForKey:@"data"] objectForKey:@"worksContents"]) {
                    [self.templeteViewM addObject:dic];
                }
                
                [self buildScrollView];
               
                self.navLabel.text = [NSString stringWithFormat:@"%d/%ld",1,self.templeteViewM.count];

                
            }
        }else{
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[responseObject objectForKey:@"msg"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
        }
        
        NSLog(@"content: %@",responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        NSLog(@"article error:%@",error);
    }];

    
}

-(void)back
{
    //self.navigationController.navigationBarHidden=YES;
    self.navigationController.navigationBar.alpha = 0;
    [self.navigationController popViewControllerAnimated:YES];
}

//回到话题
-(void)backTopic
{
    [self.navigationController popViewControllerAnimated:YES];
}
//下一篇
-(void)nextOpus
{
    
}


-(void)customLayoutTemplete:(templeteView*)templete withIndex:(NSInteger)index withOrder:(int)orderNum rate:(float)rate
{
    switch (index) {
        case 1:
        {
            [templete buildStyle1WithImageWithUrl:[self.templeteViewM[orderNum] objectForKey:kImage]  textColer:kColor(74, 74, 74) title:[self.templeteViewM[orderNum] objectForKey:kTitle] content:[self.templeteViewM[orderNum]objectForKey:kContent] vc:self fontRate:rate];

        }
            break;
        case 2:
        {
            [templete buildStyle2WithImageWithUrl:[self.templeteViewM[orderNum] objectForKey:kImage] textColer:kColor(74, 74, 74) title:[self.templeteViewM[orderNum] objectForKey:kTitle] content:[self.templeteViewM[orderNum]objectForKey:kContent] vc:self fontRate:rate];

        }
            break;
            
        case 3:
        {
            [templete buildStyle3WithImageWithUrl:[self.templeteViewM[orderNum] objectForKey:kImage] textColer:kColor(74, 74, 74) title:[self.templeteViewM[orderNum] objectForKey:kTitle] content:[self.templeteViewM[orderNum] objectForKey:kContent] vc:self fontRate:rate];

        }
            
            break;
        case 4:
        {
            [templete buildStyle4WithImageWithUrl:[self.templeteViewM[orderNum] objectForKey:kImage] textColer:[UIColor whiteColor] title:[self.templeteViewM[orderNum] objectForKey:kTitle] content:[self.templeteViewM[orderNum] objectForKey:kContent] vc:self fontRate:rate];

        }
            
            break;
        case 5:
        {
            
            [templete buildStyle5WithTextColer:kColor(74, 74, 74) title:[self.templeteViewM[orderNum]objectForKey:kTitle] content:[self.templeteViewM[orderNum]objectForKey:kContent] fontRate:rate vc:self];
        }
            
            break;
            
        case 6:
        {
            
            [templete buildStyle6WithTextColer:kColor(74, 74, 74) title:[self.templeteViewM[orderNum]objectForKey:kTitle] content:[self.templeteViewM[orderNum] objectForKey:kContent] fontRate:rate vc:self];
        }
            
            break;
        case 7:
        {
            
            [templete buildStyle7WithTextColer:kColor(74, 74, 74) title:[self.templeteViewM[orderNum]objectForKey:kTitle]content:[self.templeteViewM[orderNum]objectForKey:kContent]fontRate:rate vc:self];
        }
            
            break;
            
        case 8:
        {
            [templete buildStyle8WithImageWithUrl:[self.templeteViewM[orderNum] objectForKey:kImage] vc:self];

        }
            
            break;
            
        default:
            break;
    }
    
}


#pragma mark -- scrollView delegate

-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    NSInteger xOff = (int)scrollView.contentOffset.x/kWidth+1;
    
    self.navLabel.text = [NSString stringWithFormat:@"%ld/%ld",xOff,self.templeteViewM.count+1];
    

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
