//
//  shaKerTopicViewController.h
//  xike
//
//  Created by MarilynEric on 15/7/10.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "common.h"
#import "shakerTopicCell.h"
#import "shakerTopcOnlyTextCell.h"
#import "ObtainPictureViewController.h"
#import "StartViewController.h"
#import "contentViewController.h"
@interface shaKerTopicViewController : UIViewController
@property(copy, nonatomic) NSString *fromTopic;
@property(copy, nonatomic) NSString *listTopicId;
@end
