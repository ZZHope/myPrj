//
//  userTopicViewController.m
//  xike
//
//  Created by MarilynEric on 15/7/13.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "userTopicViewController.h"
#import "Networking.h"
#import "AFNetworking.h"
#import "ShareEngine.h"
#import "ObtainPictureViewController.h"
#import "Topic.h"
#import "UIImageView+WebCache.h"
#import "shakerTopicCell.h"


@interface userTopicViewController ()<UITableViewDelegate,UITableViewDataSource,ShakerTopicCellDelegate>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)UIView *runView;
@property(nonatomic,strong)NSMutableDictionary *headerDicM;
@property(nonatomic,strong)NSMutableArray *worksArrM;
@end

@implementation userTopicViewController
{
    UILabel *titleLabel;
    UILabel *contentLabel;
    UIImageView *faceImageView;
    UIButton *userButton;
    UILabel *partakeAndAttentionLabel;
    UIImageView *backGroundImage;
    
    UIView *blackView;
    
    UIView *Sview;
    UITapGestureRecognizer *giveUpTap;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    //self.navigationController.navigationBarHidden=YES;
    
    [self prefersStatusBarHidden];
    
    _headerDicM=[NSMutableDictionary new];
    _worksArrM = [NSMutableArray array];
    
    UIImage *backImg=[UIImage imageNamed:@"BackArrow"];
    UIButton *backImgViewBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    //    backImgView.backgroundColor=[UIColor redColor];
    backImgViewBtn.frame=CGRectMake(0, 0, backImg.size.width, backImg.size.height);
    [backImgViewBtn setImage:backImg forState:UIControlStateNormal];
    [backImgViewBtn addTarget:self action:@selector(leftBackBtnClick) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftItemCuston=[[UIBarButtonItem alloc]initWithCustomView:backImgViewBtn];
    self.navigationItem.leftBarButtonItem=leftItemCuston;
    
    UIImage *shareImage=[UIImage imageNamed:@"LineCopy 4"];
    UIButton *shareImgViewBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    shareImgViewBtn.frame=CGRectMake(0, 0, shareImage.size.width, shareImage.size.height);
    [shareImgViewBtn setImage:shareImage forState:UIControlStateNormal];
    [shareImgViewBtn addTarget:self action:@selector(rightShareBtnClick) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *rightItemCuston=[[UIBarButtonItem alloc]initWithCustomView:shareImgViewBtn];
    self.navigationItem.rightBarButtonItem=rightItemCuston;
    
    self.navigationController.navigationBar.alpha = 0;
    
    [self buildTabBar];
    
    [self buildTableView];
    
    [self buildBackBlackView];
    
    [self loadDataFromServerWithTopicId:self.listTopicId];
}

-(void)viewWillAppear:(BOOL)animated
{
    self.navigationController.navigationBar.alpha = 0;
}


- (BOOL)prefersStatusBarHidden
{
    return YES;//隐藏为YES，显示为NO
}

-(void)buildTabBar
{
    //自定义 tabbar 的 我要参与
    UIView *tabBarView=[[UIView alloc]initWithFrame:CGRectMake(0, self.view.bounds.size.height-49, self.view.bounds.size.width, 49)];
    tabBarView.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:tabBarView];
    
    UIButton *joinBtn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    joinBtn.frame=CGRectMake(self.view.frame.size.width/4, 0, self.view.frame.size.width/2, 49);
    [joinBtn setTitle:@"我要参与" forState:UIControlStateNormal];
    [joinBtn setTitleColor:[UIColor colorWithRed:0/255.0 green:216/255.0 blue:165/255.0 alpha:1] forState:UIControlStateNormal];
    [joinBtn addTarget:self action:@selector(iWantToJoinIt) forControlEvents:UIControlEventTouchUpInside];
    [tabBarView addSubview:joinBtn];
    
    UIView *lineView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 1)];
    lineView.backgroundColor=[UIColor colorWithRed:167/255.0 green:167/255.0 blue:167/255.0 alpha:1.0];
    [tabBarView addSubview:lineView];
}

-(void)buildBackBlackView
{
    blackView=[[UIView alloc]initWithFrame:CGRectMake(0, kHeight, kWidth, kHeight*0.7)];
    blackView.backgroundColor=[UIColor blackColor];
    blackView.alpha=0.5;
    giveUpTap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(giveUpShareTap)];
    
    
    [blackView addGestureRecognizer:giveUpTap];
    
    Sview=[[UIView alloc]initWithFrame:CGRectMake(0, kHeight+kHeight*0.7, kWidth, kHeight*0.3)];
    Sview.backgroundColor=[UIColor whiteColor];
    
    UIButton *weiXinButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    weiXinButton.frame=CGRectMake(kWidth*0.1, 10, kWidth*0.2, (kWidth*0.2)/0.71);
    [weiXinButton setImage:[[UIImage imageNamed:@"wechat" ]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forState:UIControlStateNormal];
    [weiXinButton addTarget:self action:@selector(weChatShare) forControlEvents:UIControlEventTouchUpInside];
    [Sview addSubview:weiXinButton];
    
    UIButton *momentsButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    momentsButton.frame=CGRectMake(kWidth*0.4, 10, kWidth*0.2, (kWidth*0.2)/0.71);
    [momentsButton setImage:[[UIImage imageNamed:@"moments" ]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forState:UIControlStateNormal];
    [momentsButton addTarget:self action:@selector(momentsShare) forControlEvents:UIControlEventTouchUpInside];
    [Sview addSubview:momentsButton];
    
    UIButton *weiBoButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    weiBoButton.frame=CGRectMake(kWidth*0.7, 10, kWidth*0.2, (kWidth*0.2)/0.71);
    [weiBoButton setImage:[[UIImage imageNamed:@"weBo" ]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forState:UIControlStateNormal];
    [weiBoButton addTarget:self action:@selector(weBoShare) forControlEvents:UIControlEventTouchUpInside];
    [Sview addSubview:weiBoButton];
    
    UIButton *cancelButton =[UIButton buttonWithType:UIButtonTypeRoundedRect];
    cancelButton.frame=CGRectMake(kWidth*0.1, 10+weiXinButton.frame.size.height+10, kWidth*0.8, (Sview.frame.size.height-10-weiXinButton.frame.size.height)/2);
    [cancelButton setTitle:@"取消" forState:UIControlStateNormal];
    cancelButton.backgroundColor=kColor(0, 216, 165);
    [cancelButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [cancelButton.layer setCornerRadius:3];
    [cancelButton addTarget:self action:@selector(giveUpShareTap) forControlEvents:UIControlEventTouchUpInside];
    [Sview addSubview:cancelButton];
    
    [self.view addSubview:Sview];
    [self.view addSubview:blackView];
}

-(void)buildTableView
{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kHeight-49) style:UITableViewStyleGrouped];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    
    [self.view addSubview:_tableView];
}

//设置有几个section  默认为1
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

//设置每个section中有多少个cell
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.worksArrM.count;
}


//绘制tableViewCell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier1 = @"id";
    shakerTopicCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier1];
    if (nil == cell) {
        cell =  [[NSBundle mainBundle] loadNibNamed:@"shakerTopicCell" owner:self options:nil][0];
        cell.delegate = self;
    }
    
    [cell.profileCreator sd_setImageWithURL:[NSURL URLWithString:[self.worksArrM[indexPath.row] objectForKey:@"createUserPhoto"]]];
    [cell.creatorName setTitle:[self.worksArrM[indexPath.row] objectForKey:@"createUser"] forState:UIControlStateNormal];
    cell.timeDuration.text = [self.worksArrM[indexPath.row] objectForKey:@"createDateStr"];
    cell.topicTitle.text = [self.worksArrM[indexPath.row] objectForKey:@"title"];
    [cell.topicTitle sizeToFit];
    cell.textlabel.text = [self.worksArrM[indexPath.row] objectForKey:@"content"];
    cell.commentNumL.text = [NSString stringWithFormat:@"%@",[self.worksArrM[indexPath.row]objectForKey:@"comments"]];
    cell.likeNumL.text = [NSString stringWithFormat:@"%@",[self.worksArrM[indexPath.row] objectForKey:@"likes"]];
    cell.pagesNumL.text = [NSString stringWithFormat:@"%@",[self.worksArrM[indexPath.row]objectForKey:@"pageTotal"]]; //页数
    cell.attentionButton.tag = indexPath.row+1000;
    if ([[self.worksArrM[indexPath.row] objectForKey:@"concern"] intValue] == 0) {
        cell.attentionButton.userInteractionEnabled = YES;
        [cell.attentionButton setTitle:@"关注" forState:UIControlStateNormal];
        [cell.attentionButton setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
        cell.attentionButton.layer.borderColor = [kColor(0, 216, 165) CGColor];
        cell.attentionButton.layer.borderWidth = 1.0f;
    }else{
        [cell.attentionButton setTitle:@"" forState:UIControlStateNormal];
        [cell.attentionButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        cell.attentionButton.layer.borderColor = [[UIColor whiteColor] CGColor];
        cell.attentionButton.layer.borderWidth = 0.0f;
        cell.attentionButton.userInteractionEnabled = NO;

    }
    [cell.articleCoverView sd_setImageWithURL:[NSURL URLWithString:[self.worksArrM[indexPath.row]objectForKey:@"logo"]]];
    
    
    
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    return cell;
}
#pragma mark -- UITableViewDelegate
//设置每个cell的高度
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 640;
}

//设置section header的高度
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return kWidth+kHeight*0.07;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.1;
}

//cell的响应  当选择cell是调用
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    contentViewController *minute=[[contentViewController alloc]init];
    minute.articleId = [self.worksArrM[indexPath.row] objectForKey:@"id"];
    minute.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:minute animated:YES];
}

//设置头视图中的view；
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view=[[UIView alloc]init];
    view.backgroundColor=[UIColor whiteColor];
    
    if (self.headerDicM.count) {
        
        //背景图
        backGroundImage=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kWidth)];
        backGroundImage.backgroundColor=[UIColor whiteColor];
        backGroundImage.userInteractionEnabled = YES;
        [backGroundImage sd_setImageWithURL:[self.headerDicM objectForKey:@"logo"]];
        [view addSubview:backGroundImage];
        
        //一个半透明黑底的view
        UIView *blackAlpha=[[UIView alloc]initWithFrame:CGRectMake(0, 0, backGroundImage.frame.size.width, backGroundImage.frame.size.height)];
        blackAlpha.backgroundColor=[UIColor blackColor];
        blackAlpha.alpha=0.3;
        [backGroundImage addSubview:blackAlpha];
        
        //左面返回按钮
        UIButton *leftBackBtn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
        leftBackBtn.frame=CGRectMake(10, 15, 30, 30);
        //leftBackBtn.backgroundColor = [UIColor yellowColor];
        [leftBackBtn setImage:[[UIImage imageNamed:@"back"]  imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forState:UIControlStateNormal];
        [leftBackBtn addTarget:self action:@selector(leftBackBtnClick) forControlEvents:UIControlEventTouchUpInside];
        [backGroundImage addSubview:leftBackBtn];
        
        //右面分享按钮
        UIButton *rightShareBtn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
        rightShareBtn.frame=CGRectMake(kWidth-40, 15, 30, 30);
        [rightShareBtn setImage:[[UIImage imageNamed:@"fenxiang2"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal ] forState:UIControlStateNormal];
        [rightShareBtn addTarget:self action:@selector(rightShareBtnClick) forControlEvents:UIControlEventTouchUpInside];
        [backGroundImage addSubview:rightShareBtn];
        
        //标题
        titleLabel=[[UILabel alloc]initWithFrame:CGRectMake(15, backGroundImage.frame.size.height*0.15, kWidth-30, kWidth*0.16)];
        titleLabel.backgroundColor=[UIColor clearColor];

        titleLabel.text=[self.headerDicM objectForKey:@"title"];

        titleLabel.textColor=[UIColor whiteColor];
        titleLabel.numberOfLines=2;
        titleLabel.font=[UIFont systemFontOfSize:22];
        titleLabel.font=[UIFont boldSystemFontOfSize:21];
        [backGroundImage addSubview:titleLabel];
        
        //内容label
        contentLabel=[[UILabel alloc]initWithFrame:CGRectMake(15, titleLabel.frame.origin.y+titleLabel.frame.size.height+10, kWidth-30, backGroundImage.frame.size.height*0.29)];
        contentLabel.backgroundColor=[UIColor clearColor];
           
        contentLabel.text=[self.headerDicM objectForKey:@"content"];
        
        contentLabel.textColor=[UIColor whiteColor];
        contentLabel.numberOfLines=4;
        contentLabel.font=[UIFont systemFontOfSize:12];
        contentLabel.font=[UIFont boldSystemFontOfSize:14];
        [backGroundImage addSubview:contentLabel];
        
        //调整行间距
        if (contentLabel.text.length) {
            
            NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:contentLabel.text];
            NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
            
            [paragraphStyle setLineSpacing:LINESPACE2];//调整行间距
            
            [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [contentLabel.text length])];
            contentLabel.attributedText = attributedString;

        }
        
        //关注话题按钮
        //===========================================>>>>>>>>>> 点击 “关注话题”按钮 按钮变为已关注 个人主页的关注＋1
        UIButton *attentionTopicBtn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
        attentionTopicBtn.frame=CGRectMake(15, contentLabel.frame.origin.y+contentLabel.frame.size.height+10, kWidth*0.18, kWidth*0.06);
        [attentionTopicBtn setTitle:@"关注话题" forState:UIControlStateNormal];
        [attentionTopicBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [attentionTopicBtn.layer setCornerRadius:1];
        [attentionTopicBtn.layer setBorderWidth:1];
        attentionTopicBtn.layer.borderColor = [UIColor whiteColor].CGColor;
        attentionTopicBtn.titleLabel.font=[UIFont systemFontOfSize:12];
        attentionTopicBtn.titleLabel.font=[UIFont boldSystemFontOfSize:12];
        [backGroundImage addSubview:attentionTopicBtn];
        //===========================================>>>>>>>>>> 点击 “关注话题”按钮 按钮变为已关注 个人主页的关注＋1
        
        
        //创建话题发起人头像
        //===========================================>>>>>>>>>>传过来话题发起人的 头像！！
        faceImageView=[[UIImageView alloc]initWithFrame:CGRectMake(15, attentionTopicBtn.frame.origin.y+attentionTopicBtn.frame.size.height+20, /*kWidth*0.12*/45, /*kWidth*0.12*/45)];
        faceImageView.backgroundColor=kColor(0, 216, 165);
        [faceImageView sd_setImageWithURL:[self.headerDicM objectForKey:@"createUserPhoto"]];
        //给image加手势
        UITapGestureRecognizer *goUser=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(goUserTap:)];
        [faceImageView addGestureRecognizer:goUser];
        goUser.numberOfTapsRequired = 1; // 单击;
        faceImageView.userInteractionEnabled = YES;
        [backGroundImage addSubview:faceImageView];
        //===========================================>>>>>>>>>>传过来话题发起人的 头像！！
        
        
        UILabel *buildPeople=[[UILabel alloc]initWithFrame:CGRectMake(faceImageView.frame.origin.x+faceImageView.frame.size.width+10, faceImageView.frame.origin.y, kWidth/3, 20)];
        buildPeople.text=@"创建人";
        buildPeople.textColor=[UIColor whiteColor];
        buildPeople.font=[UIFont systemFontOfSize:10];
        buildPeople.font=[UIFont boldSystemFontOfSize:14];
        [backGroundImage addSubview:buildPeople];
        
        //创建人的名字button
        userButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];
        //===========================================>>>>>>>>>>>传过来话题创建人的 名字！！！
        [userButton setTitle:[self.headerDicM objectForKey:@"createUser"] forState:UIControlStateNormal];
        //===========================================>>>>>>>>>>>传过来话题创建人的 名字！！！
        userButton.frame=CGRectMake(buildPeople.frame.origin.x, buildPeople.frame.origin.y+buildPeople.frame.size.height, kWidth/2, 22);
        userButton.backgroundColor=[UIColor clearColor];
        [userButton addTarget:self action:@selector(goOtherUser) forControlEvents:UIControlEventTouchUpInside];
        [userButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        userButton.titleLabel.font=[UIFont systemFontOfSize:16];
        [userButton sizeToFit];
        [backGroundImage addSubview:userButton];
        
        //创建有多少人参与 多少人关注的label
        partakeAndAttentionLabel=[[UILabel alloc]initWithFrame:CGRectMake(userButton.frame.origin.x+userButton.frame.size.width, userButton.frame.origin.y, kWidth-userButton.frame.origin.x-userButton.frame.size.width-15, userButton.frame.size.height)];
        partakeAndAttentionLabel.backgroundColor=[UIColor clearColor];
        //=======================================>>>>>>>>>>>传过来 多少人参与 多少人关注！！
        partakeAndAttentionLabel.text=[self.headerDicM objectForKey:@"postsAndConcerns"];
        //=======================================>>>>>>>>>>>传过来 多少人参与 多少人关注！！
        partakeAndAttentionLabel.textColor=[UIColor whiteColor];
        partakeAndAttentionLabel.textAlignment=NSTextAlignmentRight;
        partakeAndAttentionLabel.font=[UIFont systemFontOfSize:10];
        //[partakeAndAttentionLabel sizeToFit];
        [backGroundImage addSubview:partakeAndAttentionLabel];
        
        
        //最热button
        UIButton *bestHot=[UIButton buttonWithType:UIButtonTypeRoundedRect];
        bestHot.frame=CGRectMake(0, backGroundImage.frame.size.height, kWidth/2-1,kHeight*0.07-1 );
        [bestHot setTitle:@"最热" forState:UIControlStateNormal];
        [bestHot setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
        bestHot.backgroundColor=[UIColor whiteColor];
        bestHot.tag=901;
        [bestHot addTarget:self action:@selector(bestNewOrHotClick:) forControlEvents:UIControlEventTouchUpInside];
        [view addSubview:bestHot];
        
        //最新button
        UIButton *bestNew=[UIButton buttonWithType:UIButtonTypeRoundedRect];
        bestNew.frame=CGRectMake(bestHot.frame.size.width+2, bestHot.frame.origin.y, bestHot.frame.size.width, bestHot.frame.size.height);
        [bestNew setTitle:@"最新" forState:UIControlStateNormal];
        [bestNew setTitleColor:kColor(167, 167, 167) forState:UIControlStateNormal];
        bestNew.backgroundColor=[UIColor whiteColor];
        bestNew.tag=902;
        [bestNew addTarget:self action:@selector(bestNewOrHotClick:) forControlEvents:UIControlEventTouchUpInside];
        [view addSubview:bestNew];
        
        _runView=[[UIView alloc]initWithFrame:CGRectMake(0, bestHot.frame.origin.y+bestHot.frame.size.height, bestHot.frame.size.width, 1)];
        _runView.backgroundColor=kColor(0, 216, 165);
        [view addSubview:_runView];
        
        UIView *midView=[[UIView alloc]initWithFrame:CGRectMake(bestHot.frame.size.width, bestHot.frame.origin.y+bestHot.frame.size.height*0.3, 1, bestHot.frame.size.height*0.4)];
        midView.backgroundColor=kColor(216, 216, 216);
        [view addSubview:midView];

    }
    
    
    
    return view;
}
//nav左边返回按钮响应
-(void)leftBackBtnClick
{
    self.navigationController.navigationBarHidden=NO;
    [self.navigationController popViewControllerAnimated:YES];
}
//nav右面分享按钮响应
-(void)rightShareBtnClick
{
//    [self wechatSessionShare];
  
        //
        //注册通知
//        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeNavgation) name:@"changeNav" object:nil];
    
        
        //[self sinaWeiboShare];
        [UIView animateWithDuration:0.3f animations:^{
            [blackView setFrame:CGRectMake(0, 0, kWidth, kHeight*0.7)];
        }];
        
        [UIView animateWithDuration:0.3f animations:^{
            [Sview setFrame:CGRectMake(0, kHeight*0.7, kWidth, kHeight*0.3)];
        }];

}

-(void)giveUpShareTap
{
    [UIView animateWithDuration:0.3f animations:^{
        [blackView setFrame:CGRectMake(0, kHeight, kWidth, kHeight*0.7)];
    }];
    
    [UIView animateWithDuration:0.3f animations:^{
        [Sview setFrame:CGRectMake(0, kHeight+kHeight*0.7, kWidth, kHeight*0.3)];
    }];
    
    //[blackView removeGestureRecognizer:giveUpTap];
}

-(void)weChatShare
{
    [self wechatSessionShare];
}
-(void)weBoShare
{
    [self sinaWeiboShare];
}
//-(void)momentsShare
//{
//    [self wechatTimelineShare];
//}


//tabbar上的我要参与按钮响应
-(void)iWantToJoinIt
{
     self.navigationController.navigationBarHidden=NO;
    if ([[NSUserDefaults standardUserDefaults] boolForKey:isLogin]) {
        
        ObtainPictureViewController *obtainPhoto = [[ObtainPictureViewController alloc]init];
        obtainPhoto.creatTopicId=[self.headerDicM objectForKey:@"id"];
        [self.navigationController pushViewController:obtainPhoto animated:YES];
        
        
    }else{
        
        StartViewController *startVC = [[StartViewController alloc]init];
        [self.navigationController pushViewController:startVC animated:YES];
        
    }
}
//进入其他用户的主页
-(void)goOtherUser
{
    otherUserViewController *otherUser=[[otherUserViewController alloc]init];
    otherUser.fromTopic = FromTopic;
    otherUser.hidesBottomBarWhenPushed = YES;
    UIBarButtonItem *backitem = [[UIBarButtonItem alloc]init];
    backitem.title = @"";
    self.navigationItem.backBarButtonItem = backitem;
    self.navigationController.navigationBar.tintColor = kColor(0, 216, 165);
    [self.navigationController pushViewController:otherUser animated:YES];
    
}

//点击用户头像进入用户主页
-(void)goUserTap:(UITapGestureRecognizer *)tap
{
    otherUserViewController *otherUser=[[otherUserViewController alloc]init];
    otherUser.fromTopic = FromTopic;
    otherUser.hidesBottomBarWhenPushed = YES;
    UIBarButtonItem *backitem = [[UIBarButtonItem alloc]init];
    backitem.title = @"";
    self.navigationItem.backBarButtonItem = backitem;
    self.navigationController.navigationBar.tintColor = kColor(0, 216, 165);
    [self.navigationController pushViewController:otherUser animated:YES];
}

NSInteger bestNewAndHotTag2 = 901;
-(void)bestNewOrHotClick:(UIButton *)sender
{
    UIButton *cusBtn = (UIButton *)[self.view viewWithTag:bestNewAndHotTag2];
    [cusBtn setTitleColor:kColor(167, 167, 167) forState:UIControlStateNormal];
    
    switch (sender.tag) {
        case 901:
        {
            [sender setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
            [UIView animateWithDuration:0.5 animations:^{
                _runView.center = CGPointMake(sender.center.x, _runView.center.y);
                
            }];
        }
            break;
        case 902:
        {
            [sender setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
            [UIView animateWithDuration:0.5 animations:^{
                _runView.center = CGPointMake(sender.center.x, _runView.center.y);
                
            }];
        }
        default:
            break;
    }
    
    bestNewAndHotTag2 = sender.tag;
}

#pragma mark -- load data
-(void)loadDataFromServerWithTopicId:(NSString*)topicId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSString *strUrl = [NSString stringWithFormat:@"%@%@%@",HOST,@"topic/",topicId];
    NSDictionary *parameter = @{@"deviceToken":[[NSUserDefaults standardUserDefaults] objectForKey:kDeviceToken],
                                @"authCode":[[NSUserDefaults standardUserDefaults] objectForKey:kAuthCode]
                                };
    
    [manager GET:strUrl parameters:parameter success:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         if ([[responseObject objectForKey:@"code"] integerValue] == 1) {
             
             NSLog(@"topic check:%@",responseObject);
             
             if (![[responseObject objectForKey:@"data"] isEqual:[NSNull null]]) {
                 [self.worksArrM removeAllObjects];
                 
                 [self.headerDicM setObject:[[responseObject objectForKey:@"data"] objectForKey:@"title"] forKey:@"title"];
                 
                 [self.headerDicM setObject:[[responseObject objectForKey:@"data"] objectForKey:@"content"] forKey:@"content"];
                 [self.headerDicM setObject:[[responseObject objectForKey:@"data"]objectForKey:@"createUserPhoto"] forKey:@"createUserPhoto"];
                 
                 [self.headerDicM setObject:[[responseObject objectForKey:@"data"] objectForKey:@"createUser"] forKey:@"createUser"];
                 
                 [self.headerDicM setObject:[NSString stringWithFormat:@"%ld人参与/%ld人关注",[[[responseObject objectForKey:@"data"] objectForKey:@"posts"]integerValue],[[[responseObject objectForKey:@"data"] objectForKey:@"concerns"]integerValue]] forKey:@"postsAndConcerns"];
                 
                 [self.headerDicM setObject:[[responseObject objectForKey:@"data"] objectForKey:@"logo"] forKey:@"logo"];
                 
                 [self.headerDicM setObject:[[responseObject objectForKey:@"data"] objectForKey:@"id"]forKey:@"id"];
                 
                 for (NSDictionary *dic in [[responseObject objectForKey:@"data"] objectForKey:@"works"]){
                     
                     
                     [self.worksArrM addObject:dic];
                     
                 }
                 
                 [self.tableView reloadData];

             }
             
         }
         
         
     } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
         NSLog(@"topic detail error:%@",error);
     }];
}

#pragma mark Share Button Actions
- (void)wechatSessionShare {
    NSString *theme = [@"testWechat" stringByAppendingString:@":"];
    // UIImage *image = [UIImage imageWithOriginImage:[UIImage imageNamed:@"3"] scaledToSize:CGSizeMake(220, 148)];
    //UIImage *image = [UIImage imageNamed:@"layout1_79122"];
    NSString *content = @"testtest";
    NSString *URLString = [[NSString alloc] initWithFormat:@"%@",@"http://v1.qzone.cc/pic/201507/02/21/05/559536ff424f2614.jpg!600x600.jpg"];
    [[ShareEngine sharedInstance] sendLinkContent:WXSceneSession :theme :content :[UIImage imageNamed:@"3"] :[NSURL URLWithString:URLString]];
    
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
   
      self.navigationController.navigationBar.alpha = self.tableView.contentOffset.y/500;
    
}

#pragma mark -- shakerCell delegate

-(void)shakerTopicCellFocusClickWithButton:(UIButton *)sender
{
    NSString *strUrl = [NSString stringWithFormat:@"%@%@",HOST,@"site/user/concern/add"];
    NSDictionary *para = @{@"concernUserId":[self.worksArrM[sender.tag-1000]objectForKey:@"createUserId"],
                           @"authCode":[[NSUserDefaults standardUserDefaults] objectForKey:kAuthCode],
                           @"deviceToken":[[NSUserDefaults standardUserDefaults] objectForKey:kDeviceToken]};
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager POST:strUrl parameters:para success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"===topicdetail:%@",responseObject);
        if ([[responseObject objectForKey:@"code"] integerValue] == 1) {
            NSMutableDictionary *tempDic = [NSMutableDictionary dictionaryWithDictionary:self.worksArrM[sender.tag-1000]];
            [tempDic setObject:@1 forKey:@"concern"];
            [self.worksArrM replaceObjectAtIndex:sender.tag-1000 withObject:tempDic];
            
            [self.tableView reloadData];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"focus error:%@",error);
    }];
}


#pragma mark -- share weibo
- (void)sinaWeiboShare {
    
    NSString *content = @"test";
    NSString *URLString = [[NSString alloc] initWithFormat:@"%@%@%@",@"http://v2.shaker.mobi",@"/entity/",@"a6618832-39f5-4e04-91ff-7ed57f40d2be"];
    [[ShareEngine sharedInstance] sendWBLinkeContent:content :@"shaker test" :[UIImage imageNamed:@"xiangji"] :[NSURL URLWithString:URLString]];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
