//
//  Recommend.h
//  xike
//
//  Created by shaker on 15/8/4.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Recommend : NSObject
@property(nonatomic, copy) NSString *creatDate;
@property(nonatomic, copy) NSString *creatUser;
@property(nonatomic, assign) NSInteger creatUserId;
@property(nonatomic, copy) NSString *creatUserPhoto;
@property(nonatomic, copy) NSString *img;
@property(nonatomic, assign) NSInteger recomendId;
@property(nonatomic, assign) NSInteger orderIndex;
@property(nonatomic, copy) NSString *title;
@property(nonatomic, copy) NSString *content;
@property(nonatomic, assign) NSInteger topicId;

@end
