//
//  RecommendViewController.m
//  xike
//
//  Created by shaker on 15/6/1.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "RecommendViewController.h"
#import "common.h"
#import "recommendCell.h"
#import "AFNetworking.h"
#import "Networking.h"
#import "UIImageView+WebCache.h"
#import "UserSingleton.h"
#import "Recommend.h"
#import "MyProgressView.h"
#import "MyAlertView.h"


@interface RecommendViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)NSMutableArray *recommendImageData;
@property(nonatomic,strong) Recommend *recommend;
@property(nonatomic,strong) MyProgressView *progressView;
@end

@implementation RecommendViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    //记录tabbarItem
    [UserSingleton shareUserSingleton].tabItemIndex = @"0";
    
    //self.navigationController.navigationBar.translucent= NO;
    self.navigationItem.titleView = [[UIImageView alloc] initWithImage: [UIImage imageNamed:@"logo"]];
    [self buildTableView];

    

    
    _recommendImageData=[NSMutableArray new];
    
    //model
    _recommend = [[Recommend alloc]init];
    
    //progress

    _progressView = [[MyProgressView alloc]initWithFrame:CGRectMake(0, 0, kWidth,kWidth)];
    

}

-(void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    
    RecommendViewController *recommendVC = self;
    [self.tableView addLegendHeaderWithRefreshingBlock:^{
        [recommendVC loadRecommendPageDataFromServer];
    }];
    
    [self.tableView.header setTitle:@"稀客正在为您刷新。。。" forState:MJRefreshHeaderStatePulling];

    [self.tableView.header beginRefreshing];
    [MobClick beginLogPageView:@"RecommendViewController"];
    
}

-(void)buildTableView
{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kHeight) style:UITableViewStyleGrouped];
    //_tableView.pagingEnabled = YES; //是否翻页
    _tableView.delegate=self;
    _tableView.dataSource=self;

    
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    //隐藏
    self.tableView.showsVerticalScrollIndicator = NO;
    //修改颜色
    self.tableView.indicatorStyle=UIScrollViewIndicatorStyleWhite;
    
    [self.view addSubview:_tableView];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
   return self.recommendImageData.count;
//   return 0;

}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"id";
    recommendCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    
    if (nil == cell) {
       cell =  [[NSBundle mainBundle] loadNibNamed:@"recommendCell" owner:self options:nil][0];
        
       [cell.contentView addSubview:self.progressView];
    }
   

    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
       [cell.recommendImage sd_setImageWithURL:[NSURL URLWithString:[self.recommendImageData[indexPath.row] img]] placeholderImage:nil options:SDWebImageLowPriority progress:^(NSInteger receivedSize, NSInteger expectedSize) {
           [self.progressView animatProgress:(receivedSize*1.0/expectedSize)];
           
    } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
            [self.progressView removeFromSuperview];
        
        
    }];


    return cell;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.1;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return kWidth+6;
}


//cell的响应  当选择cell是调用
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    shaKerTopicViewController *topic=[[shaKerTopicViewController alloc]init];
    topic.fromTopic = FromTopic;

    topic.listTopicId = [NSString stringWithFormat:@"%ld",[self.recommendImageData[indexPath.row] recomendId]];

    topic.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:topic animated:YES];
}


-(void)loadRecommendPageDataFromServer

{
    [self.tableView.header beginRefreshing];
    NSString *strUrl = [NSString stringWithFormat:@"%@%@",HOST,@"official/topic/list"];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:strUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        [self.tableView.header endRefreshing];
        NSLog(@"recomend :%@ msg:%@",responseObject,[responseObject objectForKey:@"msg"]);
        if ([[responseObject objectForKey:@"code"] intValue] == 1) {
            if (![[responseObject objectForKey:@"data"] isEqual:[NSNull null]]) {
                
                [self.recommendImageData removeAllObjects];
                for (NSDictionary *dic in [[responseObject objectForKey:@"data"] objectForKey:@"rows"]) {
                  
                    Recommend *recom = [[Recommend alloc]init];

                    recom.recomendId = [[dic objectForKey:@"id"] integerValue];
                    recom.img = [dic objectForKey:@"logo"];
                    recom.orderIndex =  [[dic objectForKey:@"orderIndex"] integerValue];
                    recom.title = [dic objectForKey:@"title"];
                    recom.content = [dic objectForKey:@"content"];
                    
                    [self.recommendImageData addObject:recom];

                }
            }
        }
        [self.tableView reloadData];
        [self.tableView.header endRefreshing];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"recommend error:%@",error);
        [self.tableView.header endRefreshing];
        
        UIWindow *window = [[UIApplication sharedApplication] keyWindow];
        [MyAlertView showMessageToView:window];

    }];
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"RecommendViewController"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
