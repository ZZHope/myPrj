//
//  shaKerTopicViewController.m
//  xike
//
//  Created by MarilynEric on 15/7/10.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "shaKerTopicViewController.h"
#import "UIImageView+WebCache.h"
@interface shaKerTopicViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)UIView *underLineView;
@property(nonatomic,strong)UIView *runView;
@property(nonatomic,strong)NSMutableDictionary *headerDicM;
@end

@implementation shaKerTopicViewController
{
    UILabel *partakeAndAttentionLabel;

    //显示内容的label
    UILabel *textLabel;
    
    UIView *blackView;
    
    UIView *Sview;
    
    UITapGestureRecognizer *giveUpTap;
}
-(void)viewWillAppear:(BOOL)animated
{
    self.navigationController.navigationBar.alpha = 0;

}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationController.navigationBarHidden=NO;
    
     _headerDicM=[NSMutableDictionary new];
    
    [self prefersStatusBarHidden];

    UIImage *backImg=[UIImage imageNamed:@"BackArrow"];
    UIButton *backImgViewBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    //    backImgView.backgroundColor=[UIColor redColor];
    backImgViewBtn.frame=CGRectMake(0, 0, backImg.size.width, backImg.size.height);
    [backImgViewBtn setImage:backImg forState:UIControlStateNormal];
    [backImgViewBtn addTarget:self action:@selector(leftBackBtnClick) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftItemCuston=[[UIBarButtonItem alloc]initWithCustomView:backImgViewBtn];
    self.navigationItem.leftBarButtonItem=leftItemCuston;
    
    UIImage *shareImage=[UIImage imageNamed:@"LineCopy 4"];
    UIButton *shareImgViewBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    shareImgViewBtn.frame=CGRectMake(0, 0, shareImage.size.width, shareImage.size.height);
    [shareImgViewBtn setImage:shareImage forState:UIControlStateNormal];
    [shareImgViewBtn addTarget:self action:@selector(rightShareBtnClick1) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *rightItemCuston=[[UIBarButtonItem alloc]initWithCustomView:shareImgViewBtn];
    self.navigationItem.rightBarButtonItem=rightItemCuston;

    self.navigationController.navigationBar.alpha = 0;
    
    
    [self buildTabBar];
    [self buildTableView];
    [self buildBackBlackView];
    [self loadDataFromServerWithTopicId:self.listTopicId];
    
    
}
- (BOOL)prefersStatusBarHidden
{
    return YES;//隐藏为YES，显示为NO
}

-(void)buildTabBar
{
    //自定义的tabbar 我要参与
    UIView *tabBarView=[[UIView alloc]initWithFrame:CGRectMake(0, self.view.bounds.size.height-49, self.view.bounds.size.width, 49)];
    tabBarView.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:tabBarView];
    
    UIButton *joinBtn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    joinBtn.frame=CGRectMake(self.view.frame.size.width/4, 0, self.view.frame.size.width/2, 49);
    [joinBtn setTitle:@"我要参与" forState:UIControlStateNormal];
    [joinBtn setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
    [joinBtn addTarget:self action:@selector(iWantToJoinIt) forControlEvents:UIControlEventTouchUpInside];
    [tabBarView addSubview:joinBtn];
    
    UIView *lineView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 1)];
    lineView.backgroundColor=kColor(167, 167, 167);
    [tabBarView addSubview:lineView];
    
}

-(void)buildBackBlackView
{
    blackView=[[UIView alloc]initWithFrame:CGRectMake(0, kHeight, kWidth, kHeight*0.7)];
    blackView.backgroundColor=[UIColor blackColor];
    blackView.alpha=0.5;
    giveUpTap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(giveUpShareTap)];

    
    [blackView addGestureRecognizer:giveUpTap];
    
    Sview=[[UIView alloc]initWithFrame:CGRectMake(0, kHeight+kHeight*0.7, kWidth, kHeight*0.3)];
    Sview.backgroundColor=[UIColor whiteColor];
    
    UIButton *weiXinButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    weiXinButton.frame=CGRectMake(kWidth*0.1, 10, kWidth*0.2, (kWidth*0.2)/0.71);
    [weiXinButton setImage:[[UIImage imageNamed:@"wechat" ]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forState:UIControlStateNormal];
    [weiXinButton addTarget:self action:@selector(weChatShare) forControlEvents:UIControlEventTouchUpInside];
    [Sview addSubview:weiXinButton];
    
    UIButton *momentsButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    momentsButton.frame=CGRectMake(kWidth*0.4, 10, kWidth*0.2, (kWidth*0.2)/0.71);
    [momentsButton setImage:[[UIImage imageNamed:@"moments" ]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forState:UIControlStateNormal];
    [momentsButton addTarget:self action:@selector(momentsShare) forControlEvents:UIControlEventTouchUpInside];
    [Sview addSubview:momentsButton];
    
    UIButton *weiBoButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    weiBoButton.frame=CGRectMake(kWidth*0.7, 10, kWidth*0.2, (kWidth*0.2)/0.71);
    [weiBoButton setImage:[[UIImage imageNamed:@"weBo" ]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forState:UIControlStateNormal];
    [weiBoButton addTarget:self action:@selector(weBoShare) forControlEvents:UIControlEventTouchUpInside];
    [Sview addSubview:weiBoButton];
    
    UIButton *cancelButton =[UIButton buttonWithType:UIButtonTypeRoundedRect];
    cancelButton.frame=CGRectMake(kWidth*0.1, 10+weiXinButton.frame.size.height+10, kWidth*0.8, (Sview.frame.size.height-10-weiXinButton.frame.size.height)/2);
    [cancelButton setTitle:@"取消" forState:UIControlStateNormal];
    cancelButton.backgroundColor=kColor(0, 216, 165);
    [cancelButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [cancelButton.layer setCornerRadius:3];
    [cancelButton addTarget:self action:@selector(giveUpShareTap) forControlEvents:UIControlEventTouchUpInside];
    [Sview addSubview:cancelButton];
    
    [self.view addSubview:Sview];
    [self.view addSubview:blackView];
}

-(void)buildTableView
{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kHeight-49) style:UITableViewStyleGrouped];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    self.tableView.showsVerticalScrollIndicator = NO;
    [self.view addSubview:_tableView];
}

//设置有几个section  默认为1
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

//绘制tableViewCell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"id";
    shakerTopicCell *cell =[tableView dequeueReusableCellWithIdentifier:identifier];
    if (nil == cell) {
        cell =  [[NSBundle mainBundle] loadNibNamed:@"shakerTopicCell" owner:self options:nil][0];
    
//    static NSString *identifier1 = @"id";
//    shakerTopcOnlyTextCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier1];
//    if (nil == cell) {
//        cell =  [[NSBundle mainBundle] loadNibNamed:@"shakerTopcOnlyTextCell" owner:self options:nil][0];
    }
    
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    return cell;
}
//设置每个section中有多少个cell
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 10;
}

#pragma mark -- UITableViewDelegate
//设置每个cell的高度
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 516;
}

//设置section header的高度
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
//    if (self.view.bounds.size.height==667) {
//        return 630;
//    }else if(self.view.bounds.size.height==480 )
//    {
//        return 536;
//    }else if(self.view.bounds.size.height==568)
//    {
//        return 554;
//    }else{
//        return 683;
//    }
    return kWidth+0.03*kHeight+20+3+20+10+textLabel.frame.size.height+0.03*kHeight+0.05*kHeight+kHeight*0.03+1+kHeight*0.07+1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.1;
}

//cell的响应  当选择cell是调用
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    contentViewController *minute=[[contentViewController alloc]init];
    UIBarButtonItem *backitem = [[UIBarButtonItem alloc]init];
    backitem.title = @"";
    
    //self.navigationItem.backBarButtonItem.title = @"";
    self.navigationItem.backBarButtonItem = backitem;
    self.navigationController.navigationBar.tintColor = kColor(167 , 167, 167);
    minute.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:minute animated:YES];
}


//设置头视图中的view；
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view=[[UIView alloc]init];
    view.backgroundColor=[UIColor whiteColor];
    
    //背景图片
    UIImageView* backGroundImage=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kWidth)];
    backGroundImage.backgroundColor=kColor(216, 216, 216);
//=======================================================>>>>>>传一张背景图
    [backGroundImage sd_setImageWithURL:[self.headerDicM objectForKey:@"logo"]];
//=======================================================>>>>>>传一张背景图
    backGroundImage.userInteractionEnabled = YES;
    [view addSubview:backGroundImage];
    
    //左侧返回按钮
    UIButton *leftBackBtn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    leftBackBtn.frame=CGRectMake(10, 15, 30, 30);
    [leftBackBtn setImage:[[UIImage imageNamed:@"BackArrow"]  imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forState:UIControlStateNormal];
    //leftBackBtn.imageView.userInteractionEnabled=YES;
    [leftBackBtn addTarget:self action:@selector(leftBackBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [backGroundImage addSubview:leftBackBtn];
    
    //右侧分享按钮
    UIButton *rightShareBtn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    rightShareBtn.frame=CGRectMake(kWidth-40, 15, 30, 30);
    [rightShareBtn setImage:[[UIImage imageNamed:@"LineCopy 4"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal ] forState:UIControlStateNormal];
    [rightShareBtn addTarget:self action:@selector(rightShareBtnClick1) forControlEvents:UIControlEventTouchUpInside];
    [backGroundImage addSubview:rightShareBtn];
    
    //稀客说logo
    UIImageView *shakerSayImage=[[UIImageView alloc]initWithFrame:CGRectMake(15, backGroundImage.frame.size.height+0.03*kHeight, kHeight*0.12, kHeight*0.12)];
    shakerSayImage.image=[UIImage imageNamed:@"xikeshuo"];
    [view addSubview:shakerSayImage];
    
    //创建人label
    UILabel *buildPeople=[[UILabel alloc]initWithFrame:CGRectMake(shakerSayImage.frame.origin.x+shakerSayImage.frame.size.width+kWidth*0.05, shakerSayImage.frame.origin.y, 80, 20)];
    buildPeople.text=@"创建人";
    buildPeople.textColor=kColor(167, 167, 167);
    buildPeople.font=[UIFont systemFontOfSize:12.0f];
    [view addSubview:buildPeople];
    
    //创建人按钮
    UIButton *shakerBtn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    shakerBtn.frame=CGRectMake(buildPeople.frame.origin.x, buildPeople.frame.origin.y+buildPeople.frame.size.height+3, 30, 20);
//===================================>>>>>>>>传创建人的名字的button
    [shakerBtn setTitle:@"稀客" forState:UIControlStateNormal];
//===================================>>>>>>>>>>>>>
    shakerBtn.titleLabel.font=[UIFont systemFontOfSize:14.0f];
    shakerBtn.titleLabel.font=[UIFont boldSystemFontOfSize:14];
    [shakerBtn setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
    shakerBtn.titleLabel.textAlignment=NSTextAlignmentRight;
    [view addSubview:shakerBtn];
    
    //显示内容的label
    textLabel=[[UILabel alloc]initWithFrame:CGRectMake(shakerBtn.frame.origin.x, shakerBtn.frame.origin.y+shakerBtn.frame.size.height+10, kWidth-shakerSayImage.frame.origin.x*2-shakerSayImage.frame.size.width-15, kHeight*0.12)];
//====================================>>>>>>>>>>>创建作品的主要内容 已经设置只显示3行
    textLabel.text = [self.headerDicM objectForKey:@"content"];
    //linshi
    textLabel.text = @"离开现实表面";
    
//====================================>>>>>>>>>>>
    textLabel.numberOfLines=3;
    textLabel.font=[UIFont systemFontOfSize:14.0];
    //调整text的行间距
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:textLabel.text];//textLabel.text
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    
    [paragraphStyle setLineSpacing:LINESPACE];//调整行间距
    
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [textLabel.text length])];
    textLabel.attributedText = attributedString;
    //sizeToFit
    [textLabel sizeToFit];
    
    [view addSubview:textLabel];
    
    //关注此话题 的Button
//==================================>>>>>>>>>>>>>点击 “关注话题” 自己个人主页的关注＋1
    UIButton *attentionTopicBtn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    attentionTopicBtn.frame=CGRectMake(textLabel.frame.origin.x, textLabel.frame.origin.y+textLabel.frame.size.height+0.03*kHeight, 0.13*kHeight, 0.05*kHeight);
    [attentionTopicBtn setTitle:@"关注话题" forState:UIControlStateNormal];
    [attentionTopicBtn setTitleColor:kColor(0, 216 , 165) forState:UIControlStateNormal];
    attentionTopicBtn.titleLabel.font=[UIFont systemFontOfSize:14];
    attentionTopicBtn.layer.borderWidth=1.0;
    attentionTopicBtn.layer.borderColor=[kColor(0, 216, 165) CGColor];
    [view addSubview:attentionTopicBtn];
//==================================>>>>>>>>>>>>>点击 “关注话题” 自己个人主页的关注＋1
    
    
    //显示参与和关注人数的label
//==================================>>>>>>>>>>>>>显示此话题有多少人 关注 和参与
    partakeAndAttentionLabel=[[UILabel alloc]initWithFrame:CGRectMake(attentionTopicBtn.frame.origin.x+attentionTopicBtn.frame.size.width, attentionTopicBtn.frame.origin.y, kWidth-attentionTopicBtn.frame.origin.x-attentionTopicBtn.frame.size.width-15, attentionTopicBtn.frame.size.height)];
    partakeAndAttentionLabel.text=[self.headerDicM objectForKey:@"postsAndConcerns"];
    partakeAndAttentionLabel.textColor=kColor(167, 167, 167);
    partakeAndAttentionLabel.font=[UIFont systemFontOfSize:12.0f];
    partakeAndAttentionLabel.textAlignment=NSTextAlignmentRight;
    [view addSubview:partakeAndAttentionLabel];
//==================================>>>>>>>>>>>>>显示此话题有多少人 关注 和参与
    

    UIView *topLineView=[[UIView alloc]initWithFrame:CGRectMake(0, attentionTopicBtn.frame.origin.y+attentionTopicBtn.frame.size.height+kHeight*0.03, kWidth, 1)];
    topLineView.backgroundColor=kColor(216, 216, 216);
    [view addSubview:topLineView];
    
    //最热button
    UIButton *bestHot=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    bestHot.frame=CGRectMake(0, topLineView.frame.origin.y+1, kWidth/2-1, kHeight*0.07);
    [bestHot setTitle:@"最热" forState:UIControlStateNormal];
    [bestHot setTitleColor:kColor(0, 216, 167) forState:UIControlStateNormal];
    bestHot.backgroundColor=[UIColor whiteColor];
    bestHot.tag=801;
    [bestHot addTarget:self action:@selector(bestHotAndNew:) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:bestHot];
    
    //最新button
    UIButton *bestNew=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    bestNew.frame=CGRectMake(bestHot.frame.size.width+2, bestHot.frame.origin.y, bestHot.frame.size.width, bestHot.frame.size.height);
    [bestNew setTitle:@"最新" forState:UIControlStateNormal];
    [bestNew setTitleColor:kColor(167, 167, 167) forState:UIControlStateNormal];
    bestNew.backgroundColor=[UIColor whiteColor];
    bestNew.tag=802;
    [bestNew addTarget:self action:@selector(bestHotAndNew:) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:bestNew];
    
    _underLineView=[[UIView alloc]initWithFrame:CGRectMake(0, bestHot.frame.origin.y+bestHot.frame.size.height, kWidth, 1)];
    _underLineView.backgroundColor=kColor(216, 216, 216);
    [view addSubview:_underLineView];
    
    _runView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, _underLineView.frame.size.width/2, 1)];
    _runView.backgroundColor=kColor(0, 216, 165);
    [_underLineView addSubview:_runView];
    
    UIView *midView=[[UIView alloc]initWithFrame:CGRectMake(bestHot.frame.size.width+1, bestHot.frame.origin.y+bestHot.frame.size.height*0.3, 1, bestHot.frame.size.height*0.4)];
    midView.backgroundColor=kColor(216, 216, 216);
    [view addSubview:midView];
    
    
    return view;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    self.navigationController.navigationBarHidden=NO;
//     NSLog(@"offset---scroll:%f",self.tableView.contentOffset.y);
     self.navigationController.navigationBar.alpha = self.tableView.contentOffset.y/500;
}

//nav左边返回按钮响应
-(void)leftBackBtnClick
{
    self.navigationController.navigationBarHidden=NO;
    [self.navigationController popViewControllerAnimated:YES];
}
//nav右面分享按钮响应
-(void)rightShareBtnClick1
{
//
    //注册通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeNavgation) name:@"changeNav" object:nil];
    
    
    //[self sinaWeiboShare];
    [UIView animateWithDuration:0.3f animations:^{
        [blackView setFrame:CGRectMake(0, 0, kWidth, kHeight*0.7)];
    }];
    
    [UIView animateWithDuration:0.3f animations:^{
        [Sview setFrame:CGRectMake(0, kHeight*0.7, kWidth, kHeight*0.3)];
    }];
}

-(void)giveUpShareTap
{
    [UIView animateWithDuration:0.3f animations:^{
        [blackView setFrame:CGRectMake(0, kHeight, kWidth, kHeight*0.7)];
    }];
    
    [UIView animateWithDuration:0.3f animations:^{
        [Sview setFrame:CGRectMake(0, kHeight+kHeight*0.7, kWidth, kHeight*0.3)];
    }];
    
    //[blackView removeGestureRecognizer:giveUpTap];
}

-(void)weChatShare
{
    [self wechatSessionShare];
}
-(void)weBoShare
{
    [self sinaWeiboShare];
}
//-(void)momentsShare
//{
//    [self wechatTimelineShare];
//}

//tabbar上的我要参与按钮响应
-(void)iWantToJoinIt
{
     self.navigationController.navigationBarHidden=NO;
    if ([[NSUserDefaults standardUserDefaults] boolForKey:isLogin]) {
        
        ObtainPictureViewController *obtainPhoto = [[ObtainPictureViewController alloc]init];
        [self.navigationController pushViewController:obtainPhoto animated:YES];
        
        
    }else{
        
        StartViewController *startVC = [[StartViewController alloc]init];
        [self.navigationController pushViewController:startVC animated:YES];
        
    }
}
NSInteger bestNewAndHotTag1 = 801;
-(void)bestHotAndNew:(UIButton *)sender
{
    UIButton *cusBtn = (UIButton *)[self.view viewWithTag:bestNewAndHotTag1];
        [cusBtn setTitleColor:kColor(167, 167, 167) forState:UIControlStateNormal];
    
    switch (sender.tag) {
        case 801:
        {
            [sender setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
            [UIView animateWithDuration:0.5 animations:^{

            _runView.center = CGPointMake(sender.center.x, _runView.center.y);
            
            }];
        }
            break;
        case 802:
        {
            [sender setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
            [UIView animateWithDuration:0.5 animations:^{
                
            _runView.center = CGPointMake(sender.center.x, _runView.center.y);
            
            }];
        }
           
            break;
        default:
            break;
    }
    
    bestNewAndHotTag1 = sender.tag;
    
}

#pragma mark -- load data
-(void)loadDataFromServerWithTopicId:(NSString*)topicId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSString *strUrl = [NSString stringWithFormat:@"%@%@%@",HOST,@"topic/",topicId];
    
    [manager GET:strUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         if ([[responseObject objectForKey:@"code"] integerValue] == 1) {
             if (![[responseObject objectForKey:@"data"] isEqual:[NSNull null]]){
             
             [self.headerDicM setObject:[[responseObject objectForKey:@"data"] objectForKey:@"content"] forKey:@"content"];
             
             [self.headerDicM setObject:[NSString stringWithFormat:@"%ld人参与/%ld人关注",[[[responseObject objectForKey:@"data"] objectForKey:@"posts"]integerValue],[[[responseObject objectForKey:@"data"] objectForKey:@"concerns"]integerValue]] forKey:@"postsAndConcerns"];
             
             [self.headerDicM setObject:[[responseObject objectForKey:@"data"] objectForKey:@"logo"] forKey:@"logo"];
             
             [self.tableView reloadData];
             }
         }
         NSLog(@"shakerTopicView :%@ %@",responseObject,[responseObject objectForKey:@"msg"]);
         
         
     } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
         NSLog(@"topic detail error:%@",error);
     }];
}


#pragma mark Share Button Actions
- (void)wechatSessionShare {
    NSString *theme = [@"testWechat" stringByAppendingString:@":"];
  
    NSString *content = @"testtest";
    NSString *URLString = [[NSString alloc] initWithFormat:@"%@",[self.headerDicM objectForKey:@"logo"]];
    [[ShareEngine sharedInstance] sendLinkContent:WXSceneSession :theme :content :[UIImage imageNamed:@"3"] :[NSURL URLWithString:URLString]];
    
}
#pragma mark -- share weibo
- (void)sinaWeiboShare {
    
    NSString *content = @"test";
    NSString *URLString = [[NSString alloc] initWithFormat:@"%@%@%@",@"http://v2.shaker.mobi",@"/entity/",@"a6618832-39f5-4e04-91ff-7ed57f40d2be"];
    [[ShareEngine sharedInstance] sendWBLinkeContent:content :@"shaker test" :[UIImage imageNamed:@"zuo zhe"] :[NSURL URLWithString:URLString]];
}


-(void)changeNavgation
{
    
    
    self.navigationController.navigationBar.backgroundColor = [UIColor clearColor];
    self.navigationController.navigationBar.alpha=0;

//     self.navigationController.navigationBarHidden=NO;
//    [self.tableView reloadData];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
