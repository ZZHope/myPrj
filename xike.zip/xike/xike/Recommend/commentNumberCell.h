//
//  commentNumberCell.h
//  xike
//
//  Created by a on 15/6/30.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface commentNumberCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *commentFaceImage;
@property (weak, nonatomic) IBOutlet UILabel *commentNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *commentTime;
@property (weak, nonatomic) IBOutlet UILabel *commentContentLabel;

@end
