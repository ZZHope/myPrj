//
//  Recommend.m
//  xike
//
//  Created by shaker on 15/8/4.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "Recommend.h"

@implementation Recommend

-(id)init
{
    self = [super init];
    if (self) {
        
        _creatDate = @"";
        _creatUser = @"";
        _creatUserId = 0;
        _creatUserPhoto = @"";
        _img = @"";
        _recomendId = 0;
        _orderIndex = 0;
        _title = @"";
        _content = @"";
        _topicId = 0;
    }
    return self;
}

@end
