//
//  contentViewController.h
//  xike
//
//  Created by a on 15/6/26.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "common.h"
#import "likeNumberViewController.h"
#import "otherUserViewController.h"
#import "test.h"
#import "shaKerTopicViewController.h"
#import "userTopicViewController.h"
@interface contentViewController : UIViewController

@property(nonatomic, assign) NSInteger progressRate;
@property(nonatomic,copy)NSString *articleId;

@end
