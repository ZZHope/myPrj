//
//  shakerTopcOnlyTextCell.m
//  xike
//
//  Created by MarilynEric on 15/7/13.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "shakerTopcOnlyTextCell.h"

@implementation shakerTopcOnlyTextCell

- (void)awakeFromNib {
    // Initialization code
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:_contentLabel.text];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    
    [paragraphStyle setLineSpacing:LINESPACE];//调整行间距
    
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [_contentLabel.text length])];
    _contentLabel.attributedText = attributedString;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
