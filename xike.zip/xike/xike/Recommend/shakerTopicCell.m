//
//  shakerTopicCell.m
//  xike
//
//  Created by MarilynEric on 15/7/10.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "shakerTopicCell.h"

@implementation shakerTopicCell

- (void)awakeFromNib {
    // Initialization code
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:_textlabel.text];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    
    [paragraphStyle setLineSpacing:LINESPACE];//调整行间距
    
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [_textlabel.text length])];
    _textlabel.attributedText = attributedString;
    
    
    [_attentionButton.layer setCornerRadius:1];
    [_attentionButton.layer setBorderWidth:1];
    //    [btn.layer setBorderColor:[kColor(0, 216, 165) .CGColor]];
    _attentionButton.layer.borderColor = kColor(0, 216, 165).CGColor;
}
- (IBAction)focusClick:(UIButton *)sender {
    [self.delegate shakerTopicCellFocusClickWithButton:sender];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
