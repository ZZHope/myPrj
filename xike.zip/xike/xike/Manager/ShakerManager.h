//
//  ShakerManager.h
//  xike
//
//  Created by shaker on 15/6/1.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, SHAKERTYPE) {
    SHAKERGUIDE=0,
    SHAKERMAIN
};
@interface ShakerManager : NSObject

+(void)presentViewControllerWithType:(SHAKERTYPE)type;

@end
