//
//  ShakerManager.m
//  xike
//
//  Created by shaker on 15/6/1.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "ShakerManager.h"
#import "MainViewController.h"
#import "GuideViewController.h"

@implementation ShakerManager


+(void)presentViewControllerWithType:(SHAKERTYPE)type
{
      //  以修改keywindow的rootViewController，来实现界面的跳转
        UIViewController *controller =  [[[self alloc] init] controllerByType:type];
        UIWindow *window = [[[UIApplication sharedApplication] delegate] window];
        window.rootViewController = controller;

}

//根据传入controllerTyp创建具体的ViewController对象
- (UIViewController*)controllerByType:(SHAKERTYPE)type
{
    UIViewController *viewController = nil;
    
    switch (type) {
        case SHAKERGUIDE:
            viewController = [[GuideViewController alloc] init];
            break;
        case SHAKERMAIN:
            viewController = [[MainViewController alloc] init];
            break;
        default:
            break;
    }
    return viewController;
}



@end
