//
//  TopicDetailController.h
//  xike
//
//  Created by shaker on 15/6/15.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TopicDetailController : UIViewController

@property(copy, nonatomic) NSString *fromTopic;
@property(copy, nonatomic) NSString *listTopicId;

@end
