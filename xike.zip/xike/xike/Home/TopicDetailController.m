//
//  TopicDetailController.m
//  xike
//
//  Created by shaker on 15/6/15.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "TopicDetailController.h"
#import "StartViewController.h"
#import "common.h"
#import "Networking.h"
#import "AFNetworking.h"
#import "ShareEngine.h"
#import "ObtainPictureViewController.h"
#import "Topic.h"
#import "UIImageView+WebCache.h"

@interface TopicDetailController ()
@property (strong, nonatomic)  UIImageView *backView;
@property (strong, nonatomic)  UILabel *titleLabel;
@property (strong, nonatomic)  UILabel *subTitleLabel;
@property (strong, nonatomic)  UILabel *creatorLabel;
@property (strong, nonatomic)  UIImageView *thumbnailImgview;
@property (strong, nonatomic)  UILabel *creatorNameLabel;
@property (strong, nonatomic)  UILabel *joinNumberLabel;
@property (strong, nonatomic)  UIScrollView *scrollView;

@property (strong, nonatomic) NSMutableArray *articleArrM;

@property (strong, nonatomic) Topic *topic;

@end

@implementation TopicDetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];

    //上面半部分图
    _backView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kWidth)];
    
    UIImage *img = [[UIImage imageNamed:@""] resizableImageWithCapInsets:UIEdgeInsetsMake(75, 138,75 , 138) resizingMode:UIImageResizingModeStretch];
    self.backView.image =  img;

    self.backView.userInteractionEnabled=YES;


    self.backView.backgroundColor = kColor(216, 216, 216);
    
    [self layoutBackView];
    
    //scrollView
    
    _scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.backView.frame), kWidth, kHeight-kWidth)];
    self.scrollView.showsHorizontalScrollIndicator = NO;
    [self.view addSubview:self.backView];
    

    
    //用于界面复用的区分
    if ([self.fromTopic isEqualToString:FromTopic]) {
        UIButton *focusBtn = [self customButtonWithFrame:CGRectMake(15, CGRectGetMinY(_thumbnailImgview.frame)-40, 60, 20) title:@"关注话题" tag:1001];
        focusBtn.layer.borderColor = [UIColor whiteColor].CGColor;
        focusBtn.layer.borderWidth = 1.0f;
        focusBtn.titleLabel.font = [UIFont systemFontOfSize:10.0f];
        [self.backView addSubview:focusBtn];
        
        
        UIButton *joinBtn = [self customButtonWithFrame:CGRectMake(88, kWidth-60, kWidth-88*2, 30) title:@"我要参与" tag:1002];
        joinBtn.layer.borderWidth = 1.0f;
        joinBtn.layer.borderColor = [kColor(0, 216, 165) CGColor];
        [joinBtn setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
        joinBtn.titleLabel.font = [UIFont systemFontOfSize:14.0f];
        [self.backView addSubview:joinBtn];
        
        [self layoutSubView4ScrollView];
        
    }
    
    //我要参与和创建完成
    if ([self.fromTopic isEqualToString:CompleteTopic]||[self.fromTopic isEqualToString:TakePartInTopic]) {
        
        float imgWidth = 10+ceil(kWidth-35)/2.5;
        _scrollView.contentSize = CGSizeMake(kWidth, kHeight-kWidth);
        
        UIButton *addArticle = [[UIButton alloc]initWithFrame:CGRectMake(15,  28*kWidth/375.0, imgWidth-10, (imgWidth-10)*209/136)];
        [addArticle setImage:[UIImage imageNamed:@"addArticle"] forState:UIControlStateNormal];
        addArticle.backgroundColor = [UIColor lightGrayColor];
        addArticle.alpha = 0.3;
        [addArticle addTarget:self action:@selector(addArticles) forControlEvents:UIControlEventTouchUpInside];
        [self.scrollView addSubview:addArticle];


    }
    
    [self.view addSubview:self.scrollView];
    
}

-(void)viewWillAppear:(BOOL)animated
{
    
    [self loadDataFromServerWithTopicId:self.listTopicId];

    self.navigationController.navigationBarHidden = YES;
}

#pragma mark -- layoutBackview
-(void)layoutBackView
{
    //返回
    UIButton *backBtn = [[UIButton alloc]initWithFrame:CGRectMake(10, 25, 30, 30)];
    [backBtn setImage:[UIImage imageNamed:@"BackArrow"] forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(backController:) forControlEvents:UIControlEventTouchUpInside];
    [self.backView addSubview:backBtn];
    
    
    //临时拿掉
    //share
    
    UIButton *shareBtn = [[UIButton alloc]initWithFrame:CGRectMake(kWidth-15-30, 25, 30, 30)];
    [shareBtn setImage:[UIImage imageNamed:@"fenxiang"] forState:UIControlStateNormal];
    [shareBtn addTarget:self action:@selector(shareTopic:) forControlEvents:UIControlEventTouchUpInside];
    //[self.backView addSubview:shareBtn];
    
    //title
    _titleLabel = [self creatLabelWithFrame:CGRectMake(15, 108*kWidth/375.0, kWidth-30, 24) title:@"离开现实表面" font:24.0f];
    self.titleLabel.font = [UIFont boldSystemFontOfSize:24.0f];
    [self.backView addSubview:self.titleLabel];
    
    //subtitle
    _subTitleLabel = [self creatLabelWithFrame:CGRectMake(15, CGRectGetMaxY(self.titleLabel.frame)+17, self.titleLabel.bounds.size.width, 25) title:@"有人想离开显示表面有人想离开显示表面有人想离开显示表面有人想离开显示表面有人想离开显示表面" font:10.f];
    self.subTitleLabel.numberOfLines = 2;
    [self.backView addSubview:self.subTitleLabel];


    
    //创建人
    
    _thumbnailImgview = [[UIImageView alloc]initWithFrame:CGRectMake(15, kWidth-82*kWidth/375.0-40, 40, 40)];
    self.thumbnailImgview.backgroundColor = kColor(216,216, 216);

    self.thumbnailImgview.userInteractionEnabled = YES;
    
    UITapGestureRecognizer *tapProfile = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapToUserInfoView:)];
    [self.thumbnailImgview addGestureRecognizer:tapProfile];
    [self.backView addSubview:self.thumbnailImgview];
    //发起人
    _creatorLabel = [self creatLabelWithFrame:CGRectMake(CGRectGetMaxX(self.thumbnailImgview.frame)+10,  kWidth-86*kWidth/375.0-23, 40, 10) title:@"发起人" font:9];
    [self.backView addSubview:self.creatorLabel];
    
    //name
    _creatorNameLabel = [self creatLabelWithFrame:CGRectMake(CGRectGetMaxX(self.thumbnailImgview.frame)+10, CGRectGetMaxY(self.creatorLabel.frame)+3, 60, 10) title:@"Kelly Kelley" font:10.0f];
    [self.backView addSubview:self.creatorNameLabel];

    
    //参与人数
    _joinNumberLabel = [self creatLabelWithFrame:CGRectMake(kWidth-115, CGRectGetMinY(self.creatorNameLabel.frame), 100, 10) title:[NSString stringWithFormat:@"%d人参与/%d人关注",0,0] font:9.0f];
    [self.backView addSubview:self.joinNumberLabel];
    
    //准备数据
    
    
    
    _articleArrM = [NSMutableArray array];
    [self.articleArrM addObject:[UIImage imageNamed:@"Camera"]];
    [self.articleArrM addObject:[UIImage imageNamed:@"Camera"]];
    [self.articleArrM addObject:[UIImage imageNamed:@"Camera"]];
    [self.articleArrM addObject:[UIImage imageNamed:@"Camera"]];
    [self.articleArrM addObject:[UIImage imageNamed:@"Camera"]];
    [self.articleArrM addObject:[UIImage imageNamed:@"Camera"]];
    [self.articleArrM addObject:[UIImage imageNamed:@"Camera"]];
    
    
    _topic = [[Topic alloc]init];

    
    
}



#pragma mark -- custom label
-(UILabel *)creatLabelWithFrame:(CGRect)frame title:(NSString *)title font:(float)fontSize
{
    UILabel *label = [[UILabel alloc]initWithFrame:frame];
    
    label.text = title;
    label.font = [UIFont systemFontOfSize:fontSize];
    label.textColor = [UIColor whiteColor];
    label.textAlignment = NSTextAlignmentLeft;
    
    return label;
}

//creat scrollview subview
-(void)layoutSubView4ScrollView
{
    float imgWidth = 10+ceil(kWidth-35)/2.5;
    _scrollView.contentSize = CGSizeMake(kWidth*ceil(self.articleArrM.count/2.5)+imgWidth, kHeight-kWidth);
    
    for (int i=0; i<self.articleArrM.count; i++) {
        UIView *view = [[UIImageView alloc]initWithFrame:CGRectMake(15+imgWidth*i,0, imgWidth-10, CGRectGetHeight(self.scrollView.frame)-28*kWidth/375.0)];
        //hot
        if (i<3) {
            UIButton *topBtn = [[UIButton alloc]initWithFrame:CGRectMake(CGRectGetWidth(view.frame)-25, 0, 25, 25)];
            [topBtn setImage:[UIImage imageNamed:[NSString stringWithFormat:@"top%d",i+1]] forState:UIControlStateNormal];
            topBtn.userInteractionEnabled = NO;
            [view addSubview:topBtn];

        }
        
        UIImageView *imgView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 28*kWidth/375.0, view.bounds.size.width, view.bounds.size.width*209/136)];
        //imgView.backgroundColor = [UIColor grayColor];
        imgView.image = self.articleArrM[i];
        [view addSubview:imgView];
        
        UIView *bottomView = [[UIView alloc]initWithFrame:CGRectMake(15+i*(CGRectGetWidth(imgView.frame)+10), CGRectGetMaxY(imgView.frame)+5, CGRectGetWidth(imgView.frame), view.bounds.size.height-imgView.bounds.size.height)];
        
        UIButton *nameBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, view.bounds.size.width*0.5, bottomView.bounds.size.height-10)];
        [nameBtn setTitle:@"Justin" forState:UIControlStateNormal];
        nameBtn.titleLabel.textAlignment = NSTextAlignmentLeft;
        
        [nameBtn setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
        nameBtn.titleLabel.font = [UIFont systemFontOfSize:10.0f];
        [nameBtn addTarget:self action:@selector(tapToUserInfoView:) forControlEvents:UIControlEventTouchUpInside];
        [bottomView addSubview:nameBtn];
        
        UIButton *focusBtn = [[UIButton alloc]initWithFrame:CGRectMake(CGRectGetWidth(bottomView.frame)-45, CGRectGetMinY(nameBtn.frame), CGRectGetWidth(bottomView.frame)-CGRectGetWidth(nameBtn.frame), CGRectGetHeight(nameBtn.frame))];
        [focusBtn setImage:[UIImage imageNamed:@"like"] forState:UIControlStateNormal];
        [focusBtn setTitle:[NSString stringWithFormat:@"%d",12] forState:UIControlStateNormal];
        [focusBtn setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
        focusBtn.titleLabel.font = [UIFont systemFontOfSize:12.0];
        [focusBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 5, 0, 0)];
        focusBtn.titleLabel.textAlignment = NSTextAlignmentRight;
        focusBtn.userInteractionEnabled = NO;
        [bottomView addSubview:focusBtn];
        
        
        
        [self.scrollView addSubview:bottomView];
        
        [self.scrollView addSubview:view];
    }
    
}




-(UIButton *)customButtonWithFrame:(CGRect)frame title:(NSString *)title tag:(NSInteger)tag
{
    UIButton *btn = [[UIButton alloc]initWithFrame:frame];
    [btn setTitle:title forState:UIControlStateNormal];
    btn.tag = tag;
    [btn addTarget:self action:@selector(clickButtonToJoin:) forControlEvents:UIControlEventTouchUpInside];
    return btn;
}

//share
- (void)shareTopic:(UIButton *)sender {
    
    //[self sinaWeiboShare];
}



//back button
- (void)backController:(UIButton *)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}

//关注或者参与
-(void)clickButtonToJoin:(UIButton *)sender
{
    switch (sender.tag) {
        case 1001:
            NSLog(@"关注话题");
            break;
            
        case 1002:
        {
            if ([[NSUserDefaults standardUserDefaults] boolForKey:isLogin]) {
                
                ObtainPictureViewController *obtainPhoto = [[ObtainPictureViewController alloc]init];
                obtainPhoto.creatTopicId = self.listTopicId;
                [self.navigationController pushViewController:obtainPhoto animated:YES];

                
            }else{
                
                StartViewController *startVC = [[StartViewController alloc]init];
                //[self:startVC animated:YES completion:nil];
                [self.navigationController pushViewController:startVC animated:YES];
                
            }

        }
            
            break;

            
        default:
            break;
    }
}

//点击头像
-(void)tapToUserInfoView:(id)sender
{
    NSLog(@"点击进入个人主页");
}

//创建作品
-(void)addArticles
{

    ObtainPictureViewController *obtainVC = [[ObtainPictureViewController alloc]init];
    obtainVC.creatTopicId = self.listTopicId;
    [self.navigationController pushViewController:obtainVC animated:YES];
}

#pragma mark -- load data
-(void)loadDataFromServerWithTopicId:(NSString*)topicId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSString *strUrl = [NSString stringWithFormat:@"%@%@%@",HOST,@"topic/",topicId];
    NSDictionary *parameter = @{@"deviceToken":[[NSUserDefaults standardUserDefaults] objectForKey:kDeviceToken],
                                @"authCode":[[NSUserDefaults standardUserDefaults] objectForKey:kAuthCode]
                                };

    
    [manager GET:strUrl parameters:parameter success:^(AFHTTPRequestOperation *operation, id responseObject)
    {
        if ([[responseObject objectForKey:@"code"] integerValue] == 1) {
            if (![[responseObject objectForKey:@"data"] isEqual:[NSNull null]]) {
               
                
                self.titleLabel.text = [[responseObject objectForKey:@"data"] objectForKey:@"title"];
                self.subTitleLabel.text = [[responseObject objectForKey:@"data"] objectForKey:@"content"];
                [self.thumbnailImgview sd_setImageWithURL:[[responseObject objectForKey:@"data"]objectForKey:@"createUserPhoto"]];
                self.creatorNameLabel.text =  [[responseObject objectForKey:@"data"] objectForKey:@"createUser"];
                self.joinNumberLabel.text = [NSString stringWithFormat:@"%ld人参与/%ld人关注",[[[responseObject objectForKey:@"data"] objectForKey:@"posts"]integerValue],[[[responseObject objectForKey:@"data"] objectForKey:@"concerns"]integerValue]];
                
                [self.backView sd_setImageWithURL:[[responseObject objectForKey:@"data"] objectForKey:@"logo"]];
            }
            

        }
       // NSLog(@"topic detail:%@",responseObject);
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"topic detail error:%@",error);
    }];
}




-(void)viewWillDisappear:(BOOL)animated
{
    self.navigationController.navigationBarHidden = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




@end
