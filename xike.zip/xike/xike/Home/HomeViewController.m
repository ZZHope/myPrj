//
//  HomeViewController.m
//  xike
//
//  Created by shaker on 15/6/1.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "HomeViewController.h"
#import "TopicDetailController.h"
#import "common.h"
#import "AFNetworking.h"
#import "Networking.h"
#import "UIImageView+WebCache.h"
#import "UserSingleton.h"


@interface homeViewControllerCollectionViewCell : UICollectionViewCell

@property(nonatomic, strong)UIImageView *imgView;


@end

@implementation homeViewControllerCollectionViewCell

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if (self) {
        self.backgroundColor=kColor(0, 216, 165);
        _imgView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.contentView.frame.size.width, self.contentView.frame.size.height)];
        self.imgView.backgroundColor = kColor(216, 216, 216);
        [self.contentView addSubview:_imgView];
        

    }
    return self;
}
@end



@interface HomeViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

@property(nonatomic,strong)UICollectionView *collectionView;
@property(nonatomic,strong)UILabel *navLabel;
@property(nonatomic,strong)UIImageView *headerImageView;
@property(nonatomic,strong)NSMutableArray *topicDataM;

@end

@implementation HomeViewController

- (void)viewDidLoad {
    
    
    [super viewDidLoad];
    //记录tabbarItem
    [UserSingleton shareUserSingleton].tabItemIndex = @"1";

    
    //data
    _topicDataM = [NSMutableArray array];
    
    /*tabbar*/
    

    //navgation标头
    [self buildNavLabel];
    
    //collectionView;
    [self buildCollectionView];
    
    //头部广告栏ImageView
    [self buildHeaderImageView];
    
}

-(void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];

    //refreshing
    
    HomeViewController *homeVC = self;
    [self.collectionView addLegendHeaderWithRefreshingBlock:^{
        [homeVC loadTopicDataFromServer];
    }];
    [self.collectionView.header setTitle:@"稀客正在为您刷新。。。" forState:MJRefreshHeaderStatePulling];

    
    [self.collectionView.header beginRefreshing];

    
    //Umeng analyze
    [MobClick beginLogPageView:@"HomeViewController"];

}
//navgation标头
-(void)buildNavLabel
{
    _navLabel=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, 100, 40)];
    _navLabel.textAlignment=NSTextAlignmentCenter;
    _navLabel.text=@"精选话题";
    [_navLabel setTextColor:kColor(0, 216, 165)];
    self.navigationItem.titleView=_navLabel;
}

 //头部广告栏ImageView
-(void)buildHeaderImageView
{
    _headerImageView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, kWidth, 0.36*kHeight)];
    _headerImageView.backgroundColor=[UIColor whiteColor];
    _headerImageView.image=[UIImage imageNamed:@"5"];
}

//collectionView
-(void)buildCollectionView
{
    float AD_height=0.36*kHeight;//广告栏高度
    UICollectionViewFlowLayout *flowLayout=[[UICollectionViewFlowLayout alloc]init];
    [flowLayout setScrollDirection:UICollectionViewScrollDirectionVertical];
    flowLayout.headerReferenceSize = CGSizeMake(kWidth, AD_height);//头部
    self.collectionView=[[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kHeight-55) collectionViewLayout:flowLayout];
    _collectionView.backgroundColor=[UIColor whiteColor];
    
    //隐藏
    _collectionView.showsVerticalScrollIndicator = NO;
    //设置代理
    self.collectionView.delegate=self;
    self.collectionView.dataSource=self;
    
    [self.view addSubview:self.collectionView];
    
    //注册cell和ReusableView(相当于头部)
    [self.collectionView registerClass:[homeViewControllerCollectionViewCell class] forCellWithReuseIdentifier:@"cell"];
    [self.collectionView registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"ReysableView"];
}


#pragma mark --UICollectionViewDataSource
//定义展示的UICollectionViewCell的个数
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.topicDataM.count;
}
//定义展示的Section的个数
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}
//每个UICollectionView的展示内容
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *collectinView =@"cell";
    [collectionView registerClass:[homeViewControllerCollectionViewCell class] forCellWithReuseIdentifier:collectinView];
    homeViewControllerCollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:collectinView forIndexPath:indexPath];
    [cell sizeToFit];
    if (!cell) {
        cell = [[homeViewControllerCollectionViewCell alloc]init];
    }
    cell.contentView.backgroundColor = [UIColor whiteColor];
    [cell.imgView sd_setImageWithURL:[NSURL URLWithString:[self.topicDataM[indexPath.row] objectForKey:@"banner"]]];
    
    return cell;
}

//头部显示的内容
-(UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    UICollectionReusableView *headerView=[collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"ReysableView" forIndexPath:indexPath];
    [headerView addSubview:_headerImageView];//头部广告栏
    
    return headerView;

}


#pragma mark --UICollectionViewDelegateFlowLayout
//定义每个UICollectionView 大小
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(kWidth*0.44, kWidth*0.44);
}

//定义每个UICollectinView的 间距
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(kWidth*0.04, kWidth*0.04, 0,kWidth*0.04);
    
}

//定义每个UICollectionView的 纵向间距
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    
    return 0.04*kWidth;
}


#pragma mark --UICollectionViewDelegate
//UICollectionView被选中时调用的方法
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"选择了%ld",indexPath.row);
    
    //TopicDetailController *topicDetail = [[TopicDetailController alloc]init];
    userTopicViewController *topicDetail = [[userTopicViewController alloc]init];
    topicDetail.fromTopic = FromTopic;
    topicDetail.listTopicId = [self.topicDataM[indexPath.row] objectForKey:@"topicId"];
    topicDetail.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:topicDetail animated:YES];
    
}


//返回这个UICollectionView是否可以被选择；
-(BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

#pragma mark -- loaddata From server

int pageNum = 1;
-(void)loadTopicDataFromServer
{

    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSString *strUrl = [NSString stringWithFormat:@"%@%@",HOST,@"topic/recommend/list"];
    NSDictionary *para = @{@"page":[NSNumber numberWithInt:pageNum]};
    [manager GET:strUrl parameters:para success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"home topic :%@",responseObject);

        [self.collectionView.header endRefreshing];
        
        if ([[responseObject objectForKey:@"code"] intValue] == 1 ) {
            
            if (![[responseObject objectForKey:@"data"]isEqual:[NSNull null]]) {
             
                [self.topicDataM removeAllObjects];
                
                pageNum+=1;
                for (NSDictionary *dic in [responseObject objectForKey:@"data"]) {
                    
                    [self.topicDataM addObject:dic];
                    
                }
            
                [self.collectionView reloadData];


            }
            
            
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        NSLog(@"home topic error:%@",error);
        [self.collectionView.header endRefreshing];
        [MyAlertView showMessageToView:[[UIApplication sharedApplication] keyWindow]];
        
    }];
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"HomeViewController"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
