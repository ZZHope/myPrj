//
//  LoginViewController.h
//  xike
//
//  Created by shaker on 15/6/26.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface LoginViewController : UIViewController
@property(nonatomic, copy) NSString *userMail;
@property(nonatomic, copy) NSString *userPwd;


@end
