//
//  RegisterViewController.m
//  xike
//
//  Created by shaker on 15/6/26.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "RegisterViewController.h"
#import "common.h"
#import "AFNetworking.h"
#import "Networking.h"
#import <CommonCrypto/CommonDigest.h>
#import "UserSingleton.h"
#import "SetNickViewController.h"

@interface RegisterViewController ()
@property (weak, nonatomic) IBOutlet UITextField *inputMail;

@property (weak, nonatomic) IBOutlet UITextField *inputPwd;
@property (weak, nonatomic) IBOutlet UITextField *confirmPwd;
@property (nonatomic, strong) UserSingleton *userRegister;
@property (nonatomic, strong) UIButton *backBtn;

@end

@implementation RegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _userRegister = [UserSingleton shareUserSingleton];
    
    [self navigationSetting];
    
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [MobClick beginLogPageView:@"RegisterViewController"];
}


//navigation 的设置
-(void)navigationSetting
{
    //取消
    self.backBtn = [[UIButton alloc]initWithFrame:CGRectMake(15, 30, 30, 30)];
    [self.backBtn setTitle:@"取消" forState:UIControlStateNormal];
    [self.backBtn setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
    self.backBtn.titleLabel.font = [UIFont systemFontOfSize:15.0f];
    [self.backBtn addTarget:self action:@selector(cancelCurrentVC:) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:self.backBtn];
    
    
    //textView
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 60, 15)];
    titleLabel.text = @"注册";
    titleLabel.font = [UIFont boldSystemFontOfSize:15.0f];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    self.navigationItem.titleView = titleLabel;
    
}


- (void)cancelCurrentVC:(UIButton *)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}


- (IBAction)toRegister:(UIButton *)sender {
    
    //linshi
//        [[NSUserDefaults standardUserDefaults] setObject:@"23be476fdcc462818d758fade605c1bc41b6587dc875519112fe159e7883652c" forKey:kDeviceToken];
   
    if ([self isValidEmail:self.inputMail.text]&&[self.inputPwd.text isEqualToString:self.confirmPwd.text]) {
        NSString *md5Pwd = [self md5SecretePwd:self.inputPwd.text];
        NSString *md5RePwd = [self md5SecretePwd:self.confirmPwd.text];
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        NSString *strUrl = [NSString stringWithFormat:@"%@%@",HOST,@"register"];
        NSDictionary *parameter = @{
                                    @"email":self.inputMail.text,
                                    @"password":md5Pwd,
                                    @"rePassword":md5RePwd,
                                    kDeviceToken:[[NSUserDefaults standardUserDefaults] objectForKey:kDeviceToken]
                                    };
        
        [manager POST:strUrl parameters:parameter success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSLog(@"register:%@ msg:%@",responseObject,[responseObject objectForKey:@"msg"]);
            if ([[responseObject objectForKey:@"code"] intValue] == 1) {
                
                self.userRegister.authCode = [[responseObject objectForKey:@"data"] objectForKey:@"authCode"];
                self.userRegister.userID =[[responseObject objectForKey:@"data"]objectForKey:@"id"];
                self.userRegister.profileUrl = [[responseObject objectForKey:@"data"]objectForKey:@"photo"];
                self.userRegister.nickName = [[responseObject objectForKey:@"data"]objectForKey:@"username"];
                [[NSUserDefaults standardUserDefaults] setObject:self.userRegister.authCode forKey:kAuthCode];
                [[NSUserDefaults standardUserDefaults] setObject:self.userRegister.userID forKey:@"userId"];
                [[NSUserDefaults standardUserDefaults] setBool:YES forKey:isLogin];
                [[NSUserDefaults standardUserDefaults] synchronize];
                SetNickViewController *setNicVC = [[SetNickViewController alloc]init];
                [self.navigationController pushViewController:setNicVC animated:YES];
                
            
            }else{
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[responseObject objectForKey:@"msg"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                [alert show];
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
           
            NSLog(@"register error:%@",error);
            
        }];
    }
    
}



#pragma mark -- valid mail
- (BOOL)isValidEmail:(NSString *)checkString
{
    BOOL stricterFilter = YES;
    NSString *stricterFilterString = @"[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}";
    NSString *laxString = @".+@([A-Za-z0-9]+\\.)+[A-Za-z]{2}[A-Za-z]*";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:checkString];
}

#pragma mark -- MD5

//32位MD5加密方式
- (NSString *)getMd5_32Bit_String:(NSString *)srcString{
    const char *cStr = [srcString UTF8String];
    unsigned char digest[CC_MD5_DIGEST_LENGTH];
    CC_MD5( cStr, (int)strlen(cStr), digest );
    NSMutableString *result = [NSMutableString stringWithCapacity:CC_MD5_DIGEST_LENGTH * 2];
    for(int i = 0; i < CC_MD5_DIGEST_LENGTH; i++)
        [result appendFormat:@"%02x", digest[i]];//以十六进制形式输出，不足两位的前面补零
    
    return result;
    
    
}

//返回一个加密后的密码
-(NSString *)md5SecretePwd:(NSString *)pwdText
{
    NSString *pwdStr = pwdText;
    pwdStr = [self getMd5_32Bit_String:pwdStr];
    return pwdStr;
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.inputMail resignFirstResponder];
    [self.inputPwd resignFirstResponder];
    [self.confirmPwd resignFirstResponder];
}


-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"RegisterViewController"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
