//
//  LoginViewController.m
//  xike
//
//  Created by shaker on 15/6/26.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "LoginViewController.h"
#import "ForgetPasswordViewController.h"
#import <CommonCrypto/CommonDigest.h>
#import "AFNetworking.h"
#import "Networking.h"
#import "UserSingleton.h"
#import "common.h"


@interface LoginViewController ()

@property (weak, nonatomic) IBOutlet UITextField *mailField;
@property (weak, nonatomic) IBOutlet UITextField *pwdField;
@property (nonatomic, strong) UserSingleton *loginUser;
@property (nonatomic, strong) UIButton *backBtn;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self navigationSetting];
    
    CGRect tempMailF = self.mailField.frame;
    tempMailF.size.height = 40;
    self.mailField.frame = tempMailF;
    
    CGRect tempPwdF = self.pwdField.frame;
    tempPwdF.size.height = 40;
    self.mailField.frame = tempPwdF;
    

    
    
    if (self.userMail.length) {
        self.mailField.text = self.userMail;
    }
    
    if (self.userPwd.length) {
        self.pwdField.text = self.userPwd;
    }
   
    //usersingle
    _loginUser = [UserSingleton shareUserSingleton];
    
}



//navigation 的设置
-(void)navigationSetting
{
    //取消
    self.backBtn = [[UIButton alloc]initWithFrame:CGRectMake(15, 30, 30, 15)];
    [self.backBtn setTitle:@"取消" forState:UIControlStateNormal];
    [self.backBtn setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
    self.backBtn.titleLabel.font = [UIFont systemFontOfSize:15.0f];
    [self.backBtn addTarget:self action:@selector(cancelBtn:) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:self.backBtn];
    
    
    //textView
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 60, 15)];
    titleLabel.text = @"登录";
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.font = [UIFont boldSystemFontOfSize:15.0f];
    self.navigationItem.titleView = titleLabel;
    
}


- (IBAction)toLogin:(UIButton *)sender {


    //0821 linshi
//    [[NSUserDefaults standardUserDefaults] setObject:@"23be476fdcc462818d758fade605c1bc41b6587dc875519112fe159e7883652c" forKey:kDeviceToken];
    
    if ([self isValidEmail:self.mailField.text]) {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        NSString *strUrl = [NSString stringWithFormat:@"%@%@",HOST,@"login"];
        NSDictionary *para = @{@"email":self.mailField.text,
                               @"password":[self md5SecretePwd:self.pwdField.text],
                               @"deviceToken":[[NSUserDefaults standardUserDefaults]objectForKey:kDeviceToken]};
    
        [manager POST:strUrl parameters:para success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            NSLog(@"login:%@ msg:%@",responseObject,[responseObject objectForKey:@"msg"]);
            if ([[responseObject objectForKey:@"code"] intValue] == 1) {
                
                self.loginUser.authCode = [[responseObject objectForKey:@"data"] objectForKey:@"authCode"];
                self.loginUser.userID = [[responseObject objectForKey:@"data"] objectForKey:@"id"];
                //            self.loginUser.nickName = [[responseObject objectForKey:@"data"] objectForKey:@"username"];
                self.loginUser.userID = [[responseObject objectForKey:@"data"] objectForKey:@"id"];
                self.loginUser.accountNumber = [[responseObject objectForKey:@"data"] objectForKey:@"username"];
                [[NSUserDefaults standardUserDefaults] setObject:self.loginUser.userID forKey:@"userId"];
                [[NSUserDefaults standardUserDefaults] setObject:self.loginUser.authCode forKey:@"authCode" ];
                [[NSUserDefaults standardUserDefaults] setBool:YES forKey:isLogin];
                [[NSUserDefaults standardUserDefaults] synchronize];

                NSInteger vcCnt = self.navigationController.viewControllers.count;
                [self.navigationController popToViewController:self.navigationController.viewControllers[vcCnt-1-2] animated:YES];
            }
            
            
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            NSLog(@"login error:%@",error);
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"网络不给力" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
            
        }];
        
    }
    
    
}
- (void)cancelBtn:(UIButton *)sender {
    
    NSInteger vcCnt = self.navigationController.viewControllers.count;
    [self.navigationController popToViewController:self.navigationController.viewControllers[vcCnt-1-2] animated:YES];
}
- (IBAction)forgetPassword:(UIButton *)sender {
    
    ForgetPasswordViewController *forgetVC = [[ForgetPasswordViewController alloc]init];
    [self.navigationController pushViewController:forgetVC animated:YES];
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.mailField resignFirstResponder];
    [self.pwdField resignFirstResponder];
}

#pragma mark -- valid mail 
- (BOOL)isValidEmail:(NSString *)checkString
{
    BOOL stricterFilter = YES;
    NSString *stricterFilterString = @"[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}";
    NSString *laxString = @".+@([A-Za-z0-9]+\\.)+[A-Za-z]{2}[A-Za-z]*";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:checkString];
}

#pragma mark -- MD5

//32位MD5加密方式
- (NSString *)getMd5_32Bit_String:(NSString *)srcString{
    const char *cStr = [srcString UTF8String];
    unsigned char digest[CC_MD5_DIGEST_LENGTH];
    CC_MD5( cStr, (int)strlen(cStr), digest );
    NSMutableString *result = [NSMutableString stringWithCapacity:CC_MD5_DIGEST_LENGTH * 2];
    for(int i = 0; i < CC_MD5_DIGEST_LENGTH; i++)
        [result appendFormat:@"%02x", digest[i]];//以十六进制形式输出，不足两位的前面补零
    
    return result;
    
    
}

//返回一个加密后的密码
-(NSString *)md5SecretePwd:(NSString *)pwdText
{
    NSString *pwdStr = pwdText;
    pwdStr = [self getMd5_32Bit_String:pwdStr];
    return pwdStr;
}


//info sychronize

-(void)info2Save
{
    NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
//    [user setObject:[CbyUserSingleton shareUserSingleton].userName forKey:@"userName"];
//    [user setObject:self.pwd.text forKey:@"pwd"];
//    [user setBool:YES forKey:@"remPwd"];
//    [user setBool:YES forKey:@"autoLogin"];
//    [user setBool:self.success forKey:@"successLogin"];
//    [user setObject:[[responseObject objectForKey:@"data"] objectForKey:@"user_id"] forKey:@"userID"];
    
    //进行写入磁盘
    
    [user synchronize];

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
