//
//  ForgetPasswordViewController.m
//  xike
//
//  Created by shaker on 15/6/26.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "ForgetPasswordViewController.h"
#import "common.h"
#import "AFNetworking.h"
#import "Networking.h"

@interface ForgetPasswordViewController ()<UIAlertViewDelegate>
@property (weak, nonatomic) IBOutlet UITextField *putMail;
@property (strong,nonatomic) UIButton *backBtn;

@end

@implementation ForgetPasswordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self navigationSetting];
    // Do any additional setup after loading the view from its nib.
}

//navigation 的设置
-(void)navigationSetting
{
    //取消
    self.backBtn = [[UIButton alloc]initWithFrame:CGRectMake(15, 30, 30, 15)];
    [self.backBtn setTitle:@"取消" forState:UIControlStateNormal];
    [self.backBtn setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
    self.backBtn.titleLabel.font = [UIFont systemFontOfSize:15.0f];
    [self.backBtn addTarget:self action:@selector(cancelBtn) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:self.backBtn];
    
    
    //textView
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 60, 15)];
    titleLabel.text = @"忘记密码";
    titleLabel.font = [UIFont boldSystemFontOfSize:15.0f];
    self.navigationItem.titleView = titleLabel;
    
}

-(void)cancelBtn
{
    [self.navigationController popViewControllerAnimated:YES];
}


- (IBAction)findPassword:(UIButton *)sender {
    
    sender.enabled = NO;
    [MBProgressHUD showMessage:@"正在验证..." toView:self.view];
    NSString *strUrl = [NSString stringWithFormat:@"%@%@",HOST,@"reset/pwd"];
    NSDictionary *para = @{@"email":self.putMail.text};
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager POST:strUrl parameters:para success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [MBProgressHUD hideHUDForView:self.view];
        if ([[responseObject objectForKey:@"code"] integerValue] == 1) {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"已将临时密码发送至您的邮箱" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
            sender.enabled = YES;
           
        }
        NSLog(@"forget:%@",responseObject);
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        NSLog(@"forget error:%@",error);
        [MBProgressHUD hideHUDForView:self.view];
        sender.enabled = YES;
    }];
}

#pragma mark -- alert view
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
