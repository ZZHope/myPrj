//
//  setNickViewController.m
//  xike
//
//  Created by shaker on 15/7/10.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "SetNickViewController.h"
#import "common.h"
#import "Networking.h"
#import "AFNetworking.h"

@interface SetNickViewController ()<UITextFieldDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@property(nonatomic, strong) UIImageView *profileView;
@property(nonatomic, strong) UIButton *promptBtn;
@property(nonatomic, strong) UITextField *nickText;

@end

@implementation SetNickViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    _profileView = [[UIImageView alloc]initWithFrame:CGRectMake((kWidth-89)/2.0, 100, 89, 89)];
    self.profileView.backgroundColor = [UIColor whiteColor];
    self.profileView.layer.borderColor = [kColor(0, 216, 165) CGColor];
    self.profileView.layer.borderWidth = 1.0f;
    self.profileView.image = [self getDefaultUserPic];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapTochangeProfile:)];
    [self.profileView addGestureRecognizer:tap];
    
    [self.view addSubview:self.profileView];
    
    _promptBtn = [[UIButton alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.profileView.frame)-30, CGRectGetMinY(self.profileView.frame)-30, 59, 28)];
    [self.promptBtn setImage:[UIImage imageNamed:@"changeUserPic"] forState:UIControlStateNormal];
    self.promptBtn.userInteractionEnabled = NO;
    [self.view addSubview:self.promptBtn];
    
    _nickText = [[UITextField alloc]initWithFrame:CGRectMake(30, CGRectGetMaxY(self.profileView.frame)+15, kWidth-60, 40)];
    self.nickText.placeholder = @"请输入昵称";
    self.nickText.textAlignment = NSTextAlignmentCenter;
    self.nickText.delegate = self;
    self.nickText.textColor = kColor(74, 74, 74);
    self.nickText.backgroundColor = kColor(216, 216, 216);
    self.nickText.font = [UIFont systemFontOfSize:15.0f];
    [self.view addSubview:self.nickText];
    
    
    [self settingNavBar];
    
    
}

- (UIImage *)getDefaultUserPic {
    int x = arc4random()%8;
    return [UIImage imageNamed:[[NSString alloc] initWithFormat:@"defaultUserPic%@",[NSNumber numberWithInt:x]]];
    
}

-(void)settingNavBar
{
   
    
    UIButton *rightBtn = [self customNaviButtonWithFrame:CGRectMake(15,15, 30, 30) title:@"完成" tag:1002];
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
    self.navigationItem.rightBarButtonItem = rightItem;
    
    UIButton *leftBtn = [self customNaviButtonWithFrame:CGRectMake(0, 0, 30, 30) title:@"" tag:1001];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake((kWidth-60)/2, 15, 60, 30)];
    label.text=@"个人设置";
    label.font = [UIFont systemFontOfSize:15.0f];
    label.textAlignment = NSTextAlignmentCenter;
    self.navigationItem.titleView = label;
    //[self.view addSubview:label];
    
}

//custom button
-(UIButton *)customNaviButtonWithFrame:(CGRect)frame title:(NSString *)title tag:(NSInteger)tag
{
    UIButton *btn = [[UIButton alloc]initWithFrame:frame];
    [btn setTitle:title forState:UIControlStateNormal];
    [btn setTitleColor: kColor(0, 216, 165) forState:UIControlStateNormal];
    btn.tag = tag;
    btn.titleLabel.font = [UIFont systemFontOfSize:15.0f];
    [btn addTarget:self action:@selector(setNickItemClick:) forControlEvents:UIControlEventTouchUpInside];
    
    return btn;
    
}


-(void)tapTochangeProfile:(UITapGestureRecognizer*)gesture
{
    
}

//complete
-(void)setNickItemClick:(UIButton*)sender
{
    if (self.nickText.text.length) {
        [self setNickAndProfile];
    }else{
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"昵称不能为空" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
}


//setProfile
-(void)setNickAndProfile
{
    
    [MBProgressHUD showMessage:@"" toView:self.view];
    NSData *profileData = UIImageJPEGRepresentation(self.profileView.image, 1.0);
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"YYYY-MM-dd hh:mm:ss"];
    NSString *date = [formatter stringFromDate:[NSDate date]];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSString *strUrl = [NSString stringWithFormat:@"%@%@",HOST,@"site/user/update"];
    NSDictionary *para = @{@"nickname":self.nickText.text,
                           kAuthCode:[[NSUserDefaults standardUserDefaults] objectForKey:kAuthCode],
                           kDeviceToken:[[NSUserDefaults standardUserDefaults] objectForKey:kDeviceToken]};
    [manager POST:strUrl parameters:para constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        
        [formData appendPartWithFileData:profileData name:@"photo" fileName:[NSString stringWithFormat:@"%@%@",date,@"profile"] mimeType:@"image/jpeg"];
        
        
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
   
        //+ (void)hideHUDForView:(UIView *)view
       // MBProgressHUD hide
        NSLog(@"setnick %@",responseObject);
        if ([[responseObject objectForKey:@"code"] intValue]==1) {
            
            NSInteger cnt = self.navigationController.viewControllers.count;
            [self.navigationController popToViewController:self.navigationController.viewControllers[cnt-3-1] animated:YES];
        }else{
            NSLog(@"%@",[responseObject objectForKey:@"msg"]);
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        NSLog(@"nick error:%@",error);
    }];
    
}

#pragma mark -- textfield delegate

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self.nickText resignFirstResponder];
    return YES;
}


-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.nickText resignFirstResponder];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
