//
//  StartViewController.m
//  xike
//
//  Created by shaker on 15/6/1.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "StartViewController.h"
#import "RegisterViewController.h"
#import "LoginViewController.h"
#import "common.h"
#import "ShareEngine.h"
#import "ShakerManager.h"
#import "AFNetworking.h"
#import "Networking.h"
#import "dataBaseCommon.h"
#import "ShakerDataBaseManager.h"
#import "UserSingleton.h"

@interface StartViewController ()<ShareEngineDelegate>
@property(nonatomic, strong) UIButton *backBtn;
@property(nonatomic, strong) UIImageView *logoView;
@property(nonatomic, strong) UILabel *logoName;
@property(nonatomic, strong) UILabel *sloganLabel;
@property(nonatomic, strong) UIButton *weiboBtn;
@property(nonatomic, strong) UIButton *weixinBtn;
@property(nonatomic, strong) UILabel *orLabel;
@property(nonatomic, strong) UIButton *mailBtn;
@property(nonatomic, strong) UIButton *registerBtn;
@property(nonatomic, copy)   NSString *logonType;
@property(nonatomic, copy)   NSString *dismissFlag;
@property(nonatomic, strong) ShakerDataBaseManager *dbManager;

@end

@implementation StartViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    _dbManager = [ShakerDataBaseManager shareInstance];
    self.navigationController.navigationBarHidden = NO;
    [self navigationSetting];
    
    
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self layoutViews];
    
    [ShareEngine sharedInstance].delegate = self;
}

//navigation 的设置
-(void)navigationSetting
{
    //取消
    self.backBtn = [[UIButton alloc]initWithFrame:CGRectMake(15, 30, 30, 15)];
    [self.backBtn setTitle:@"取消" forState:UIControlStateNormal];
    [self.backBtn setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
    self.backBtn.titleLabel.font = [UIFont systemFontOfSize:15.0f];
    [self.backBtn addTarget:self action:@selector(clickToBack) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:self.backBtn];


    //textView
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 60, 15)];
    titleLabel.text = @"登录";
    titleLabel.font = [UIFont boldSystemFontOfSize:15.0f];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    self.navigationItem.titleView = titleLabel;
    
}



-(void)layoutViews
{
   //logo
    
    _logoView = [[UIImageView alloc]initWithFrame:CGRectMake((kWidth-91)/2, 74*kHeight/375-44, 91, 101)];
    self.logoView.image = [UIImage imageNamed:@"logoLogin"];
    [self.view addSubview:self.logoView];
    
    //logo name
    _logoName = [[UILabel alloc]initWithFrame:CGRectMake((kWidth-60)/2, CGRectGetMaxY(self.logoView.frame)+15, 60, 18)];
    self.logoName.font = [UIFont systemFontOfSize:18.0f];
    self.logoName.textAlignment = NSTextAlignmentCenter;
    self.logoName.textColor = kDefaultColor;
    self.logoName.text = @"稀\t客";
    [self.view addSubview:self.logoName];
    
    //slogan
    
    _sloganLabel = [[UILabel alloc]initWithFrame:CGRectMake((kWidth-155)/2, CGRectGetMaxY(self.logoName.frame)+30, 155, 12)];
    self.sloganLabel.textColor = [UIColor grayColor];
    self.sloganLabel.text = @"离\t开\t现\t实\t表\t面";
    self.sloganLabel.font  = [UIFont boldSystemFontOfSize:10.0f];
    self.sloganLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:self.sloganLabel];
    
    //weibo login
    _weiboBtn = [[UIButton alloc]initWithFrame:CGRectMake((kWidth-273*kWidth/375)/2, kHeight-187*kHeight/667, 273*kWidth/375, 40*kHeight/667)];
    [self.weiboBtn setImage:[UIImage imageNamed:@"weibo"] forState:UIControlStateNormal];
    [self.weiboBtn setBackgroundColor:kDefaultColor];
    [self.weiboBtn setTitle:@"微博登录" forState:UIControlStateNormal];
    [self.weiboBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.weiboBtn addTarget:self action:@selector(login:) forControlEvents:UIControlEventTouchUpInside];
    self.weiboBtn.titleLabel.font = [UIFont boldSystemFontOfSize:12.0f];
    [self.weiboBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 15, 0, 0)];
    self.weiboBtn.layer.cornerRadius = 2.0f;
    self.weiboBtn.tag = 1001;
    [self.view addSubview:self.weiboBtn];

    //weixin login
    _weixinBtn = [[UIButton alloc]initWithFrame:CGRectMake((kWidth-273*kWidth/375)/2, CGRectGetMaxY(self.weiboBtn.frame)+15*kHeight/667, 273*kWidth/375, 40*kHeight/667)];
    [self.weixinBtn setImage:[UIImage imageNamed:@"weixin"] forState:UIControlStateNormal];
    [self.weixinBtn setBackgroundColor:kDefaultColor];
    [self.weixinBtn setTitle:@"微信登录" forState:UIControlStateNormal];
    [self.weixinBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.weixinBtn addTarget:self action:@selector(login:) forControlEvents:UIControlEventTouchUpInside];
    self.weixinBtn.titleLabel.font = [UIFont boldSystemFontOfSize:12.0f];
    [self.weixinBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 15, 0, 0)];
    self.weixinBtn.layer.cornerRadius= 2.0f;
    self.weixinBtn.tag = 1002;
    if ([WXApi isWXAppSupportApi]) {
        
        [self.view addSubview:self.weixinBtn];
    }
    
    
    
    //depart line
    UIView *lineLeft = [[UIView alloc]initWithFrame:CGRectMake(CGRectGetMinX(self.weixinBtn.frame)+5, CGRectGetMaxY(self.weixinBtn.frame)+20*kHeight/667, 114*kWidth/375, 0.5)];
    lineLeft.backgroundColor = [UIColor lightGrayColor];
    [self.view addSubview:lineLeft];
    
    _orLabel = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(lineLeft.frame)+5, CGRectGetMaxY(self.weixinBtn.frame)+15*kHeight/667, 20, 12)];
    self.orLabel.font = [UIFont systemFontOfSize:10.0f];
    self.orLabel.text = @"或者";
    self.orLabel.textColor = [UIColor grayColor];
    self.orLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:self.orLabel];
    
    UIView *lineRight = [[UIView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.orLabel.frame)+5, CGRectGetMaxY(self.weixinBtn.frame)+20*kHeight/667, 114*kWidth/375, 0.5)];
    lineRight.backgroundColor = [UIColor lightGrayColor];
    [self.view addSubview:lineRight];

    //mail login and register
    _mailBtn = [[UIButton alloc]initWithFrame:CGRectMake(CGRectGetMinX(self.weixinBtn.frame)+50*kWidth/375,CGRectGetMaxY(self.orLabel.frame)+15 , 50, 12)];//kHeight-25*kHeight/667-12
    [self.mailBtn setTitle:@"邮箱登录" forState:UIControlStateNormal];
    [self.mailBtn setTitleColor:kDefaultColor forState:UIControlStateNormal];
    self.mailBtn.titleLabel.font = [UIFont systemFontOfSize:12.0f];
    [self.mailBtn addTarget:self action:@selector(login:) forControlEvents:UIControlEventTouchUpInside];
    self.mailBtn.tag = 1003;
    [self.view addSubview:self.mailBtn];
    //[[[UIApplication sharedApplication] keyWindow] addSubview:self.mailBtn];
    
    //register
    
    _registerBtn = [[UIButton alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.weixinBtn.frame)-50*kWidth/375-50, CGRectGetMinY(self.mailBtn.frame), 50, 12)];
    [self.registerBtn setTitleColor:kDefaultColor forState:UIControlStateNormal];
    [self.registerBtn setTitle:@"注册账号" forState:UIControlStateNormal];
    self.registerBtn.titleLabel.font = [UIFont systemFontOfSize:12.0f];
    [self.registerBtn addTarget:self action:@selector(login:) forControlEvents:UIControlEventTouchUpInside];
    self.registerBtn.tag = 1004;
    [self.view addSubview:self.registerBtn];
//    [[[UIApplication sharedApplication] keyWindow] addSubview:self.registerBtn];


}


#pragma mark -- button click

//取消
-(void)clickToBack
{

    int  index = [[UserSingleton shareUserSingleton].tabItemIndex intValue];
    self.tabBarController.selectedViewController = self.tabBarController.viewControllers[index];
    [self.navigationController popViewControllerAnimated:YES];

}
//第三方登陆
-(void)login:(UIButton *)sender//1001:weibo 1002:weixin  1003:mail
{
    switch (sender.tag) {
        case 1001: //weibo
        {
            self.logonType = @"WB";
            [[ShareEngine sharedInstance] sendSSOAuthRequest];
        }
            
            break;
        case 1002: //weixin
        {
            self.logonType = @"WX";
            [[ShareEngine sharedInstance] sendAuthRequest];
        }
            
            break;
        case 1003: //mail
        {
           
            LoginViewController *loginVC = [[LoginViewController alloc]init];
            
            [self.navigationController pushViewController:loginVC animated:YES];
        }
            
            break;
            
        case 1004: //register
        {
            RegisterViewController *registerVC = [[RegisterViewController alloc]init];
            [self.navigationController pushViewController:registerVC animated:YES];
        }
            break;


            
        default:
            break;
    }
}

- (void)didLogon:(NSString *)logonType :(NSDictionary *)userDic {
    
    
    //0821 linshi
//    [[NSUserDefaults standardUserDefaults] setObject:@"23be476fdcc462818d758fade605c1bc41b6587dc875519112fe159e7883652c" forKey:kDeviceToken];
//
    
    if (userDic) {
        
        if ([self.logonType isEqualToString:@"WX"]) {
            
            
            NSDictionary *para = @{@"openId":[userDic objectForKey:@"openid"],
                                   @"userName":[userDic objectForKey:@"nickname"],
                                   @"photo":[userDic objectForKey:@"headimgurl"],
                                   @"deviceToken":[[NSUserDefaults standardUserDefaults] objectForKey:kDeviceToken]};
            [self pushUserInfoWithPara:para];
        } else if ([self.logonType isEqualToString:@"WB"]) {
            


            NSDictionary *para = @{@"uid":[userDic objectForKey:@"id"],

                                   @"userName":[userDic objectForKey:@"screen_name"],
                                   @"photo":[userDic objectForKey:@"profile_image_url"],
                                   @"deviceToken":[[NSUserDefaults standardUserDefaults] objectForKey:kDeviceToken]
                                   };
            NSMutableDictionary *dbDic = [NSMutableDictionary dictionary];
            [dbDic setObject:[userDic objectForKey:@"id"] forKey:kUserId];
            [dbDic setObject:[userDic objectForKey:@"profile_image_url"] forKey:kProfileUrl];
            [dbDic setObject:[userDic objectForKey:@"screen_name"] forKey:kNickName];
            [self.dbManager addNewUserInfoWithData:dbDic];
            [self pushUserInfoWithPara:para];
        }

    }
}



-(void)pushUserInfoWithPara:(NSDictionary *)para
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSString *strUrl = [NSString stringWithFormat:@"%@%@",HOST,@"automatic"];
    [manager POST:strUrl parameters:para success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"login 3 success:  %@",responseObject);
        if ([[responseObject objectForKey:@"code"] intValue] == 1) {

            [[NSUserDefaults standardUserDefaults]setObject:[[responseObject objectForKey:@"data"] objectForKey:@"authCode" ] forKey:kAuthCode];
            [[NSUserDefaults standardUserDefaults]setObject:[[responseObject objectForKey:@"data"] objectForKey:@"id"] forKey:@"userId"];
            [[NSUserDefaults standardUserDefaults]setBool:YES forKey:isLogin];
            [[NSUserDefaults standardUserDefaults]synchronize];
            
            NSMutableDictionary *dbDic = [NSMutableDictionary dictionary];
            [dbDic setObject:[[responseObject objectForKey:@"data"]objectForKey:@"id" ] forKey:kUserId];
            [dbDic setObject:[[responseObject objectForKey:@"data"]objectForKey:@"photo"] forKey:kProfileUrl];
            [dbDic setObject:[[responseObject objectForKey:@"data"] objectForKey:@"username"] forKey:kNickName];
            [self.dbManager addNewUserInfoWithData:dbDic];
            
            [self.navigationController popViewControllerAnimated:YES];
            
        }
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [MyAlertView showMessageToView:[[UIApplication sharedApplication] keyWindow]];
        NSLog(@"3 login error:%@",error);
    }];
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self.mailBtn removeFromSuperview];
    [self.registerBtn removeFromSuperview];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
