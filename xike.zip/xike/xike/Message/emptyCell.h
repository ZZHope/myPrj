//
//  emptyCell.h
//  xike
//
//  Created by a on 15/7/9.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface emptyCell : UITableViewCell

@end
