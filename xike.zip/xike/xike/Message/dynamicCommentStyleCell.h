//
//  dynamicCommentStyleCell.h
//  xike
//
//  Created by a on 15/7/2.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface dynamicCommentStyleCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *profileImgView;
@property (weak, nonatomic) IBOutlet UILabel *creatorName;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UIButton *topicOrigin;
@property (weak, nonatomic) IBOutlet UILabel *commentMsgL;
@property (weak, nonatomic) IBOutlet UIImageView *articleCoverImgView;

@end
