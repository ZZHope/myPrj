//
//  messagePublishCell.h
//  xike
//
//  Created by a on 15/7/3.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface messagePublishCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *profilePublish;
@property (weak, nonatomic) IBOutlet UILabel *timePublish;

@property (weak, nonatomic) IBOutlet UIButton *activityOnlineTheme;

@property (weak, nonatomic) IBOutlet UIImageView *activityImgView;
@end
