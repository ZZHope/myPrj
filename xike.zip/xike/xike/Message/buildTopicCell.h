//
//  buildTopicCell.h
//  xike
//
//  Created by a on 15/7/3.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface buildTopicCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *topicImgViewBuild;

@property (weak, nonatomic) IBOutlet UILabel *timeBuild;
@property (weak, nonatomic) IBOutlet UIButton *topicThemeBuild;
@property (weak, nonatomic) IBOutlet UIButton *partCount;
@property (weak, nonatomic) IBOutlet UILabel *partName;

@property (weak, nonatomic) IBOutlet UIImageView *article1ImgView;

@property (weak, nonatomic) IBOutlet UIImageView *article2;
@property (weak, nonatomic) IBOutlet UIImageView *article3;
@property (weak, nonatomic) IBOutlet UIImageView *article4;

@end
