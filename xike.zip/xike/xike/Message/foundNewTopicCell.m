//
//  foundNewTopicCell.m
//  xike
//
//  Created by a on 15/7/3.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "foundNewTopicCell.h"

@implementation foundNewTopicCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
