//
//  MsgViewController.m
//  xike
//
//  Created by shaker on 15/6/1.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "MsgViewController.h"
#import "AFNetworking.h"
#import "Networking.h"
#import "common.h"
#import "dynamicCommentStyleCell.h"
#import "messageThumbs-upCell.h"
#import "emptyCell.h"
#import "dynamicPartakeCell.h"
#import "foundNewTopicCell.h"
#import "buildTopicCell.h"
#import "messageAttentionCell.h"
#import "messagePublishCell.h"
#import "UIImageView+WebCache.h"
#import "UserSingleton.h"
#import "StartViewController.h"


typedef NS_ENUM(NSInteger, VIEWTYPE)
{
    DYNAMIC=0,
    MESSAGE,
    EMPTY
};


#define Dynamic @"dynamics"
#define Message @"msgs"
@interface MsgViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,assign)NSInteger viewFlag;
@property(nonatomic, strong) NSMutableArray *totleMassageM;
@property(nonatomic, strong) NSMutableArray *dynamicM;
@property(nonatomic, strong) NSMutableArray *messageM;
@end

@implementation MsgViewController
{
    UIView *view;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationController.navigationBarHidden=YES;
    
    self.viewFlag=DYNAMIC;
    //data
    
    _totleMassageM = [NSMutableArray array];
    _messageM = [NSMutableArray array];
    _dynamicM = [NSMutableArray array];
    
    
    [self buildTableView];
    
    [self loadDataFromServerWithType:Dynamic];

    
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    
    if (![[NSUserDefaults standardUserDefaults]boolForKey:isLogin]) {
        StartViewController *startVC = [[StartViewController alloc]init];
        startVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:startVC animated:YES];
    }else{
        
        self.navigationController.navigationBarHidden = YES;
        [self loadDataFromServerWithType:Dynamic];
        //记录tabbarItem
        [UserSingleton shareUserSingleton].tabItemIndex = @"3";
        [self buildView];
        
    }

    
    [MobClick beginLogPageView:@"HomeViewController"];
    
}

-(void)buildView
{
    UIView *backGroundView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWidth, 64)];
    backGroundView.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:backGroundView];
    
    UIButton *dynamicBtn=[self buttonWithFrame:CGRectMake(0, 20, kWidth/2, 43) title:@"动态" tag:401];
    [dynamicBtn setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
    dynamicBtn.backgroundColor=[UIColor whiteColor];
    [backGroundView addSubview:dynamicBtn];
    
    
    UIButton *messageBtn=[self buttonWithFrame:CGRectMake(kWidth/2, 20, kWidth/2, 43) title:@"消息" tag:402];
    messageBtn.backgroundColor=[UIColor whiteColor];
    
    [backGroundView addSubview:messageBtn];
    
    view=[[UIView alloc]initWithFrame:CGRectMake(0, 63, kWidth/2, 1)];
    view.backgroundColor=kColor(0, 216, 162) ;
    [backGroundView addSubview:view];
    
}

-(void)buildTableView
{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 64, kWidth, kHeight-64-49) style:UITableViewStylePlain];
    
    _tableView.delegate=self;
    _tableView.dataSource=self;
    _tableView.backgroundColor=[UIColor whiteColor];
    self.tableView.showsVerticalScrollIndicator = NO;
    
    [self.view addSubview:_tableView];

}
//设置有几个section  默认为1
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
//设置每个section中有多少个cell
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.totleMassageM.count) {
        return self.totleMassageM.count;
        
    }else{
        self.viewFlag = EMPTY;
        return 1;
    }
    
}


//绘制tableViewCell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //        static NSString *cellNum=@"cellNum1";
    //        dynamicCommentStyleCell *cell=[tableView dequeueReusableCellWithIdentifier:cellNum];
    //        if (cell==nil) {
    //            cell=[[NSBundle mainBundle] loadNibNamed:@"dynamicCommentStyleCell" owner:self options:nil][0];
    //            cell.selectionStyle=UITableViewCellSelectionStyleNone;
    //        }
    //        return cell;
    static NSString *cellEmpty=@"cellNum2";
    emptyCell *cell=[tableView dequeueReusableCellWithIdentifier:cellEmpty];
        if (cell==nil) {
            cell=[[NSBundle mainBundle] loadNibNamed:@"emptyCell" owner:self options:nil][0];
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            
        }


  
//    if (self.viewFlag == DYNAMIC) {
//      
//        switch ([[self.totleMassageM[indexPath.row] objectForKey:@"type"] intValue]) {
//            case 1:
//            {
//                static NSString *comentCellId = @"commentCellId";
//                //作品品论
//                dynamicCommentStyleCell *commentCell = [tableView dequeueReusableCellWithIdentifier:comentCellId];
//                if (nil == commentCell) {
//                    commentCell = [[dynamicCommentStyleCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:comentCellId];
//                }
//                [commentCell.profileImgView sd_setImageWithURL:[self.totleMassageM[indexPath.row] objectForKey:@"sourceUserPhoto"]];
//                commentCell.creatorName.text = [self.totleMassageM[indexPath.row] objectForKey:@"sourceUserName"];
//                [commentCell.topicOrigin setTitle:[self.totleMassageM[indexPath.row] objectForKey:@"targetWorksLogo"]forState:UIControlStateNormal];
//                //commentCell.commentMsgL.text = [self.totleMassageM[indexPath.row] objectForKey:@""];
//
//
//                
//            }
//                
//                break;
//            case 2:
//                
//                break;
//
//            case 3:
//                
//                break;
//
//            case 4:
//                
//                break;
//                
//            default:
//                break;
//        }
//
//    }else if(self.viewFlag == MESSAGE){
//        switch ([[self.totleMassageM[indexPath.row] objectForKey:@"type"] intValue]) {
//            case 1:
//                
//                break;
//            case 2:
//                
//                break;
//                
//            case 3:
//                
//                break;
//                
//            default:
//                break;
//        }
//
//    }else{
//       
//        static NSString *cellEmpy = @"emptyCell";
//        emptyCell *empCell = [tableView dequeueReusableCellWithIdentifier:cellEmpy];
//        if (nil == empCell) {
//            empCell = [[emptyCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellEmpy];
//        }
//        
//    
//        return empCell;
//    }
    
    return cell;
}

#pragma mark -- UITableViewDelegate
//设置每个cell的高度
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    //return 238;
    return _tableView.frame.size.height;
}

////设置section header的高度
//-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
//{
//    return 64;
//    
//}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.1;
}

////设置头视图中的view；
//-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
//{
//    
//}

NSInteger buttonTag = 401;
-(void)btnClick:(UIButton *)sender
{
    UIButton *cusBtn = (UIButton *)[self.view viewWithTag:buttonTag];
    [cusBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    switch (sender.tag) {
        case 401:
        {
            
            [sender setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
            self.viewFlag = DYNAMIC;
            
            [self loadDataFromServerWithType:Dynamic];
            self.totleMassageM = self.dynamicM;
            
            [UIView animateWithDuration:0.5 animations:^{
                view.center = CGPointMake(sender.center.x, view.center.y);
                
            }];
            //[self.tableView reloadData];
        }
            break;
        case 402:
        {
            
            [sender setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
            self.viewFlag = MESSAGE;
            [self loadDataFromServerWithType:Message];
            self.totleMassageM = self.messageM;
            [UIView animateWithDuration:0.5 animations:^{
                view.center = CGPointMake(sender.center.x, view.center.y);
                
            }];
            //[self.tableView reloadData];
            
        }
            break;
        default:
            break;
    }
    buttonTag = sender.tag;
}
#pragma mark ---custom button

-(UIButton *)buttonWithFrame:(CGRect)frame title:(NSString *)title tag:(NSInteger)tag
{
    UIButton *topic1Button=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    topic1Button.frame=frame;
    [topic1Button setTitle:title forState:UIControlStateNormal];
    topic1Button.backgroundColor=[UIColor whiteColor];
    topic1Button.titleLabel.font=[UIFont systemFontOfSize:14.0f];
    topic1Button.titleLabel.font=[UIFont boldSystemFontOfSize:15.0];
    [topic1Button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [topic1Button addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    topic1Button.tag = tag;
    
    return topic1Button;
}


-(void)loadDataFromServerWithType:(NSString *)type
{
    
    NSString *strUrl = [NSString stringWithFormat:@"%@member/%@",HOST,type];
    NSDictionary *parameter = @{
                                kAuthCode:[[NSUserDefaults standardUserDefaults]objectForKey:kAuthCode],
                                kDeviceToken:[[NSUserDefaults standardUserDefaults] objectForKey:kDeviceToken]
                                };
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:strUrl parameters:parameter success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [self.tableView.header endRefreshing];
         NSLog(@"message:%@",responseObject);
        if ([[responseObject objectForKey:@"code"]intValue] == 1) {
            if (![[responseObject objectForKey:@"data"] isEqual:[NSNull null]]) {
                
                if ([type isEqualToString:@"dynamics"]) {
                    [self.dynamicM removeAllObjects];
                    for (NSDictionary *dic in [responseObject objectForKey:@"data"]) {

                    [self.dynamicM addObject:dic];
                        
                    }
                    self.totleMassageM = self.dynamicM;
                    
                }else{
                    [self.messageM removeAllObjects];
                    for (NSDictionary *dic in [responseObject objectForKey:@"data"]) {

                    [self.messageM addObject:dic];
                }
                    self.totleMassageM = self.messageM;
            }

                
            }
        }
        [self.tableView reloadData];
       
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error:%@",error);
        [self.tableView.header endRefreshing];
    }];
    
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"HomeViewController"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
