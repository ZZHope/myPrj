//
//  foundNewTopicCell.h
//  xike
//
//  Created by a on 15/7/3.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface foundNewTopicCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *profileViewFound;
@property (weak, nonatomic) IBOutlet UILabel *creatorNameFound;
@property (weak, nonatomic) IBOutlet UIImageView *articleFound;
@property (weak, nonatomic) IBOutlet UILabel *topicThemeFound;
@property (weak, nonatomic) IBOutlet UILabel *topicContendFound;
@property (weak, nonatomic) IBOutlet UILabel *timeLabelFound;

@end
