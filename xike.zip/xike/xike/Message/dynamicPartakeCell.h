//
//  dynamicPartakeCell.h
//  xike
//
//  Created by a on 15/7/3.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface dynamicPartakeCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *profilePartview;
@property (weak, nonatomic) IBOutlet UILabel *creatorPart;
@property (weak, nonatomic) IBOutlet UILabel *timePartL;
@property (weak, nonatomic) IBOutlet UIButton *topicOriginPart;

@end
