//
//  messageThumbs-upCell.h
//  xike
//
//  Created by a on 15/7/6.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface messageThumbs_upCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *profileThumb;

@property (weak, nonatomic) IBOutlet UILabel *personThumb;
@property (weak, nonatomic) IBOutlet UILabel *timeThumb;
@property (weak, nonatomic) IBOutlet UILabel *thumbNames;

@property (weak, nonatomic) IBOutlet UIButton *thumbCount;
@property (weak, nonatomic) IBOutlet UIButton *topicThumb;
@property (weak, nonatomic) IBOutlet UIImageView *articleThumb;

@end
