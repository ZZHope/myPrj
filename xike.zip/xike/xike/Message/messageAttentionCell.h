//
//  messageAttentionCell.h
//  xike
//
//  Created by a on 15/7/3.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface messageAttentionCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *profileAttention;
@property (weak, nonatomic) IBOutlet UILabel *attentionName;
@property (weak, nonatomic) IBOutlet UILabel *timeAttention;
@property (weak, nonatomic) IBOutlet UIButton *focusPersonBtn;

@end
