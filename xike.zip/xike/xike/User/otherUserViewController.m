//
//  otherUserViewController.m
//  xike
//
//  Created by a on 15/6/25.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "otherUserViewController.h"
#import "UIImageView+WebCache.h"
typedef NS_ENUM(NSInteger, VIEWTYPE)
{
    TOPICVIEW1=0,
    OPUSVIEW1
    
};


@interface otherUserViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>
@property(nonatomic,strong)UICollectionView *otherCollectionView;
@property(nonatomic,strong)UICollectionView *collectionView;
@property(nonatomic,strong)UILabel *navLabel;
@property(nonatomic,strong)UIImageView *headerImageView;
@property(nonatomic,strong)UIImageView *faceView;
@property(nonatomic,strong)UILabel *attentionLabel;
@property(nonatomic,strong)UILabel *fansLabel;
@property(nonatomic,strong)UIButton *attentionButton;
@property(nonatomic,strong)UIButton *fansButton;
@property(nonatomic,strong)UIButton *attentionOtherUserBtn;

@property(nonatomic,assign)NSInteger viewFlag1;

@property(nonatomic, strong) NSMutableArray *totleArr;
@property(nonatomic, strong) NSMutableArray *topicArr;
@property(nonatomic, strong) NSMutableArray *opusArr;

@property(nonatomic,strong)NSMutableDictionary *headerDicM;
@end

@implementation otherUserViewController
{
    UIButton *opusButton;
    UIButton *topicButton;
    UIView *topLineView;
    UIView *underLineView;
    UIView *midLineView;
}

-(void)viewWillAppear:(BOOL)animated
{
//=========================================================================
    [self loadSelfInfo:1];
//=========================================================================
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//===============================================================>>>>>>>>>>
    self.title=[self.headerDicM objectForKey:@"userName"];
//===============================================================>>>>>>>>>>
    self.viewFlag1 = TOPICVIEW1;
    
    //collectionView;
    [self buildCollectionView];
    
    //头部广告栏ImageView
    [self buildHeaderImageView];
    
    [self netWorkingOtherWithType:@"topics"];
    
    _totleArr=[NSMutableArray array];
    _topicArr=[NSMutableArray array];
    _opusArr=[NSMutableArray array];
    _headerDicM=[NSMutableDictionary new];
    
}



//collectionView
-(void)buildCollectionView
{
    float AD_height=0.56*kHeight;;//广告栏高度
    UICollectionViewFlowLayout *flowLayout=[[UICollectionViewFlowLayout alloc]init];
    [flowLayout setScrollDirection:UICollectionViewScrollDirectionVertical];
    flowLayout.headerReferenceSize = CGSizeMake(kWidth, AD_height);//头部
    self.otherCollectionView=[[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kHeight) collectionViewLayout:flowLayout];
    _otherCollectionView.backgroundColor=[UIColor whiteColor];
    
    //隐藏
    _otherCollectionView.showsVerticalScrollIndicator = NO;
    //设置代理
    self.otherCollectionView.delegate=self;
    self.otherCollectionView.dataSource=self;
    
    [self.view addSubview:self.otherCollectionView];
    
    //注册cell和ReusableView(相当于头部)
    [self.otherCollectionView registerClass:[userCollectionViewCell class] forCellWithReuseIdentifier:@"cell1"];
    [self.otherCollectionView registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"ReysableView1"];
}

//头部广告栏ImageView
-(void)buildHeaderImageView
{
    //背景图片
    _headerImageView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, kWidth, 0.24*kHeight)];
    _headerImageView.backgroundColor=[UIColor whiteColor];
//=============================================================>>>>>>>>>>>>>
    [_headerImageView sd_setImageWithURL:[self.headerDicM objectForKey:@"background"] placeholderImage:[UIImage imageNamed:@"1"]];
//=============================================================>>>>>>>>>>>>>
    //头像图片
    _faceView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 0.16*kWidth, 0.16*kWidth)];
    
    _faceView.center=CGPointMake(kWidth/2, _headerImageView.frame.size.height);
    
    _faceView.backgroundColor=kColor(0, 216, 165);
//=============================================================>>>>>>>>>>>>>
    [_faceView sd_setImageWithURL:[self.headerDicM objectForKey:@"photo"]];
//=============================================================>>>>>>>>>>>>>
    //设置关注
    _attentionLabel=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, 0.16*kWidth-2, _faceView.frame.size.height*0.25)];
    _attentionLabel.backgroundColor=[UIColor clearColor];
//=============================================================>>>>>>>>>>
    _attentionLabel.text=[self.headerDicM objectForKey:@"concerns"];
//=============================================================>>>>>>>>>>
    _attentionLabel.textAlignment=NSTextAlignmentCenter;
    _attentionLabel.font=[UIFont systemFontOfSize:12.0f];
    _attentionLabel.textColor=kColor(74, 74, 74);
    _attentionLabel.center=CGPointMake(_faceView.center.x-_faceView.frame.size.width/2, _faceView.center.y+_faceView.frame.size.height*0.85);
    
    //设置粉丝
    _fansLabel=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, 0.16*kWidth-2, _faceView.frame.size.height*0.25)];
    _fansLabel.backgroundColor=[UIColor clearColor];
//=============================================================>>>>>>>>>>>>
    _fansLabel.text=[self.headerDicM objectForKey:@"fans"];
//=============================================================>>>>>>>>>>>>
    _fansLabel.textAlignment=NSTextAlignmentCenter;
    _fansLabel.font=[UIFont systemFontOfSize:12.0f];
    _fansLabel.textColor=kColor(74, 74, 74);
    _fansLabel.center=CGPointMake(_faceView.center.x+_faceView.frame.size.width/2, _faceView.center.y+_faceView.frame.size.height*0.85);
    
    
    _attentionButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    _attentionButton.frame=CGRectMake(0, 0,_attentionLabel.frame.size.width/2, _attentionLabel.frame.size.height*1.2);
    _attentionButton.center=CGPointMake(_attentionLabel.center.x, _attentionLabel.center.y+1.5*_attentionLabel.frame.size.height);
    [_attentionButton setTitle:@"关注" forState:UIControlStateNormal];
    [_attentionButton setTitleColor:kColor(167, 167, 167) forState:UIControlStateNormal];
    _attentionButton.titleLabel.font=[UIFont systemFontOfSize:12.0f];
    _attentionButton.titleLabel.font=[UIFont boldSystemFontOfSize:12];
    [_attentionButton setTitleColor:kColor(0, 216, 165) forState:UIControlStateHighlighted];
    
    [_attentionButton addTarget:self action:@selector(attentionButtonClick) forControlEvents:UIControlEventTouchUpInside];
    
    
    
    
    _fansButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    _fansButton.frame=CGRectMake(0, 0,_attentionLabel.frame.size.width/2, _attentionLabel.frame.size.height*1.2);
    _fansButton.center=CGPointMake(_fansLabel.center.x, _fansLabel.center.y+1.5*_attentionLabel.frame.size.height);
    [_fansButton setTitle:@"粉丝" forState:UIControlStateNormal];
    [_fansButton setTitleColor:kColor(167, 167, 167) forState:UIControlStateNormal];
    _fansButton.titleLabel.font=[UIFont systemFontOfSize:12.0f];
    _fansButton.titleLabel.font=[UIFont boldSystemFontOfSize:12];
    [_fansButton setTitleColor:kColor(0, 216, 165) forState:UIControlStateHighlighted];
    [_fansButton addTarget:self action:@selector(fansButtonClick) forControlEvents:UIControlEventTouchUpInside];
    
    _attentionOtherUserBtn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    _attentionOtherUserBtn.frame=CGRectMake(0, 0, 0.20*kWidth, 0.07*kWidth);
    _attentionOtherUserBtn.center=CGPointMake(_faceView.center.x, _fansButton.center.y+0.08*kHeight);
    [_attentionOtherUserBtn.layer setMasksToBounds:YES];
    [_attentionOtherUserBtn.layer setCornerRadius:1];
    [_attentionOtherUserBtn.layer setBorderWidth:1];
    //    [btn.layer setBorderColor:[kColor(0, 216, 165) .CGColor]];
    _attentionOtherUserBtn.layer.borderColor = kColor(0, 216, 165).CGColor;
    [_attentionOtherUserBtn setTitle:@"关注" forState:UIControlStateNormal];
    [_attentionOtherUserBtn setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
    _attentionOtherUserBtn.titleLabel.font=[UIFont systemFontOfSize:14];
    [_attentionOtherUserBtn addTarget:self action:@selector(otherUserBtnClick) forControlEvents:UIControlEventTouchUpInside];
    
    
    //创建 “话题” 按钮
    
    topicButton = [self buttonWithFrame:CGRectMake(0.04*kWidth, kHeight*0.5, 0.46*kWidth, 0.05*kHeight) title:@"话题" tag:3001 ];
    [topicButton setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
    topicButton.backgroundColor=[UIColor clearColor];
    
    //创建 “作品” 按钮
    
    opusButton = [self buttonWithFrame:CGRectMake(0.04*kWidth+topicButton.frame.size.width, kHeight*0.5, 0.46*kWidth, 0.05*kHeight) title:@"作品" tag:3002 ];
    opusButton.backgroundColor=[UIColor clearColor];
    
    topLineView=[[UIView alloc]initWithFrame:CGRectMake(topicButton.frame.origin.x,opusButton.frame.origin.y-2, topicButton.frame.size.width+opusButton.frame.size.width, 1)];
    topLineView.backgroundColor=kColor(216, 216, 216);
    
    
    underLineView=[[UIView alloc]initWithFrame:CGRectMake(topicButton.frame.origin.x, kHeight*0.5+topicButton.frame.size.height+1, topicButton.frame.size.width+opusButton.frame.size.width, 1)];
    underLineView.backgroundColor=kColor(216, 216, 216);
    
    
    midLineView=[[UIView alloc]initWithFrame:CGRectMake(opusButton.frame.origin.x, opusButton.frame.origin.y+opusButton.frame.size.height*0.21, 1, 0.61*opusButton.frame.size.height)];
    midLineView.backgroundColor=kColor(216, 216, 216);
    
}
#pragma mark ---custom button

-(UIButton *)buttonWithFrame:(CGRect)frame title:(NSString *)title tag:(NSInteger)tag
{
    UIButton *otherTopicButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    otherTopicButton.frame=frame;
    
    [otherTopicButton setTitle:title forState:UIControlStateNormal];
    otherTopicButton.backgroundColor=[UIColor whiteColor];
    otherTopicButton.titleLabel.font=[UIFont systemFontOfSize:14.0f];
    otherTopicButton.titleLabel.font=[UIFont boldSystemFontOfSize:15.0];
    [otherTopicButton setTitleColor:kColor(216, 216, 216) forState:UIControlStateNormal];
    [otherTopicButton addTarget:self action:@selector(otherTopicButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    otherTopicButton.tag = tag;
    
    return otherTopicButton;
}
NSInteger customTag1 = 3001;
-(void)otherTopicButtonClick:(UIButton *)sender
{
    UIButton *cusBtn = (UIButton *)[self.view viewWithTag:customTag1];
    [cusBtn setTitleColor:kColor(216, 216, 216) forState:UIControlStateNormal];
    switch (sender.tag) {
        case 3001:
        {
            [sender setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
            self.viewFlag1 = TOPICVIEW1;
            [self netWorkingOtherWithType:@"topics"];
            self.totleArr = self.topicArr;
            [self.otherCollectionView reloadData];
        }
            break;
        case 3002:{
            [sender setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
            self.viewFlag1 = OPUSVIEW1;
            [self netWorkingOtherWithType:@"works"];
            self.totleArr = self.opusArr;
            [self.otherCollectionView reloadData];
            
        }
            break;
            
        default:
            break;
    }
    self.totleArr = self.topicArr;
    customTag1 = sender.tag;
}


#pragma mark --UICollectionViewDataSource
//定义展示的UICollectionViewCell的个数
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (self.viewFlag1==TOPICVIEW1) {
        return self.topicArr.count;
    }else {
        return self.opusArr.count;
    }
}
//定义展示的Section的个数
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}
//每个UICollectionView的展示内容
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.viewFlag1 == TOPICVIEW1) {
        static NSString *idw =@"cell";
        [collectionView registerClass:[userCollectionViewCell class] forCellWithReuseIdentifier:idw];
        userCollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:idw forIndexPath:indexPath];
        [cell sizeToFit];
        if (!cell) {
            cell = [[userCollectionViewCell alloc]init];
        }
        [cell.imgView sd_setImageWithURL:[self.topicArr[indexPath.row]objectForKey:@""]];
        return cell;
    }else 
    {
        static NSString *ide =@"cell1";
        [collectionView registerClass:[userOpusCollectionViewCell class] forCellWithReuseIdentifier:ide];
        userOpusCollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:ide forIndexPath:indexPath];
        [cell sizeToFit];
        if (!cell) {
            cell = [[userOpusCollectionViewCell alloc]init];
        }
        [cell.imgView sd_setImageWithURL:[self.opusArr[indexPath.row]objectForKey:@""]];
        return cell;
        
        }
}

//头部显示的内容
-(UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    UICollectionReusableView *headerView=[collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"ReysableView1" forIndexPath:indexPath];
    
    headerView.backgroundColor=[UIColor clearColor];
    [headerView addSubview:_headerImageView];//头部广告栏
    [headerView addSubview:_faceView];
    [headerView addSubview:_attentionLabel];
    [headerView addSubview:_fansLabel];
    [headerView addSubview:_attentionButton];
    [headerView addSubview:_fansButton];
    [headerView addSubview:_attentionOtherUserBtn];
    
    [headerView addSubview:topicButton];
    [headerView addSubview:opusButton];
    
    [headerView addSubview:topLineView];
    [headerView addSubview:underLineView];
    [headerView addSubview:midLineView];
    return headerView;
    
}


#pragma mark --UICollectionViewDelegateFlowLayout
//定义每个UICollectionView 大小
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.viewFlag1==TOPICVIEW1 ) {
        return CGSizeMake(0.44*kWidth, 0.44*kWidth);
    }else if(self.viewFlag1==OPUSVIEW1)
    {
        return CGSizeMake(0.44*kWidth, 0.38*kHeight);
    }else
    {
        return CGSizeMake(10, 10);
    }
}

//定义每个UICollectinView的 间距
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0.03*kHeight, 0.04*kWidth, 15,0.04*kWidth);
    
}

//定义每个UICollectionView的 纵向间距
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    
    return 0.04*kWidth;
}


#pragma mark --UICollectionViewDelegate
//UICollectionView被选中时调用的方法
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"选择了%ld",indexPath.row);
    
    
    
}


//返回这个UICollectionView是否可以被选择；
-(BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}


#pragma mark --buttonClick
-(void)fansButtonClick
{
    fansViewController *goFans=[[fansViewController alloc]init];
    UIBarButtonItem *backitem = [[UIBarButtonItem alloc]init];
    backitem.title = @"";
    
    self.navigationItem.backBarButtonItem = backitem;
    self.navigationController.navigationBar.tintColor = kColor(0, 216, 165);
    [self.navigationController pushViewController:goFans animated:YES];
}
-(void)attentionButtonClick
{
    attentionViewController *goAttention=[[attentionViewController alloc]init];
    
    UIBarButtonItem *backitem = [[UIBarButtonItem alloc]init];
    backitem.title = @"";
    
    
    self.navigationItem.backBarButtonItem = backitem;
    self.navigationController.navigationBar.tintColor = kColor(0, 216, 165);
    [self.navigationController pushViewController:goAttention animated:YES];
    
}

-(void)otherUserBtnClick
{
    [_attentionOtherUserBtn setTitle:@"已关注" forState:UIControlStateNormal];
    [_attentionOtherUserBtn setTitleColor:kColor(216, 216, 216) forState:UIControlStateNormal];
    _attentionOtherUserBtn.layer.borderColor=kColor(216, 216, 216).CGColor;
}

-(void)back
{
    self.navigationController.navigationBar.alpha = 0;
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark -- load data

//user info
-(void)loadSelfInfo:(int)userId
{
    NSString *strUrl = [NSString stringWithFormat:@"%@%@",HOST,@"member/browse/info"];
    NSDictionary *para = @{
                           kUserId:[NSNumber numberWithInt:userId] //参数是动态获取的
                           };
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:strUrl parameters:para success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"self info:%@",responseObject);
        
        if ([[responseObject objectForKey:@"code"] integerValue] == 1) {
            [self.headerDicM setObject:[[responseObject objectForKey:@"data"] objectForKey:@"userName"] forKey:@"userName"];
            
            [self.headerDicM setObject:[[responseObject objectForKey:@"data"] objectForKey:@"concerns"] forKey:@"concerns"];
            
            [self.headerDicM setObject:[[responseObject objectForKey:@"data"] objectForKey:@"fans"] forKey:@"fans"];
            
            [self.headerDicM setObject:[[responseObject objectForKey:@"data"] objectForKey:@"photo"] forKey:@"photo"];
            
            [self.headerDicM setObject:[[responseObject objectForKey:@"data"] objectForKey:@"background"] forKey:@"background"];
        }
        [self.collectionView reloadData];
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        NSLog(@"self info error:%@",error);
    }];

}

// other : topic, works,
-(void)netWorkingOtherWithType:(NSString *)type
{
    self.otherUserId = @"3";
    NSString *strUrl = [NSString stringWithFormat:@"%@%@%@",HOST,@"member/browse/",type];
    NSDictionary *para =  @{@"userId":self.otherUserId};
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:strUrl parameters:para success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"other Info:%@",responseObject);
 
        if ([type isEqualToString:@"topics"]){
            
            [self.topicArr removeAllObjects];
            
            for (NSDictionary *dic in [[responseObject objectForKey:@"data"] objectForKey:@"rows"]){
                
                [self.topicArr addObject:dic];
            }
            
        }else {
            [self.opusArr removeAllObjects];
            
            for (NSDictionary *dic in [[responseObject objectForKey:@"data"] objectForKey:@"rows"]){
                
                [self.opusArr addObject:dic];
            }
            
        }
        [self.otherCollectionView reloadData];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        NSLog(@"other error:%@",error);

    }];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
