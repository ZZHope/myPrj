//
//  UserViewController.h
//  xike
//
//  Created by shaker on 15/6/1.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "common.h"
#import "fansViewController.h"
#import "attentionViewController.h"
#import "setViewController.h"
#import "userCollectionViewCell.h"
#import "userOpusCollectionViewCell.h"
#import "userLikeCollectionViewCell.h"
#import "AFNetworking.h"
#import "contentViewController.h"
@interface UserViewController : UIViewController


@end
