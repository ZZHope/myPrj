//
//  emptyCollectionViewCell.h
//  xike
//
//  Created by MarilynEric on 15/8/18.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface emptyCollectionViewCell : UICollectionViewCell

@end
