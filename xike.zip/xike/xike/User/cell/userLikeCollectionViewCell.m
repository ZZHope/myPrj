//
//  userLikeCollectionViewCell.m
//  xike
//
//  Created by a on 15/6/23.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "userLikeCollectionViewCell.h"

@implementation userLikeCollectionViewCell
-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if (self) {
        self.backgroundColor=[UIColor whiteColor];
    _imgView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.contentView.frame.size.width,self.contentView.frame.size.height*0.88)];
        
    _userNameLabel=[[UILabel alloc]initWithFrame:CGRectMake(0, self.contentView.frame.size.height*0.90, self.contentView.frame.size.width/2, self.contentView.frame.size.height*0.1)];
    
    _likeNumberLabel=[[UILabel alloc]initWithFrame:CGRectMake(_userNameLabel.frame.size.width, self.contentView.frame.size.height*0.90, self.contentView.frame.size.width/4, self.contentView.frame.size.height*0.1)];
        
    _likeImgView =[[UIImageView alloc]initWithFrame:CGRectMake(self.contentView.frame.size.width*0.85, self.contentView.frame.size.height*0.93, self.contentView.frame.size.width/11, self.contentView.frame.size.height*0.05)];
    }
    
    _imgView.backgroundColor=kColor(216, 216, 216);
    _imgView.image=[UIImage imageNamed:@"4"];
    [self.contentView addSubview:_imgView];
    
    
    _userNameLabel.text=@"Justin Beck";
    [_userNameLabel setTextColor:kColor(0, 216, 165)];
    _userNameLabel.font=[UIFont systemFontOfSize:12];
    //[userNameLabel sizeToFit];
    [self.contentView addSubview:_userNameLabel];
    
    
   
    _likeNumberLabel.text=@"12";
    _likeNumberLabel.font=[UIFont systemFontOfSize:14];
    _likeNumberLabel.textAlignment=NSTextAlignmentRight;
    _likeNumberLabel.textColor=kColor(167, 167, 167);
    [self.contentView addSubview:_likeNumberLabel];
    
    
    _likeImgView.image=[UIImage imageNamed:@"like"];
    [self.contentView addSubview:_likeImgView];
    
    return self;
}
@end
