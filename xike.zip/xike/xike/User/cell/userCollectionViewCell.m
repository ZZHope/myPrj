//
//  userCollectionViewCell.m
//  xike
//
//  Created by a on 15/6/23.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "userCollectionViewCell.h"

@implementation userCollectionViewCell
-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if (self) {
        self.backgroundColor=kColor(0, 216, 165);
        _imgView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.contentView.frame.size.width, self.contentView.frame.size.height)];
    }
    
    _imgView.backgroundColor=kColor(216, 216, 216);
    _imgView.image=[UIImage imageNamed:@"3"];
    [self.contentView addSubview:_imgView];
    return self;
}
@end
