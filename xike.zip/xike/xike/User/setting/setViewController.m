//
//  setViewController.m
//  xike
//
//  Created by a on 15/6/12.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "setViewController.h"
#import "common.h"
#import "AFNetworking.h"
#import "Networking.h"
#import "UIImageView+WebCache.h"
#import "UserSingleton.h"

@interface setViewController ()<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
@property(nonatomic,strong)UITableView *setTableView;
@property(nonatomic,strong)UITextField *textField;
@property(nonatomic,strong)UIImageView *photoImage;

@end


@implementation setViewController
{
    UIActionSheet *myActionSheet;
    UIGestureRecognizer *tap;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self buildTableView];
    
    [self navRightBar];
    //self.navigationController.navigationBarHidden=YES;
    
    tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(resignKeyBoard)];
    
}

-(void)viewWillDisappear:(BOOL)animated
{
   // self.navigationController.navigationBarHidden=NO;
}


-(void)navRightBar
{
    self.title=@"设置";
    
    UIBarButtonItem *rightItemCustm=[[UIBarButtonItem alloc]initWithTitle:@"保存" style:UIBarButtonItemStyleDone target:self action:@selector(rightCustmKeep)];
    self.navigationItem.rightBarButtonItem=rightItemCustm;
}

-(void)buildTableView
{
    _setTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kHeight) style:UITableViewStylePlain];
    
    _setTableView.delegate=self;
    _setTableView.dataSource=self;
    
    [self.view addSubview:_setTableView];
    
}

#pragma mark -- UITableViewDataSource
////设置每个section中有多少个cell
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section==0) {
        return 2;
    }else if (section==1)
    {
        return 5;
    }else
    {
        return 0;
    }
}

//绘制tableViewCell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *settingTableView=@"cellID1";
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:settingTableView];
    if (cell==nil) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:settingTableView];
        
    }
    //[cell.contentView addSubview:_setTableView];
    UILabel *label=[[UILabel alloc]initWithFrame:CGRectMake(20, kHeight*0.10*0.1, kWidth*0.22, kHeight*0.10*0.8)];
    label.backgroundColor=[UIColor clearColor];
    label.font=[UIFont systemFontOfSize:14.0f];
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    if (indexPath.section==0) {
        NSArray *cellArray = [NSArray arrayWithObjects: @"头像", @"昵称",nil];
        label.text=[cellArray objectAtIndex:indexPath.row];
        if (indexPath.row==0) {
            _photoImage=[[UIImageView alloc]initWithFrame:CGRectMake(0.82*kWidth, cell.frame.size.height*0.12, kHeight*0.10*0.8, kHeight*0.10*0.8)];
            _photoImage.layer.cornerRadius = 2;
            _photoImage.backgroundColor=[UIColor whiteColor];
       
            [_photoImage sd_setImageWithURL:[NSURL URLWithString:self.photoUrl] placeholderImage:[UIImage imageNamed:@"defaultUserPic3"]];
            
            [cell.contentView addSubview:_photoImage];
        }else
        {
            _textField=[[UITextField alloc]initWithFrame:CGRectMake(20+kWidth*0.22, kHeight*0.10*0.1, kWidth-20-kWidth*0.22, kHeight*0.10*0.8)];
            _textField.delegate=self;
            self.textField.text = self.settingNickName;
            _textField.font=[UIFont systemFontOfSize:13.0f];
            _textField.backgroundColor=[UIColor clearColor];
            [cell.contentView addSubview:_textField];
        }
    }else
    {
        NSArray *cell1Array=[NSArray arrayWithObjects:@"关于稀客",@"意见反馈",@"给稀客打分",@"清理缓存",@"修改密码", nil];
        label.text=[cell1Array objectAtIndex:indexPath.row];
    }
    
    
    
    
    [cell.contentView addSubview:label];
    return cell;
}

//设置有几个section  默认为1
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 3;
}

//cell的响应  当选择cell是调用
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section==0) {
        if (indexPath.row==0) {
            myActionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"打开照相机",@"从手机相册获取", nil];//此版本暂不做调整图片
            myActionSheet.tag = 1;
            [myActionSheet showInView:self.view];
        }
    }else if (indexPath.section==1)
    {
        if (indexPath.row==0) {
            shaKerViewController *aboutShaKer=[[shaKerViewController alloc]init];
            UIBarButtonItem *backitem = [[UIBarButtonItem alloc]init];
            backitem.title = @"返回";
            
            //self.navigationItem.backBarButtonItem.title = @"";
            self.navigationItem.backBarButtonItem = backitem;
            self.navigationController.navigationBar.tintColor = kColor(0, 216, 165);
            [self.navigationController pushViewController:aboutShaKer animated:YES];
        }else if(indexPath.row==1)
        {
            feedBackViewController *feedBack=[[feedBackViewController alloc]init];
            
            UIBarButtonItem *backItem=[[UIBarButtonItem alloc]init];
            backItem.title=@"返回";
            self.navigationItem.backBarButtonItem=backItem;
            
            [self.navigationController pushViewController:feedBack animated:YES];
        }else if(indexPath.row==2)
        {
            [[UIApplication sharedApplication] openURL: [NSURL URLWithString:@"itms-apps://itunes.apple.com/WebObjects/MZStore.woa/wa/viewContentsUserReviews?mt=8&onlyLatestVersion=true&pageNumber=0&sortOrdering=1&type=Purple+Software&id=924809913"]];
            NSLog(@"++++%@",[NSURL URLWithString:@"itms-apps://itunes.apple.com/WebObjects/MZStore.woa/wa/viewContentsUserReviews?mt=8&onlyLatestVersion=true&pageNumber=0&sortOrdering=1&type=Purple+Software&id=924809913"]);
            
        }else if(indexPath.row==3)
        {
            #pragma 清除缓存
            
            [MBProgressHUD showMessage:@"清理缓存中。。。" toView:self.view];
            [[SDImageCache sharedImageCache] clearDiskOnCompletion:^{
                
                [MBProgressHUD hideHUDForView:self.view];
               

            }];
            [[SDImageCache sharedImageCache] clearMemory];
        }else
        {
            changePasswordViewController *changePassword=[[changePasswordViewController alloc]init];
           // changePassword.user = _user;
            //changePassword.database = _database;
            UIBarButtonItem *backItem=[[UIBarButtonItem alloc]init];
            backItem.title=@"返回";
            self.navigationItem.backBarButtonItem=backItem;
            [self.navigationController pushViewController:changePassword animated:YES];
        }
    NSLog(@"选择了%ld",indexPath.row);
    }
}


#pragma mark -- UITableViewDelegate
//设置每个cell的高度
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return kHeight*0.10;
    
}

//设置section header的高度
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section==0) {
        return kHeight*0.04;
    }else if(section==1)
    {
        return kHeight*0.04;
    }else{
        return kHeight-64-(kHeight*0.09)*7-(kHeight*0.04)*2;
    }
    
}

//设置头视图中的view；
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (section==0) {
        UIView *underView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kHeight*0.04)];
        underView.backgroundColor=kColor(234, 234, 234);
        
        UIView *view=[[UIView alloc]initWithFrame:CGRectMake(0, 1, kWidth, kHeight*0.04-2)];
        view.backgroundColor=[UIColor whiteColor];
        
        
        UILabel *label=[[UILabel alloc]initWithFrame:CGRectMake(20, 0, kWidth/3, kHeight*0.04)];
        label.text=@"个人资料";
        label.font=[UIFont systemFontOfSize:12.0f];
        [label setTextColor:kColor(167 , 167 , 167)];
        
        [view addSubview:label];
        
        [underView addSubview:view];
        return underView;
    }
    else if(section==1)
    {
        UIView *underView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kHeight*0.04)];
        underView.backgroundColor=kColor(234, 234, 234);
        
        UIView *view=[[UIView alloc]initWithFrame:CGRectMake(0, 1, kWidth, kHeight*0.04-2)];
        view.backgroundColor=[UIColor whiteColor];
        
            
        UILabel *label=[[UILabel alloc]initWithFrame:CGRectMake(20, 0, kWidth/3, kHeight*0.04)];
        label.text=@"支持";
        label.font=[UIFont systemFontOfSize:12.0f];
        [label setTextColor:kColor(167 , 167 , 167)];
        
        [view addSubview:label];
        
        [underView addSubview:view];
        return underView;
    }else{
        UIView *underView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kHeight*0.04)];
        underView.backgroundColor=kColor(234, 234, 234);
        
        UIView *view=[[UIView alloc]initWithFrame:CGRectMake(0, 1, kWidth,kHeight-64-(kHeight*0.09)*7-(kHeight*0.04)*2-1)];
        view.backgroundColor=[UIColor whiteColor];
        
        UIButton *outButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];
        outButton.frame=CGRectMake(0.15*kWidth, 0.2*view.frame.size.height, kWidth*0.7, 0.06*kHeight) ;
        outButton.backgroundColor=kColor(0, 216, 165);
        [outButton setTitle:@"退出登录" forState:UIControlStateNormal];
        [outButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [outButton.layer setCornerRadius:3];
        [outButton addTarget:self action:@selector(outButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        
        [view addSubview:outButton];
        [underView addSubview:view];
        return underView;
    }
}

//设置页脚footer的高度
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    
    return 0.1;
}

#pragma mark -UITextField Delegate Method
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    _textField.returnKeyType = UIReturnKeyDone;
    [_textField resignFirstResponder];
    return YES;
}
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    _textField.returnKeyType = UIReturnKeyDone;
    return YES;
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [_textField resignFirstResponder];
   // [_setTableView endEditing:YES];
}

-(void)outButtonClick:(UIButton *)sender
{
    //RecommendViewController *backRecommendView=[[RecommendViewController alloc]init];
    [[NSUserDefaults standardUserDefaults]setBool:NO forKey:isLogin];
    [[NSUserDefaults standardUserDefaults]setObject:@"" forKey:kAuthCode];
    [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:kDeviceToken];
    [[NSUserDefaults standardUserDefaults] synchronize];
    //注销登陆以后进入首页
    self.tabBarController.selectedViewController = self.tabBarController.viewControllers[0];
    [self.navigationController popToRootViewControllerAnimated:YES];
    //返回首页 并注销
}

-(void)rightCustmKeep
{
//    NSLog(@"%@",_textField.text);
    
    if (self.photoImage.image != nil) {
       
        [self changeUserImgAndNick];
    }
    

}



#pragma mark -- actionSheet

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex) {
        case 0://take photo
            
            [self pickImageByType:UIImagePickerControllerSourceTypeCamera];
            
            break;
        case 1://local photo
            
            [self pickImageByType:UIImagePickerControllerSourceTypePhotoLibrary];
            break;
            
            
        default:
            break;
    }
}


#pragma mark -- 拍照上传或者从照片库获取图片

-(void)pickImageByType:(UIImagePickerControllerSourceType)sourceType
{
    UIImagePickerController *picker = [[UIImagePickerController alloc]init];
    picker.delegate =self;
    picker.allowsEditing =YES;
    
    
    if (sourceType == UIImagePickerControllerSourceTypeCamera) {
        
        if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
            
            UIAlertView *alerView = [[UIAlertView alloc]initWithTitle:@"无法拍照" message:@"此设备拍照功能不可用" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil];
            [alerView show];
            
        }else{
            picker.sourceType =sourceType;
            [self presentViewController:picker animated:YES completion:nil];
        }
        
    }else{
        picker.sourceType =sourceType;
        [self presentViewController:picker animated:YES completion:nil];
    }
}

#pragma mark --  picker delegate


-(void)imagePickerController:(UIImagePickerController*)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    [picker dismissViewControllerAnimated:YES completion:^(){
        UIImage* image = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
        _photoImage.image = image;
    }];
    
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    NSLog(@"您取消了选择图片");
    [picker dismissViewControllerAnimated:YES completion:nil];
    
}

#pragma mark UITextViewDelegate
- (void)textFieldDidBeginEditing:(UITextView *)textView {
    [_setTableView addGestureRecognizer:tap];
    
    
}

- (void)textFieldDidEndEditing:(UITextView *)textView {
    [self resignKeyBoard];
    
}

- (void)resignKeyBoard {
    [_textField resignFirstResponder];
    
    [_setTableView removeGestureRecognizer:tap];
}

-(void)changeUserImgAndNick
{
    [MBProgressHUD showMessage:@"正在保存用户信息" toView:self.view];
    NSString *strUrl = [NSString stringWithFormat:@"%@%@",HOST,@"site/user/update"];
    NSDictionary *para = @{kAuthCode:[[NSUserDefaults standardUserDefaults]objectForKey:kAuthCode],
                           kDeviceToken:[[NSUserDefaults standardUserDefaults] objectForKey:kDeviceToken],
                           @"nickname":self.textField.text};
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager POST:strUrl parameters:para constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        
        NSData *photoData = UIImageJPEGRepresentation(self.photoImage.image, 1.0f);
        [formData appendPartWithFileData:photoData name:@"photo" fileName:@"photo" mimeType:@"image/jpge"];
        
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog( @"change user:%@",responseObject);
        [MBProgressHUD hideHUDForView:self.view];
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"保存成功" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        [self.navigationController popViewControllerAnimated:YES];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"change error:%@",error);
        [MBProgressHUD hideHUDForView:self.view];
    }];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
