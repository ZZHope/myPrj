//
//  changePasswordViewController.m
//  xike
//
//  Created by a on 15/6/16.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "changePasswordViewController.h"
#import "Networking.h"
#import "AFNetworking.h"

@interface changePasswordViewController ()<UITextFieldDelegate>
@property(nonatomic,strong)UIView *backgroundView;
@end

@implementation changePasswordViewController
{
    UIGestureRecognizer *tap;
    UITextField *oldPwdField;
    UITextField *newPwdField;
    UITextField *confirmPwdField;
    int retryNum;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title=@"修改密码";
    
    tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(resignKeyBoard)];
    
    [self buildBackgroundView];
    
    [self buildNavRightBar];
    
    [self buildView];
}
-(void)buildBackgroundView
{
    _backgroundView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kHeight)];
    _backgroundView.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:_backgroundView];
}

-(void)buildNavRightBar
{
    UIBarButtonItem *rightCuston=[[UIBarButtonItem alloc]initWithTitle:@"保存" style:UIBarButtonItemStyleDone target:self action:@selector(rightCustonClick)];
    self.navigationItem.rightBarButtonItem=rightCuston;
}


-(void)buildView
{
    UILabel *paddingLabel1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 14, 47)];
    UILabel *paddingLabel2 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 14, 47)];
    UILabel *paddingLabel3 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 14, 47)];
    oldPwdField = [[UITextField alloc] initWithFrame:CGRectMake(17, 13, kWidth-17*2, 47)];
    oldPwdField.backgroundColor = kColor(231, 231, 231);
    oldPwdField.layer.cornerRadius = 4;
    oldPwdField.font = [UIFont systemFontOfSize:14];
    oldPwdField.textColor = kColor(68, 68, 68);
    oldPwdField.secureTextEntry = YES;
    oldPwdField.delegate = self;
    oldPwdField.leftView = paddingLabel1;
    oldPwdField.leftViewMode = UITextFieldViewModeAlways;
    NSMutableAttributedString *placeholder1 = [[NSMutableAttributedString alloc] initWithString:@"输入旧密码"];
    [placeholder1 addAttribute:NSForegroundColorAttributeName value:kColor(167, 167, 167) range:NSMakeRange(0, placeholder1.length)];
    oldPwdField.attributedPlaceholder = placeholder1;
    [_backgroundView addSubview:oldPwdField];
    
    newPwdField = [[UITextField alloc] initWithFrame:CGRectMake(17, 77, kWidth-17*2, 47)];
    newPwdField.backgroundColor = kColor(231, 231, 231);
    newPwdField.layer.cornerRadius = 4;
    newPwdField.font = [UIFont systemFontOfSize:14];
    newPwdField.textColor = kColor(68, 68, 68);
    newPwdField.secureTextEntry = YES;
    newPwdField.delegate = self;
    newPwdField.leftView = paddingLabel2;
    newPwdField.leftViewMode = UITextFieldViewModeAlways;
    NSMutableAttributedString *placeholder2 = [[NSMutableAttributedString alloc] initWithString:@"输入新密码"];
    [placeholder2 addAttribute:NSForegroundColorAttributeName value:kColor(167, 167, 167) range:NSMakeRange(0, placeholder2.length)];
    newPwdField.attributedPlaceholder = placeholder2;
    [_backgroundView addSubview:newPwdField];
    
    confirmPwdField = [[UITextField alloc] initWithFrame:CGRectMake(17, 141, kWidth-17*2, 47)];
    confirmPwdField.backgroundColor = kColor(231, 231, 231);
    confirmPwdField.layer.cornerRadius = 4;
    confirmPwdField.font = [UIFont systemFontOfSize:14];
    confirmPwdField.textColor = kColor(68, 68, 68);
    confirmPwdField.secureTextEntry = YES;
    confirmPwdField.delegate = self;
    confirmPwdField.leftView = paddingLabel3;
    confirmPwdField.leftViewMode = UITextFieldViewModeAlways;
    NSMutableAttributedString *placeholder3 = [[NSMutableAttributedString alloc] initWithString:@"确认新密码"];
    [placeholder3 addAttribute:NSForegroundColorAttributeName value:kColor(167, 167, 167) range:NSMakeRange(0, placeholder3.length)];
    confirmPwdField.attributedPlaceholder = placeholder3;
    [_backgroundView addSubview:confirmPwdField];

}

-(void)rightCustonClick
{
    if (oldPwdField.text.length&&newPwdField.text.length&&[newPwdField.text isEqualToString:confirmPwdField.text]) {
        
        NSString *strUrl = [NSString stringWithFormat:@"%@%@",HOST,@"site/user/update/pwd"];
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        NSDictionary *para = @{kAuthCode :[[NSUserDefaults standardUserDefaults] objectForKey:kAuthCode],
                               kDeviceToken:[[NSUserDefaults standardUserDefaults] objectForKey:kDeviceToken],
                               @"oldPassword":oldPwdField.text,
                               @"password":newPwdField.text,
                               @"rePassword":confirmPwdField.text};
        
        [manager POST:strUrl parameters:para success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            NSLog(@"change pwd: %@ msg:%@",responseObject,[responseObject objectForKey:@"msg"]);
            if ([[responseObject objectForKey:@"code"] intValue] == 1) {
                [self.navigationController popViewControllerAnimated:YES];
            }else{
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[responseObject objectForKey:@"msg"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                [alert show];
            }
            
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSLog(@"change pwd error:%@",error);
            
        }];
        
    }
    
}

#pragma mark UITextViewDelegate
- (void)textFieldDidBeginEditing:(UITextView *)textView {
    [_backgroundView addGestureRecognizer:tap];
    [UIView animateWithDuration:0.3f animations:^{
        [_backgroundView setFrame:CGRectMake(0, /*-44*/0, kWidth, kHeight)];
    }];
}

- (void)textFieldDidEndEditing:(UITextView *)textView {
    [self resignKeyBoard];
    [UIView animateWithDuration:0.3f animations:^{
        [_backgroundView setFrame:CGRectMake(0, 0, kWidth, kHeight)];
    }];
}

- (void)resignKeyBoard {
    [oldPwdField resignFirstResponder];
    [newPwdField resignFirstResponder];
    [confirmPwdField resignFirstResponder];
    [_backgroundView removeGestureRecognizer:tap];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
