//
//  shaKerViewController.m
//  xike
//
//  Created by a on 15/6/16.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "shaKerViewController.h"

@interface shaKerViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *tableView;
@end

@implementation shaKerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title=@"关于稀客";
    [self buildTableView];
}
-(void)buildTableView
{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kHeight)style:UITableViewStylePlain];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    
    [self.view addSubview:_tableView];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
{
    return 4;
}

//绘制cell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *tableViewCell=@"cell";
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:tableViewCell];
    if (cell==nil) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:tableViewCell];
    }
    
    UILabel *label=[[UILabel alloc]initWithFrame:CGRectMake(20, kHeight*0.10*0.1, kWidth*0.22, kHeight*0.10*0.8)];
    label.backgroundColor=[UIColor clearColor];
    label.font=[UIFont systemFontOfSize:14.0f];
    NSArray *cellArray = [NSArray arrayWithObjects: @"稀客官网", @"关注微信",@"关注微博",@"联系电话",nil];
    label.text=[cellArray objectAtIndex:indexPath.row];
    [cell.contentView addSubview:label];
    
    if (indexPath.row==3) {
        UILabel *telLabel=[[UILabel alloc]initWithFrame:CGRectMake(20+kHeight*0.22,  kHeight*0.10*0.1, kWidth-(20+kHeight*0.22)-20, kHeight*0.10*0.8)];
        telLabel.backgroundColor=[UIColor clearColor];
        telLabel.font=[UIFont systemFontOfSize:14.0f];
        telLabel.text=@"021-61127786";
        telLabel.textAlignment=NSTextAlignmentRight;
        [cell.contentView addSubview:telLabel];
    }
    
    return cell;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *underView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWidth, 0.47*kHeight)];
    underView.backgroundColor=[UIColor whiteColor];
    
    UIImageView *shaKerIcon=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 0.22*kWidth, 0.13*kHeight)];
    shaKerIcon.center=CGPointMake(kWidth/2, 0.15*kHeight);
    shaKerIcon.backgroundColor=[UIColor clearColor];
    shaKerIcon.image=[UIImage imageNamed:@"shaKerIcon"];
    [underView addSubview:shaKerIcon];
    
    UIView *view=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 0.42*kWidth, 30)];
    view.center=CGPointMake(shaKerIcon.center.x, 0.25*kHeight) ;
    view.backgroundColor=[UIColor clearColor];
    [underView addSubview:view];
    
    UILabel *label=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, 0.25*view.frame.size.width, 30)];
    label.text=@"稀客";
    label.textColor=kColor(0, 216, 165);
    label.font=[UIFont systemFontOfSize:14.0f];
    label.textAlignment=NSTextAlignmentRight;
    [view addSubview:label];
    
    UILabel *label1=[[UILabel alloc]initWithFrame:CGRectMake(0.3*view.frame.size.width, 0, 0.75*view.frame.size.width, 30)];
    label1.text=@"－离开现实表面";
    label1.font=[UIFont systemFontOfSize:14.0f];
    label1.textAlignment=NSTextAlignmentLeft;
    [view addSubview:label1];
    
    
    UILabel *label2=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, 0.72*kWidth, 20)];
    label2.center=CGPointMake(shaKerIcon.center.x, 0.29*kHeight);
    label2.backgroundColor=[UIColor clearColor];
    label2.textAlignment=NSTextAlignmentCenter;
    label2.text=@"反现实给你一把匕首，剖开你不想看或看不透的现实";
    label2.font=[UIFont systemFontOfSize:10.0f];
    
    [underView addSubview:label2];
    
    UILabel *label3=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, 0.72*kWidth, 20)];
    label3.center=CGPointMake(shaKerIcon.center.x, 0.32*kHeight);
    label3.backgroundColor=[UIColor clearColor];
    label3.textAlignment=NSTextAlignmentCenter;
    label3.text=@"超现实送你一支迷幻剂，释放所有与现实无关的想象";
    label3.font=[UIFont systemFontOfSize:10.0f];
    
    [underView addSubview:label3];
    
    UILabel *label4=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, 0.7*kWidth, 20)];
    label4.center=CGPointMake(shaKerIcon.center.x, 0.35*kHeight);
    label4.backgroundColor=[UIColor clearColor];
    label4.textAlignment=NSTextAlignmentRight;
    label4.text=@"版本号v2.10";
    label4.textColor=kColor(167, 167, 167);
    label4.font=[UIFont systemFontOfSize:10.0f];
    
    [underView addSubview:label4];
    
    UIView *lineView=[[UIView alloc]initWithFrame:CGRectMake(0, 0.47*kHeight-1, kWidth, 1)];
    lineView.backgroundColor=kColor(216, 216, 216);
    [underView addSubview:lineView];
    
    return underView;
}

//设置有几个section  默认为1
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

#pragma mark -- UITableViewDelegate
//设置每个cell的高度
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return kHeight*0.10;
    
}

//设置section header的高度
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.47*kHeight;
    
}

//设置页脚footer的高度
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    
    return 0.1;
}

//cell的点击相应
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row==0) {
        NSURL *url = [NSURL URLWithString:@"http://www.shaker.mobi/"];
        [[UIApplication sharedApplication]openURL:url];
    }else if(indexPath.row==1)
    {
        [self pasteToBoardWithString:@"稀客shaker"];
        
    }else if(indexPath.row==2)
    {
        [self pasteToBoardWithString:@"shaker520"];
    }else
    {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"联系我们" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
        alert.tag = 2001;
        [alert show];
    }
}

-(void)pasteToBoardWithString:(NSString *)string
{
    UIPasteboard *pasteBoard = [UIPasteboard generalPasteboard];
    [pasteBoard setString:string];
    pasteBoard.persistent = YES;
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"关于稀客" message:@"稀客账号已经复制到粘贴板，请登录后关注" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
    [alert show];
}

#pragma mark -- alert delegate

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex) {
        case 0:
            
            break;
        case 1:
        {
            if (alertView.tag==2001) {//tel
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"tel://021-61127786"]];
                
            }
        }
            break;
            
            
        default:
            break;
    }
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
