//
//  feedBackViewController.m
//  xike
//
//  Created by a on 15/6/16.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "feedBackViewController.h"
#import "Networking.h"
#import "AFNetworking.h"

@interface feedBackViewController ()<UITextViewDelegate, NSURLSessionDataDelegate,UIAlertViewDelegate>
@property(nonatomic,strong)UIView* backgroundView;
@end

@implementation feedBackViewController
{
    UITextView *feedbackTextView;
    NSMutableAttributedString *placeholder;
    UITapGestureRecognizer *tap;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self buildBackgroundView];
    self.title=@"意见反馈";
    tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(resignKeyBoard)];
    [self buildNavRightBar];
    [self buildTextView];
}
-(void)buildBackgroundView
{
    _backgroundView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kHeight)];
    _backgroundView.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:_backgroundView];
}
-(void)buildNavRightBar
{
    UIBarButtonItem *rightCuston=[[UIBarButtonItem alloc]initWithTitle:@"发送" style:UIBarButtonItemStyleDone target:self action:@selector(rightCustonClick)];
     self.navigationItem.rightBarButtonItem=rightCuston;
}
-(void)buildTextView
{
    feedbackTextView = [[UITextView alloc] initWithFrame:CGRectMake(17, 13, kWidth-17*2, 140)];
    feedbackTextView.delegate = self;
    feedbackTextView.font = [UIFont systemFontOfSize:12];
    feedbackTextView.backgroundColor = kColor(231, 231, 231);
    placeholder = [[NSMutableAttributedString alloc] initWithString:@"如有建议(或好话题)，稀客欢迎大家畅所欲言，吐槽大战。"];
    [placeholder addAttribute:NSForegroundColorAttributeName value:kColor(167, 167, 167) range:NSMakeRange(0, placeholder.length)];
    [placeholder addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:12] range:NSMakeRange(0, placeholder.length)];
    feedbackTextView.attributedText = placeholder;
    self.automaticallyAdjustsScrollViewInsets = NO;
    [_backgroundView addSubview:feedbackTextView];
    UILabel *tipsLabel = [[UILabel alloc] initWithFrame:CGRectMake(17, 164, kWidth-17*2, 10)];
    tipsLabel.text = @"稀客提示：如果使用不正常可以重启试试";
    tipsLabel.font = [UIFont systemFontOfSize:10];
    tipsLabel.textColor = kColor(167, 167, 167);
    [_backgroundView addSubview:tipsLabel];
}
- (void)resignKeyBoard {
    [feedbackTextView resignFirstResponder];
    [_backgroundView removeGestureRecognizer:tap];
}


#pragma mark TextViewDelegate
- (void)textViewDidBeginEditing:(UITextView *)textView {
    [_backgroundView addGestureRecognizer:tap];
    [feedbackTextView becomeFirstResponder];
    if ([feedbackTextView.text isEqualToString:placeholder.string]) {
        feedbackTextView.text = @"";
    }
    [UIView animateWithDuration:0.3f animations:^{
        [_backgroundView setFrame:CGRectMake(0, /*-44*/0, kWidth  , kHeight)];
    }];
}

- (void)textViewDidEndEditing:(UITextView *)textView {
    if ([feedbackTextView.text isEqualToString:@""]) {
        feedbackTextView.attributedText = placeholder;
    }
    [self resignKeyBoard];
    [UIView animateWithDuration:0.3f animations:^{
        [_backgroundView setFrame:CGRectMake(0, 0, kWidth, kHeight)];
    }];
}

-(void)rightCustonClick
{
    [self sendFeedback];
}

- (void)sendFeedback {
   
    NSString *URLString = [[NSString alloc]initWithFormat:@"%@%@",HOST,@"site/user/add/suggestion"];
    NSDictionary *para = @{kAuthCode:[[NSUserDefaults standardUserDefaults] objectForKey:kAuthCode],
                           kDeviceToken:[[NSUserDefaults standardUserDefaults] objectForKey:kDeviceToken],
                           @"content":feedbackTextView.text};
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    if (feedbackTextView.text.length) {
        [manager POST:URLString parameters:para success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            NSLog(@"feed %@",responseObject);
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"" message:@"发送成功" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
            
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            NSLog(@"feed error:%@",error);
        }];
    }
    
}





#pragma mark --- alert
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark NavigationBarDelegate
- (void)leftBtnClicked {
    [self.navigationController popViewControllerAnimated:YES];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
