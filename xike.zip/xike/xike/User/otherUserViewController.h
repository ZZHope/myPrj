//
//  otherUserViewController.h
//  xike
//
//  Created by a on 15/6/25.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "common.h"
#import "userCollectionViewCell.h"
#import "userOpusCollectionViewCell.h"
#import "fansViewController.h"
#import "attentionViewController.h"
@interface otherUserViewController : UIViewController
@property(strong, nonatomic) NSString *fromTopic;
@property(nonatomic, copy) NSString *otherUserId;
@end
