//
//  fansViewController.m
//  xike
//
//  Created by a on 15/6/11.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "fansViewController.h"
#import "UserSingleton.h"
#import "UIImageView+WebCache.h"

@interface fansViewControllerTableViewCell :UITableViewCell
@property(nonatomic,strong)UIButton *btn;
@property(nonatomic,strong)UIImageView *imgView;
@property(nonatomic,strong)UILabel *fansNameLabel;

@end

@implementation fansViewControllerTableViewCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    //图片
    _imgView=[[UIImageView alloc]initWithFrame:CGRectMake(0.04*self.bounds.size.width, 0.25*self.bounds.size.height, 0.13*self.bounds.size.width, 0.13*self.bounds.size.width)];
    _imgView.backgroundColor=kColor(6, 213, 146);
    
    _imgView.image=[UIImage imageNamed:@"2"];
    
    [self.contentView addSubview:_imgView];
    
    //文字
    _fansNameLabel=[[UILabel alloc]initWithFrame:CGRectMake(65, 17, 200, 30)];
    _fansNameLabel.text=@"Eugene Burke";
    _fansNameLabel.numberOfLines=0;
    _fansNameLabel.font=[UIFont systemFontOfSize:13.0];
    _fansNameLabel.textColor=kColor(137, 137, 136);
    [self.contentView addSubview:_fansNameLabel];
    
    
    _btn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    _btn.frame=CGRectMake(316, 24, 44, 20);
    [_btn.layer setMasksToBounds:YES];
    [_btn.layer setCornerRadius:1];
    [_btn.layer setBorderWidth:1];
    //    [btn.layer setBorderColor:[kColor(0, 216, 165) .CGColor]];
    _btn.layer.borderColor = kColor(0, 216, 165).CGColor;
    [_btn setTitle:@"关注" forState:UIControlStateNormal];
    [_btn setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
    _btn.titleLabel.font=[UIFont systemFontOfSize:12];
    
//    [_btn addTarget:self action:@selector(btnClick) forControlEvents:UIControlEventTouchUpInside];
    
    [self.contentView addSubview:_btn];
    
    return self;
}



@end

@interface fansViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *fansTableView;
@property(nonatomic,strong)NSMutableArray *userFansArrM;

@end

@implementation fansViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title=@"粉丝";
    [self buildFansTableView];
    
    _userFansArrM=[NSMutableArray array];
    
    [self userFansListWithUrl:[[NSUserDefaults standardUserDefaults] objectForKey:kUserId]];
}


-(void)buildFansTableView
{
    _fansTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kHeight) style:UITableViewStyleGrouped];
    _fansTableView.delegate=self;
    _fansTableView.dataSource=self;
    
    [self.view addSubview:_fansTableView];
}

//定义展示的UICollectionViewCell的个数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.userFansArrM.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *fansTableViewCell=@"cellID1";
    fansViewControllerTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:fansTableViewCell];
    if (cell==nil) {
        cell=[[fansViewControllerTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:fansTableViewCell];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        
    }
    [cell.imgView sd_setImageWithURL:[NSURL URLWithString:[self.userFansArrM[indexPath.row]objectForKey:@"photo"]]];
    cell.fansNameLabel.text=[self.userFansArrM[indexPath.row]objectForKey:@"userName"];
    
    [cell.btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    return cell;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.1;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return kHeight*0.11;
}

-(void)btnClick:(UIButton *)sender
{

    
}

#pragma mark -- load data
//用户粉丝列表
-(void)userFansListWithUrl:(NSString*)userId
{
    NSString *strUrl=[NSString stringWithFormat:@"%@%@",HOST,@"member/fans"];
    NSDictionary *attentionTopicDic=@{@"userId":userId,//获取用户的id
                                          kAuthCode:[[NSUserDefaults standardUserDefaults]objectForKey:kAuthCode],
                                          kDeviceToken:[[NSUserDefaults standardUserDefaults] objectForKey:kDeviceToken]};
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:strUrl parameters:attentionTopicDic success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [self.userFansArrM removeAllObjects];
        for (NSDictionary *dic in [[responseObject objectForKey:@"data"] objectForKey:@"rows"]) {
            [self.userFansArrM addObject:dic];
            
            }
        
        [self.fansTableView reloadData];
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSLog(@"cancel error:%@",error);
        }];
}

//关注
-(void)attentionToServiceWithid:(int)concernUserId
{
    NSString *likeUrl = [NSString stringWithFormat:@"%@%@",HOST,@"site/user/concern/add"];
    NSDictionary *parameter = @{@"concernUserId":[NSNumber numberWithInt:concernUserId],//这个值要根据作品获取
                                kAuthCode:[[NSUserDefaults standardUserDefaults] objectForKey:kAuthCode],
                                kDeviceToken:[[NSUserDefaults standardUserDefaults] objectForKey:kDeviceToken]};
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager POST:likeUrl parameters:parameter success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"%@",responseObject);
        //        if ([[responseObject objectForKey:@"code"] intValue] == 1) {
        //
        //            likeImage.image=[UIImage imageNamed:@"like1"];
        //
        //        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"like error:%@",error);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
