//
//  UserViewController.m
//  xike
//
//  Created by shaker on 15/6/1.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "UserViewController.h"
#import "StartViewController.h"
#import "Networking.h"
#import "UserSingleton.h"
#import "AFNetworking.h"
#import "UIImageView+WebCache.h"
#import "userTopicViewController.h"
#import "contentViewController.h"

typedef NS_ENUM(NSInteger, VIEWTYPE)
{
    TOPICVIEW=0,
    OPUSVIEW,
    COLLECTION
};

@interface UserViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@property(nonatomic,strong)UICollectionView *collectionView;
@property(nonatomic,strong)UILabel *navLabel;
@property(nonatomic,strong)UIImageView *headerImageView;
@property(nonatomic,strong)UIImageView *faceView;
@property(nonatomic,strong)UILabel *attentionLabel;
@property(nonatomic,strong)UILabel *fansLabel;
@property(nonatomic,strong)UIButton *attentionButton;
@property(nonatomic,strong)UIButton *fansButton;

@property(nonatomic,assign)NSInteger viewFlag;

@property(nonatomic, strong) NSMutableArray *totleArr;
@property(nonatomic, strong) NSMutableArray *topicArr;
@property(nonatomic, strong) NSMutableArray *opusArr;
@property(nonatomic, strong) NSMutableArray *likeArr;
@property(nonatomic,strong)NSMutableDictionary *headerDicM;
@end



@implementation UserViewController
{
    UIButton *opusButton;
    UIButton *topicButton;
    UIButton *likeButton;
    
    UIView *topLineView;
    UIView *underLineView;
    UIView *midLineView;
    UIView *midLineView2;
    
    UIActionSheet *myActionSheet;
    
}


-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    //数据
    if (![[NSUserDefaults standardUserDefaults]boolForKey:isLogin]) {
        StartViewController *startVC = [[StartViewController alloc]init];
        startVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:startVC animated:YES];
    }else{
        
        
        [self netWorkingWithUrl:@"member/topics"];

         [self loadSelfInfo];

        //记录tabbarItem
        [UserSingleton shareUserSingleton].tabItemIndex = @"4";
        
    }

   
    
    
    [MobClick beginLogPageView:@"UserViewController"];
    
    

}


- (void)viewDidLoad {
    [super viewDidLoad];
    
//    self.navigationItem.titleView
    
    self.viewFlag = TOPICVIEW;
    
    [self buildRightSettingButton];
    
    //collectionView;
    [self buildCollectionView];
    
    //头部广告栏ImageView
    [self buildHeaderImageView];
    
    self.navigationController.navigationBar.translucent= NO;
    
    _totleArr=[NSMutableArray array];
    _topicArr=[NSMutableArray array];
    _opusArr=[NSMutableArray array];
    _likeArr=[NSMutableArray array];
    _headerDicM=[NSMutableDictionary new];
    
    

}

//Navigation右边设置按钮
-(void)buildRightSettingButton
{
    UIImage *img=[UIImage imageNamed:@"shezhi"];
    UIImageView *imgView=[[UIImageView alloc]initWithImage:img];
    imgView.frame=CGRectMake(0, 0, img.size.width, img.size.height);
    UIBarButtonItem *rightItemCuston=[[UIBarButtonItem alloc]initWithCustomView:imgView];
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(setTap:)];
    [imgView addGestureRecognizer:tap];
    tap.numberOfTapsRequired = 1; // 单击
    self.navigationItem.rightBarButtonItem=rightItemCuston;
    
}

#pragma mark ---custom button

-(UIButton *)buttonWithFrame:(CGRect)frame title:(NSString *)title tag:(NSInteger)tag center:(CGPoint)center
{
    UIButton *topic1Button=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    topic1Button.frame=frame;
    topic1Button.center=center;
    [topic1Button setTitle:title forState:UIControlStateNormal];
    topic1Button.backgroundColor=[UIColor whiteColor];
    topic1Button.titleLabel.font=[UIFont systemFontOfSize:14.0f];
    topic1Button.titleLabel.font=[UIFont boldSystemFontOfSize:15.0];
    [topic1Button setTitleColor:kColor(216, 216, 216) forState:UIControlStateNormal];
    [topic1Button addTarget:self action:@selector(topic1ButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    topic1Button.tag = tag;
    
    return topic1Button;
}

//设置按钮的点击手势
-(void)setTap:(UITapGestureRecognizer*)tap
{
    //处理单击操作
    setViewController *setting=[[setViewController alloc]init];
    setting.photoUrl = [self.headerDicM objectForKey:@"photo"];
    setting.settingNickName = [self.headerDicM objectForKey:@"userName"];
    setting.hidesBottomBarWhenPushed=YES;
    
    UIBarButtonItem *backitem = [[UIBarButtonItem alloc]init];
    backitem.title = @"";
    
    //self.navigationItem.backBarButtonItem.title = @"";
    self.navigationItem.backBarButtonItem = backitem;
    self.navigationController.navigationBar.tintColor = kColor(0, 216, 165);
    [self.navigationController pushViewController:setting animated:YES];
}

//头部广告栏ImageView
-(void)buildHeaderImageView
{
    //背景图片
    
    if (nil ==  _headerImageView) {
        
        _headerImageView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, kWidth, 0.24*kHeight)];
        _faceView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 0.16*kWidth, 0.16*kWidth)];
         _attentionLabel=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, 0.16*kWidth-2, _faceView.frame.size.height*0.25)];
        _fansLabel=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, 0.16*kWidth-2, _faceView.frame.size.height*0.25)];
        _attentionButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];
        _attentionButton.frame=CGRectMake(0, 0,_attentionLabel.frame.size.width/2, _attentionLabel.frame.size.height*1.2);
        
        _fansButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];
        _fansButton.frame=CGRectMake(0, 0,_attentionLabel.frame.size.width/2, _attentionLabel.frame.size.height*1.2);
        
        //创建 “作品” 按钮
        opusButton = [self buttonWithFrame:CGRectMake(0, kHeight*0.4, 0.31*kWidth, 0.05*kHeight) title:@"作品" tag:1002 center:CGPointMake(kWidth/2, kHeight*0.453-(0.05*kHeight/2))];
        opusButton.backgroundColor=[UIColor clearColor];
        
        //创建 “话题” 按钮
        
        topicButton = [self buttonWithFrame:CGRectMake(0, 0, 0.31*kWidth, 0.05*kHeight) title:@"话题" tag:1001 center:CGPointMake(opusButton.center.x-(opusButton.frame.size.width+1), opusButton.center.y)];
        [topicButton setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
        topicButton.backgroundColor=[UIColor clearColor];
        
        //创建 “喜欢” 按钮
        
        likeButton = [self buttonWithFrame:CGRectMake(0, 0, 0.31*kWidth, 0.05*kHeight) title:@"喜欢" tag:1003 center:CGPointMake(opusButton.center.x+(opusButton.frame.size.width+1), opusButton.center.y)];
        likeButton.backgroundColor=[UIColor clearColor];
        
        topLineView=[[UIView alloc]initWithFrame:CGRectMake(topicButton.frame.origin.x,opusButton.frame.origin.y-2, topicButton.frame.size.width*3+2, 1)];
        
        topLineView.backgroundColor=kColor(216, 216, 216);
        
        
        underLineView=[[UIView alloc]initWithFrame:CGRectMake(topicButton.frame.origin.x, kHeight*0.4+topicButton.frame.size.height+3, topicButton.frame.size.width*3+2, 1)];
        underLineView.backgroundColor=kColor(216, 216, 216);
        
        
        midLineView=[[UIView alloc]initWithFrame:CGRectMake(opusButton.frame.origin.x-1, opusButton.frame.origin.y+opusButton.frame.size.height*0.21, 1, 0.61*opusButton.frame.size.height)];
        midLineView.backgroundColor=kColor(216, 216, 216);
        
        
        midLineView2=[[UIView alloc]initWithFrame:CGRectMake(likeButton.frame.origin.x-1, opusButton.frame.origin.y+opusButton.frame.size.height*0.21, 1, 0.61*opusButton.frame.size.height)];
        midLineView2.backgroundColor=kColor(216, 216, 216);


  
    }
    _headerImageView.backgroundColor=[UIColor whiteColor];
//========================================================================
    if (![[self.headerDicM objectForKey:@"background"] isEqual:[NSNull null]]) {
       
            [_headerImageView sd_setImageWithURL:[self.headerDicM objectForKey:@"background"] placeholderImage:[UIImage imageNamed:@"1"]];
    }else{
        _headerImageView.image = [UIImage imageNamed:@"1"];
    }

//========================================================================
    _headerImageView.userInteractionEnabled=YES;
     UITapGestureRecognizer *backImageTap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(changeBackImage:)];
    [_headerImageView addGestureRecognizer:backImageTap];
    backImageTap.numberOfTapsRequired = 1; // 单击
    
    //头像图片
    
    
    _faceView.center=CGPointMake(kWidth/2, _headerImageView.frame.size.height);
    
    _faceView.backgroundColor=kColor(216, 216, 216);

//========================================================================
    [_faceView sd_setImageWithURL:[self.headerDicM objectForKey:@"photo"]];
//========================================================================
    
    //设置关注 显示关注数
   
//========================================================================
    _attentionLabel.text= [NSString stringWithFormat:@"%ld",[[self.headerDicM objectForKey:@"concerns"] integerValue]];
//========================================================================
    _attentionLabel.textAlignment=NSTextAlignmentCenter;
    _attentionLabel.font=[UIFont systemFontOfSize:12.0f];
    _attentionLabel.textColor=kColor(74, 74, 74);
    _attentionLabel.center=CGPointMake(_faceView.center.x-_faceView.frame.size.width/2, _faceView.center.y+_faceView.frame.size.height*0.85);
    UITapGestureRecognizer *attentLabelTap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(attentionButtonClick)];
    [_attentionLabel addGestureRecognizer:attentLabelTap];
    _attentionLabel.userInteractionEnabled=YES;
    attentLabelTap.numberOfTapsRequired = 1; // 单击
    
    
    //设置粉丝 显示粉丝数
    
//========================================================================
    _fansLabel.text= [NSString stringWithFormat:@"%ld",[[self.headerDicM objectForKey:@"fans"] integerValue]];
//========================================================================
    _fansLabel.textAlignment=NSTextAlignmentCenter;
    _fansLabel.font=[UIFont systemFontOfSize:12.0f];
    _fansLabel.textColor=kColor(74, 74, 74);
    _fansLabel.center=CGPointMake(_faceView.center.x+_faceView.frame.size.width/2, _faceView.center.y+_faceView.frame.size.height*0.85);
    UITapGestureRecognizer *fansLabelTap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(fansButtonClick)];
    [_fansLabel addGestureRecognizer:fansLabelTap];
    _fansLabel.userInteractionEnabled=YES;
    fansLabelTap.numberOfTapsRequired = 1; // 单击
    
    
    
    //关注的button
   
    _attentionButton.center=CGPointMake(_attentionLabel.center.x, _attentionLabel.center.y+1.5*_attentionLabel.frame.size.height);
    [_attentionButton setTitle:@"关注" forState:UIControlStateNormal];
    [_attentionButton setTitleColor:kColor(167, 167, 167) forState:UIControlStateNormal];
    _attentionButton.titleLabel.font=[UIFont systemFontOfSize:12.0f];
    _attentionButton.titleLabel.font=[UIFont boldSystemFontOfSize:12];
    [_attentionButton setTitleColor:kColor(0, 216, 165) forState:UIControlStateHighlighted];
    
    [_attentionButton addTarget:self action:@selector(attentionButtonClick) forControlEvents:UIControlEventTouchUpInside];
    
    
    
    //粉丝的button

    _fansButton.center=CGPointMake(_fansLabel.center.x, _fansLabel.center.y+1.5*_attentionLabel.frame.size.height);
    [_fansButton setTitle:@"粉丝" forState:UIControlStateNormal];
    [_fansButton setTitleColor:kColor(167, 167, 167) forState:UIControlStateNormal];
    _fansButton.titleLabel.font=[UIFont systemFontOfSize:12.0f];
    _fansButton.titleLabel.font=[UIFont boldSystemFontOfSize:12];
    [_fansButton setTitleColor:kColor(0, 216, 165) forState:UIControlStateHighlighted];
    [_fansButton addTarget:self action:@selector(fansButtonClick) forControlEvents:UIControlEventTouchUpInside];
    
    
}

-(void)changeBackImage:(UITapGestureRecognizer*)tap
{
    myActionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"打开照相机",@"从手机相册获取", nil];//此版本暂不做调整图片
    myActionSheet.tag = 1;
    [myActionSheet showInView:self.view];
}

//collectionView
-(void)buildCollectionView
{
    float AD_height=0.453*kHeight;//广告栏高度
    UICollectionViewFlowLayout *flowLayout=[[UICollectionViewFlowLayout alloc]init];
    [flowLayout setScrollDirection:UICollectionViewScrollDirectionVertical];
    flowLayout.headerReferenceSize = CGSizeMake(kWidth, AD_height);//头部
    self.collectionView=[[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kHeight-113) collectionViewLayout:flowLayout];
    _collectionView.backgroundColor=[UIColor whiteColor];
    _collectionView.showsVerticalScrollIndicator=NO;
    //设置代理
    self.collectionView.delegate=self;
    self.collectionView.dataSource=self;
    
    [self.view addSubview:self.collectionView];
    
    //注册cell和ReusableView(相当于头部)
    [self.collectionView registerClass:[userCollectionViewCell class] forCellWithReuseIdentifier:@"cell1"];
    [self.collectionView registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"ReysableView1"];
}


#pragma mark --UICollectionViewDataSource
//定义展示的UICollectionViewCell的个数
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (self.viewFlag==TOPICVIEW) {
        return self.topicArr.count;
    }else if(self.viewFlag==OPUSVIEW){
        return self.opusArr.count;
    }else{
        return self.likeArr.count;
    }
    
}
//定义展示的Section的个数
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}
//每个UICollectionView的展示内容
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.viewFlag == TOPICVIEW) {
        static NSString *identify =@"cell";
        [collectionView registerClass:[userCollectionViewCell class] forCellWithReuseIdentifier:identify];
        userCollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:identify forIndexPath:indexPath];
        [cell sizeToFit];
        if (!cell) {
            cell = [[userCollectionViewCell alloc]init];
        }
        [cell.imgView sd_setImageWithURL:[NSURL URLWithString:[self.topicArr[indexPath.row]objectForKey:@"logo"]]];
        return cell;
    }else if(self.viewFlag==OPUSVIEW)
    {
        static NSString *identify1 =@"cell1";
        [collectionView registerClass:[userOpusCollectionViewCell class] forCellWithReuseIdentifier:identify1];
        userOpusCollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:identify1 forIndexPath:indexPath];
        [cell sizeToFit];
        if (!cell) {
            cell = [[userOpusCollectionViewCell alloc]init];
        }
        [cell.imgView sd_setImageWithURL:[NSURL URLWithString:[self.opusArr[indexPath.row]objectForKey:@"logo"]]];
        return cell;
    }else{
        static NSString *identify2 =@"cell2";
        [collectionView registerClass:[userLikeCollectionViewCell class] forCellWithReuseIdentifier:identify2];
        userLikeCollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:identify2 forIndexPath:indexPath];
        [cell sizeToFit];
        if (!cell) {
            cell = [[userLikeCollectionViewCell alloc]init];
        }
        [cell.imgView sd_setImageWithURL:[NSURL URLWithString:[self.likeArr[indexPath.row]objectForKey:@"logo"]]];
    cell.userNameLabel.text=[self.likeArr[indexPath.row]objectForKey:@"createUser"];
     cell.likeNumberLabel.text=[self.likeArr[indexPath.row]objectForKey:@"likes"];
        

//        cell.userNameLabel.text=self.collectArr
        return cell;
        
    }
    
}

//头部显示的内容
-(UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    UICollectionReusableView *headerView=[collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"ReysableView1" forIndexPath:indexPath];
    [headerView addSubview:_headerImageView];//头部广告栏
    [headerView addSubview:_faceView];
    [headerView addSubview:_attentionLabel];
    [headerView addSubview:_fansLabel];
    [headerView addSubview:_attentionButton];
    [headerView addSubview:_fansButton];
    
    [headerView addSubview:opusButton];
    [headerView addSubview:topicButton];
    [headerView addSubview:likeButton];
    
    [headerView addSubview:topLineView];
    [headerView addSubview:underLineView];
    [headerView addSubview:midLineView];
    [headerView addSubview:midLineView2];
    
    
    return headerView;
    
}


#pragma mark --UICollectionViewDelegateFlowLayout
//定义每个UICollectionView 大小
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.viewFlag==TOPICVIEW ) {
        return CGSizeMake(0.44*kWidth, 0.44*kWidth);
    }else if(self.viewFlag == OPUSVIEW)
    {
        return CGSizeMake(0.44*kWidth, 0.38*kHeight);
    }else
    {
        return CGSizeMake(0.44*kWidth, 0.43*kHeight);
    }
}

//定义每个UICollectinView的 间距
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0.03*kHeight, 0.04*kWidth, 15,0.04*kWidth);
    
}

//定义每个UICollectionView的 纵向间距
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    
    return 0.04*kWidth;
}

#pragma mark --UICollectionViewDelegate
//UICollectionView被选中时调用的方法
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"选择了%ld",indexPath.row);
        if (self.viewFlag == TOPICVIEW) {
        
        userTopicViewController *topic=[[userTopicViewController alloc]init];
        
        topic.listTopicId = [NSString stringWithFormat:@"%@",[self.topicArr[indexPath.row] objectForKey:@"id"]];
        
        topic.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:topic animated:YES];

    }else if (self.viewFlag == OPUSVIEW)
    {
        contentViewController *contentVC = [[contentViewController alloc]init];
        contentVC.articleId = [self.opusArr[indexPath.row] objectForKey:@"id"];
        [self.navigationController pushViewController:contentVC animated:YES];
        
    }else{
        
        
    }
    //    TopicDetailController *topicDetail = [[TopicDetailController alloc]init];
    //    topicDetail.fromTopic = FromTopic;
    //    topicDetail.hidesBottomBarWhenPushed = YES;
    //    [self.navigationController pushViewController:topicDetail animated:YES];

//        contentViewController *content = [[contentViewController alloc]init];
//        content.articleId=[self.opusArr[indexPath.row] objectForKey:@"id"];
//        content.hidesBottomBarWhenPushed = YES;
//        [self.navigationController pushViewController:content animated:YES];

    
}


//返回这个UICollectionView是否可以被选择；
-(BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

#pragma mark --buttonClick
-(void)fansButtonClick
{
    fansViewController *goFans=[[fansViewController alloc]init];
    UIBarButtonItem *backitem = [[UIBarButtonItem alloc]init];
    backitem.title = @"";
    
    //self.navigationItem.backBarButtonItem.title = @"";
    self.navigationItem.backBarButtonItem = backitem;
    self.navigationController.navigationBar.tintColor = kColor(0, 216, 165);
    [self.navigationController pushViewController:goFans animated:YES];
}
-(void)attentionButtonClick
{
    attentionViewController *goAttention=[[attentionViewController alloc]init];
    
    UIBarButtonItem *backitem = [[UIBarButtonItem alloc]init];
    backitem.title = @"";
    
    
    self.navigationItem.backBarButtonItem = backitem;
    self.navigationController.navigationBar.tintColor = kColor(0, 216, 165);
    [self.navigationController pushViewController:goAttention animated:YES];
    
}

NSInteger customTag = 1001;
-(void)topic1ButtonClick:(UIButton *)sender
{
    UIButton *cusBtn = (UIButton *)[self.view viewWithTag:customTag];
    [cusBtn setTitleColor:kColor(216, 216, 216) forState:UIControlStateNormal];
    //    [sender setTitleColor:[UIColor grayColor] forState:UIControlStateSelected];
    switch (sender.tag) {
        case 1001:
        {
           
            [sender setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
            self.viewFlag = TOPICVIEW;
            [self netWorkingWithUrl:@"member/topics"];
            self.totleArr = self.topicArr;
            [self.collectionView reloadData];
            
        }
            break;
        case 1002:
        {
            
            [sender setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
            self.viewFlag = OPUSVIEW;
            [self netWorkingWithUrl:@"member/works"];
            self.totleArr = self.opusArr;
            [self.collectionView reloadData];
            
        }
            break;
        case 1003:
        {
            
            [sender setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
            self.viewFlag = COLLECTION;
//            self.totleArr = self.collectArr;
            [self netWorkingWithUrl:@"member/likes"];
            self.totleArr = self.likeArr;

            [self.collectionView reloadData];
        }
        default:
            break;
    }
    self.totleArr = self.topicArr;
    customTag = sender.tag;
}

#pragma mark -- actionSheet

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex) {
        case 0://take photo
            
            [self pickImageByType:UIImagePickerControllerSourceTypeCamera];
            
            break;
        case 1://local photo
            
            [self pickImageByType:UIImagePickerControllerSourceTypePhotoLibrary];
            break;
        default:
            break;
    }
}


#pragma mark -- 拍照上传或者从照片库获取图片

-(void)pickImageByType:(UIImagePickerControllerSourceType)sourceType
{
    UIImagePickerController *picker = [[UIImagePickerController alloc]init];
    picker.delegate =self;
    picker.allowsEditing =YES;
    
    
    if (sourceType == UIImagePickerControllerSourceTypeCamera) {
        
        if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
            
            UIAlertView *alerView = [[UIAlertView alloc]initWithTitle:@"无法拍照" message:@"此设备拍照功能不可用" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil];
            [alerView show];
            
        }else{
            picker.sourceType =sourceType;
            [self presentViewController:picker animated:YES completion:nil];
        }
        
    }else{
        picker.sourceType =sourceType;
        [self presentViewController:picker animated:YES completion:nil];
    }
}

#pragma mark --  picker delegate


-(void)imagePickerController:(UIImagePickerController*)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    [picker dismissViewControllerAnimated:YES completion:^(){
        UIImage* image = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
       // _headerImageView.image = image;
        [self uploadBackGroundWithImg:image];
    }];
    
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    NSLog(@"您取消了选择图片");
    [picker dismissViewControllerAnimated:YES completion:nil];
    
}

//get data

// self: topic,works,likes
-(void)netWorkingWithUrl:(NSString*)appendUrl
{
    [MBProgressHUD showMessage:@"loading..." toView:self.collectionView];

    //请求区域数据
    AFHTTPRequestOperationManager *manager =[AFHTTPRequestOperationManager manager];
    
    
    NSString *strUrl=[NSString stringWithFormat:@"%@%@",HOST,appendUrl];
    NSDictionary *para=@{@"authCode":[[NSUserDefaults standardUserDefaults]objectForKey:kAuthCode],
                         @"deviceToken":[[NSUserDefaults standardUserDefaults] objectForKey:kDeviceToken]                         };
    [manager GET:strUrl parameters:para success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [self.collectionView.header endRefreshing];
        
        if ([[responseObject objectForKey:@"code"] intValue] == 1) {
            if (![[responseObject objectForKey:@"data"] isEqual:[NSNull null]]) {
                [MBProgressHUD hideHUDForView:self.collectionView];
               
                if ([appendUrl isEqualToString:@"member/works"]) {
                    [self.opusArr removeAllObjects];
                    
                    for (NSDictionary *dic in [[responseObject objectForKey:@"data"] objectForKey:@"rows"]) {
                        
                        [self.opusArr addObject:dic];
                        
                    }
                    
                }else if ([appendUrl isEqualToString:@"member/topics"]){
                    
                    [self.topicArr removeAllObjects];
                    
                    for (NSDictionary *dic in [[responseObject objectForKey:@"data"] objectForKey:@"rows"]) {
                        
                        [self.topicArr addObject:dic];
                        
                    }
                    
                    
                }else{
                    
                    [self.likeArr removeAllObjects];
                    for (NSDictionary *dic in [[responseObject objectForKey:@"data"] objectForKey:@"rows"]) {
                        
                        [self.likeArr addObject:dic];
                        
                    }
                    
                }
                
                [self.collectionView reloadData];

            }
            
        }else{
            [MBProgressHUD hideHUDForView:self.collectionView];
            UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:nil message:[responseObject objectForKey:@"msg"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alertView show];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"===%@", error);
        [self.collectionView.header endRefreshing];
        [MBProgressHUD hideHUDForView:self.collectionView];
    }];

}

#pragma mark -- load data

//user info
-(void)loadSelfInfo
{
    NSString *strUrl = [NSString stringWithFormat:@"%@%@",HOST,@"member/info"];
    NSDictionary *para = @{
                           kAuthCode :[[NSUserDefaults standardUserDefaults] objectForKey:kAuthCode],
                           kDeviceToken:[[NSUserDefaults standardUserDefaults]objectForKey:kDeviceToken]
                           };
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:strUrl parameters:para success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"self info:%@",responseObject);
        
        if ([[responseObject objectForKey:@"code"] integerValue] == 1) {
            
            if (![[responseObject objectForKey:@"data"]isEqual:[NSNull null]]) {
               
                [self.headerDicM setObject:[[responseObject objectForKey:@"data"] objectForKey:@"userName"] forKey:@"userName"];
                
                [self.headerDicM setObject:[[responseObject objectForKey:@"data"] objectForKey:@"concerns"] forKey:@"concerns"];
                
                [self.headerDicM setObject:[[responseObject objectForKey:@"data"] objectForKey:@"fans"] forKey:@"fans"];
                
                [self.headerDicM setObject:[[responseObject objectForKey:@"data"] objectForKey:@"photo"] forKey:@"photo"];
                
                [self.headerDicM setObject:[[responseObject objectForKey:@"data"] objectForKey:@"background"] forKey:@"background"];

                self.navigationItem.title= [self.headerDicM objectForKey:@"userName"];
                [self buildHeaderImageView];
            }

        }
        
       
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        NSLog(@"self info error:%@",error);
    }];
}



//upload background profile
-(void)uploadBackGroundWithImg:(UIImage *)img
{
    [MBProgressHUD showMessage:@"图片上传中。。。" toView:self.view];
    NSString *strUrl = [NSString stringWithFormat:@"%@%@",HOST,@"member/background/upload"];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSDictionary *para = @{kAuthCode:[[NSUserDefaults standardUserDefaults] objectForKey:kAuthCode],
                           kDeviceToken:[[NSUserDefaults standardUserDefaults]objectForKey:kDeviceToken]};
    [manager POST:strUrl parameters:para constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        
        NSData *imgData = UIImageJPEGRepresentation(img, 1.0f);
        [formData appendPartWithFileData:imgData name:@"backgroundData" fileName:@"backgroundData" mimeType:@"image/jpeg"];
        
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"respond %@",responseObject);
        [MBProgressHUD hideHUDForView:self.view];
         _headerImageView.image = img;
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [MBProgressHUD hideHUDForView:self.view];
        NSLog( @"background error:%@",error);
    }];
}


-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"UserViewController"];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
