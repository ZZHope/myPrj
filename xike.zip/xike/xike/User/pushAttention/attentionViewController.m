//
//  attentionViewController.m
//  xike
//
//  Created by a on 15/6/11.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "attentionViewController.h"
#import "UIImageView+WebCache.h"
@interface attentionViewControllerUserTableViewCell :UITableViewCell
@property(nonatomic,strong)UIButton *btn;
@property(nonatomic ,strong)UIImageView *userPhotoImgView;
@property(nonatomic,strong)UILabel *userNameTextLabel;

@end

@implementation attentionViewControllerUserTableViewCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    //图片
    _userPhotoImgView=[[UIImageView alloc]initWithFrame:CGRectMake(15, 15, 40, 40)];
    _userPhotoImgView.backgroundColor=kColor(0, 216, 165);
    
    _userPhotoImgView.image=[UIImage imageNamed:@"2"];
    
    [self.contentView addSubview:_userPhotoImgView];
    
    //文字
    _userNameTextLabel=[[UILabel alloc]initWithFrame:CGRectMake(65, 17, 200, 30)];
    _userNameTextLabel.text=@"Eugene Burke";
    _userNameTextLabel.numberOfLines=0;
    _userNameTextLabel.font=[UIFont systemFontOfSize:13.0];
    _userNameTextLabel.textColor=kColor(137, 137, 136);
    [self.contentView addSubview:_userNameTextLabel];
    
    
    _btn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    _btn.frame=CGRectMake(316, 24, 44, 20);
    [_btn.layer setMasksToBounds:YES];
    [_btn.layer setCornerRadius:1];
    [_btn.layer setBorderWidth:1];
    //    [btn.layer setBorderColor:[kColor(0, 216, 165) .CGColor]];
    _btn.layer.borderColor = kColor(216, 216, 216).CGColor;
    [_btn setTitle:@"取消关注" forState:UIControlStateNormal];
    [_btn setTitleColor:kColor(216, 216, 216) forState:UIControlStateNormal];
    _btn.titleLabel.font=[UIFont systemFontOfSize:11];
    [_btn addTarget:self action:@selector(cancelAttention:) forControlEvents:UIControlEventTouchUpInside];
    
    // [_btn addTarget:self action:@selector(btnClick) forControlEvents:UIControlEventTouchUpInside];
    
    [self.contentView addSubview:_btn];
    
    return self;
}
-(void)cancelAttention:(UIButton *)sender
{
    [_btn setTitle:@"关注" forState:UIControlStateNormal];
    [_btn setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
    _btn.layer.borderColor=kColor(0, 216, 165).CGColor;
}
@end



//collectionViewCell
//==============================================================================
@interface attentionViewControllerTopicCollectionViewCell : UICollectionViewCell
@property(nonatomic,strong)UIImageView *topicImgView;
@end
@implementation attentionViewControllerTopicCollectionViewCell

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if (self) {
        self.backgroundColor=kColor(0, 216, 165);
    }
    _topicImgView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.contentView.frame.size.width, self.contentView.frame.size.height)];
    _topicImgView.backgroundColor=[UIColor redColor];
    _topicImgView.image=[UIImage imageNamed:@"3"];
    [self.contentView addSubview:_topicImgView];
    return self;
}
@end


@interface attentionViewController ()<UITableViewDelegate,UITableViewDataSource,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>
@property(nonatomic ,strong)UICollectionView *topicCollectionView;
@property(nonatomic ,strong)UITableView *userTableView;
@property(nonatomic ,strong)UIButton *topicButton;
@property(nonatomic ,strong)UIButton *userButton;
@property(nonatomic ,strong)NSMutableArray *attentionUserListM;
@property(nonatomic ,strong)NSMutableArray *attentionTopicListM;
@end

@implementation attentionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title=@"关注";
    self.navigationController.navigationBar.translucent = NO;
    
    [self buildButton];
    [self buildTopicCollectionView];
    [self buildUserTableView];
    [self buildView];

    _attentionUserListM=[NSMutableArray array];
    _attentionTopicListM=[NSMutableArray array];
    [self userAttentionTopicWithUrl:[[[NSUserDefaults standardUserDefaults] objectForKey:kUserId] intValue]];
}

//话题和用户2个button
-(void)buildButton
{
    _topicButton=[self buttonWithFrame:CGRectMake(0, 1, kWidth/2, kHeight*0.07-2) title:@"话题" tag:101 color:kColor(0, 216, 165)];
    [_topicButton setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
    _topicButton.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:_topicButton];
    
    _userButton=[self buttonWithFrame:CGRectMake(kWidth/2+1, 1, kWidth/2-1, kHeight*0.07-2) title:@"用户" tag:102 color:kColor(0, 216, 165)];
    _userButton.backgroundColor= [UIColor whiteColor];
    [self.view addSubview:_userButton];
}


-(void)buildView
{
    UIView *topView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWidth, 1)];
    topView.backgroundColor=kColor(216, 216, 216);
    [self.view addSubview:topView];
    
    UIView *underView=[[UIView alloc]initWithFrame:CGRectMake(0, _topicButton.frame.size.height+1, kWidth, 1)];
    underView.backgroundColor=kColor(216, 216, 216);
    [self.view addSubview:underView];
    
    UIView *lineView=[[UIView alloc]initWithFrame:CGRectMake(_userButton.frame.origin.x-1, 0.14*_userButton.frame.size.height, 1, 0.72*_userButton.frame.size.height)];
    lineView.backgroundColor=kColor(216, 216, 216);
    [self.view addSubview:lineView];
    
}


#pragma mark ---custom button

-(UIButton *)buttonWithFrame:(CGRect)frame title:(NSString *)title tag:(NSInteger)tag color:(UIColor*)color
{
    UIButton *topicButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    topicButton.frame=frame;
    [topicButton setTitle:title forState:UIControlStateNormal];
    topicButton.backgroundColor=[UIColor whiteColor];
    topicButton.titleLabel.font=[UIFont systemFontOfSize:14.0f];
    topicButton.titleLabel.font=[UIFont boldSystemFontOfSize:15.0];
    [topicButton setTitleColor:kColor(216, 216, 216) forState:UIControlStateNormal];
    [topicButton addTarget:self action:@selector(attentionButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    topicButton.tag = tag;
    
    return topicButton;
}


//设置话题展示的collectionView
-(void)buildTopicCollectionView
{
    UICollectionViewFlowLayout *flowLayout=[[UICollectionViewFlowLayout alloc]init];
    [flowLayout setScrollDirection:UICollectionViewScrollDirectionVertical];
    flowLayout.headerReferenceSize = CGSizeMake(0, 0);
    _topicCollectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, kHeight*0.07+1, kWidth, kHeight*0.75) collectionViewLayout:flowLayout];
    _topicCollectionView.backgroundColor=[UIColor whiteColor];
    //隐藏
    _topicCollectionView.showsVerticalScrollIndicator = NO;
    
    [self.view addSubview:_topicCollectionView];
    
    //设置代理
    _topicCollectionView.delegate=self;
    _topicCollectionView.dataSource=self;
    
    [_topicCollectionView registerClass:[attentionViewControllerTopicCollectionViewCell class] forCellWithReuseIdentifier:@"cell"];
    [_topicCollectionView registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"ReysableView"];
}


-(void)buildUserTableView
{
    _userTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, kHeight*0.07-1, kWidth, kHeight*0.75)style:UITableViewStyleGrouped];
    _userTableView.delegate=self;
    _userTableView.dataSource=self;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
    //return self.attentionUserListM.count;
}
//绘制tableViewCell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *userTableViewCell=@"cellID1";
    attentionViewControllerUserTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:userTableViewCell];
    if (cell==nil) {
        cell=[[attentionViewControllerUserTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:userTableViewCell];
        
    }
    cell.selectionStyle=UITableViewCellSelectionStyleNone ;
//    [cell.userPhotoImgView sd_setImageWithURL:[NSURL URLWithString:[self.attentionUserListM[indexPath.row] objectForKey:@"photo"]]];
//    cell.userNameTextLabel.text=[self.attentionUserListM[indexPath.row]objectForKey:@"userName"];
    return cell;
}


//设置有多少Section
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
//设置头表头高度
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.1;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return kHeight*0.11;
}



#pragma mark --UICollectionViewDataSource
//定义展示的UICollectionViewCell的个数
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return 30;
    //return self.attentionTopicListM.count;
}
//定义展示的Section的个数
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}
//每个UICollectionView的展示内容
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identify =@"cell";
    [collectionView registerClass:[attentionViewControllerTopicCollectionViewCell class] forCellWithReuseIdentifier:identify];
    attentionViewControllerTopicCollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:identify forIndexPath:indexPath];
    [cell sizeToFit];
    if (!cell) {
        cell = [[attentionViewControllerTopicCollectionViewCell alloc]init];
    }
    // UIImageView *imgview = [UIImageView url:self.totleArr];
//    [cell.topicImgView sd_setImageWithURL:[NSURL URLWithString:[self.attentionTopicListM[indexPath.row]objectForKey:@"logo"]]];
    return cell;
}

#pragma mark --UICollectionViewDelegateFlowLayout
//定义每个UICollectionView 大小
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(kWidth*0.44, kWidth*0.44);
}

//定义每个UICollectinView的 间距
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(kWidth*0.04, kWidth*0.04, 0,kWidth*0.04);
    
}

//定义每个UICollectionView的 纵向间距
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    
    return 0.04*kWidth;
}


#pragma mark --UICollectionViewDelegate
//UICollectionView被选中时调用的方法
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"选择了%ld",indexPath.row);
}

//返回这个UICollectionView是否可以被选择；
-(BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

NSInteger cusTag = 101;
-(void)attentionButtonClick:(UIButton *)sender
{
    UIButton *cusBtn = (UIButton *)[self.view viewWithTag:cusTag];
    [cusBtn setTitleColor:kColor(216, 216, 216) forState:UIControlStateNormal];
    switch (sender.tag) {
        case 101:
            [sender setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
//===============================================================================
            [self userAttentionTopicWithUrl:[[[NSUserDefaults standardUserDefaults] objectForKey:kUserId] intValue]];
//===============================================================================
            [_userTableView removeFromSuperview];
            [self.view addSubview:_topicCollectionView];
            break;
        case 102:
            [sender setTitleColor:kColor(0, 216, 165) forState:UIControlStateNormal];
//===============================================================================
            [self userAttentionUserWithUrl:[[[NSUserDefaults standardUserDefaults] objectForKey:kUserId] intValue]];
//===============================================================================
            [_topicCollectionView removeFromSuperview];
            [self.view addSubview:_userTableView];
            break;
        default:
            break;
    }
    
    cusTag = sender.tag;
}

#pragma mark -- load data
//用户关注"用户"列表获取
-(void)userAttentionUserWithUrl:(int)userId
{
    NSString *strUrl=[NSString stringWithFormat:@"%@%@",HOST,@"member/concern/users"];
    NSDictionary *attentionTopicDic=@{@"userId":[NSNumber numberWithInt:userId],//获取用户的id
                                      kAuthCode:[[NSUserDefaults standardUserDefaults]objectForKey:kAuthCode],
                                      kDeviceToken:[[NSUserDefaults standardUserDefaults] objectForKey:kDeviceToken]};
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:strUrl parameters:attentionTopicDic success:^(AFHTTPRequestOperation *operation, id responseObject) {
         NSLog(@"userList :%@",responseObject);
        
        if ([[responseObject objectForKey:@"code"] intValue] == 1 ) {
            
            [self.attentionUserListM removeAllObjects];
            
            for (NSDictionary *dic in [[responseObject objectForKey:@"data"] objectForKey:@"rows"]) {
                
                [self.attentionUserListM addObject:dic];
            }
            
            [self.userTableView reloadData];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
         NSLog(@"cancel error:%@",error);
    }];
}

//用户关注"话题"列表获取
-(void)userAttentionTopicWithUrl:(int)userId
{
    NSString *strUrl=[NSString stringWithFormat:@"%@%@",HOST,@"member/concern/topics"];
    NSDictionary *attentionTopicDic=@{@"userId":[NSNumber numberWithInt:userId],//获取用户的id
                                      kAuthCode:[[NSUserDefaults standardUserDefaults]objectForKey:kAuthCode],
                                      kDeviceToken:[[NSUserDefaults standardUserDefaults] objectForKey:kDeviceToken]};
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:strUrl parameters:attentionTopicDic success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"topic :%@",responseObject);
        
        if ([[responseObject objectForKey:@"code"] intValue] == 1 ) {
            
             [self.attentionTopicListM removeAllObjects];
            
            for (NSDictionary *dic in [[responseObject objectForKey:@"data"] objectForKey:@"rows"]) {
                
                [self.attentionTopicListM addObject:dic];
            }
            
            [self.topicCollectionView reloadData];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"cancel error:%@",error);
    }];
}


//取消关注
-(void)cancelAttentionToServiceWithConcernUserId:(int)concernUserId
{
    NSString *cancelStr = [NSString stringWithFormat:@"%@%@",HOST,@"site/user/concern/canel"];
    NSDictionary *parameter = @{@"id":[NSNumber numberWithInt:concernUserId],//这个值要根据作品获取
                                kAuthCode:[[NSUserDefaults standardUserDefaults] objectForKey:kAuthCode],
                                kDeviceToken:[[NSUserDefaults standardUserDefaults] objectForKey:kDeviceToken]};
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager POST:cancelStr parameters:parameter success:^(AFHTTPRequestOperation *operation, id responseObject) {
//        if ([[responseObject objectForKey:@"code"] intValue]==1) {
//            
//            likeImage.image=[UIImage imageNamed:@"xihuan"];
//        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        NSLog(@"cancel error:%@",error);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
