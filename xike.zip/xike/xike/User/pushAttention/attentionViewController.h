//
//  attentionViewController.h
//  xike
//
//  Created by a on 15/6/11.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "common.h"
#import "AFNetworking.h"
#import "Networking.h"
@interface attentionViewController : UIViewController
@end
