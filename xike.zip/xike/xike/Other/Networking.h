//
//  Networking.h
//  xike
//
//  Created by shaker on 15/6/26.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#ifndef xike_Networking_h
#define xike_Networking_h


#import "MJRefresh.h"
#import "MBProgressHUD+Add.h"
#import "MobClick.h"
#import "MyAlertView.h"

// host url

#define TESTHOST     @"http://172.1.31.161/"
#define HOST         @"http://mapi.xikenow.com/"//http://mapi.shaker.mobi/

#define HOSTIMAGE    @"http://image.shaker.mobi/"
#define HOSTZITIQH   @"http://mapi.xikenow.com/font/QH.TTF" //纤黑
#define HOSTZITISONG @"http://mapi.xikenow.com/font/SONG.TTF" //宋体
#define HOSTZITIFS   @"http://mapi.xikenow.com/font/FZFS.TTF" //仿宋

//http://mapi.xikenow.com/font/QH.TTF 纤黑 http://mapi.xikenow.com/font/SONG.TTF 宋体 http://mapi.xikenow.com/font/FZFS.TTF 仿宋


#define WXAppid @"wxca9958c9b1340c67"
#define WXAppSecect @"da1c1b7d4c36be3f5bdcb8be017c5911"
#define WeiboAppKey @"3549384627"
#define WeiboAppSecret @"7cc92f9aa73c34a79d3d28a6209bc738"
#define WeiboRedirectURL @"https://api.weibo.com/oauth2/default.html"
#define otherLogonPassword @"otherLogon"
#endif
