//
//  UIImage+Edit.h
//  PhotoEdit
//
//  Created by shaker on 15/5/19.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Edit)

- (UIImage *)imageRotatedByRadians:(CGFloat)radians;

@end
