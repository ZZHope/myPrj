//
//  dataBaseCommon.h
//  xike
//
//  Created by shaker on 15/7/23.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#ifndef xike_dataBaseCommon_h
#define xike_dataBaseCommon_h

#define kUserInfoTable   @"userInfo"
#define kRelationShipTable  @"relationShip"
#define kTypeFaceTable   @"typeFace"

#define kDataBaseName    @"shakerDataBase"

#pragma mark -- userInfo

#define kAccount  @"account"
#define kNickName @"nickName"
#define kProfileUrl  @"profileUrl"
#define kUserId    @"userId"


#pragma mark -- relation

#define kUserId @"userId"
#define kFansId @"fansId"

#pragma mark -- typeFace

#define kTypeFaceName  @"typeFaceName"
#define kTypeSize      @"typeSize"
#define kTypePath      @"typePath"
#define kUserId        @"userId"

#endif
