//
//  UIImage+Edit.m
//  PhotoEdit
//
//  Created by shaker on 15/5/19.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "UIImage+Edit.h"

#define DegreesToRadians(degrees)  degrees * M_PI / 180
#define RadiansToDegrees(radians)  radians * 180/M_PI

@implementation UIImage (Edit)


- (UIImage *)imageRotatedByRadians:(CGFloat)radians
{
    return [self imageRotatedByDegrees:RadiansToDegrees(radians)];
}

- (UIImage *)imageRotatedByDegrees:(CGFloat)degrees
{
    UIView *rotatedViewBox = [[UIView alloc] initWithFrame:CGRectMake(0,0,self.size.width, self.size.height)];
    CGAffineTransform t = CGAffineTransformMakeRotation(DegreesToRadians(degrees)); //弧度
    //说明
    /*CGAffineTransformMakeRotation ( CGFloat angle );
     The angle, in radians, by which this matrix rotates the coordinate system axes. In iOS, a positive value specifies counterclockwise rotation and a negative value specifies clockwise rotation. In OS X, a positive value specifies clockwise rotation and a negative value specifies counterclockwise rotation.
     */
    
    rotatedViewBox.transform = t;
    CGSize rotatedSize = rotatedViewBox.frame.size;

    
    UIGraphicsBeginImageContext(rotatedSize);
    CGContextRef bitmap = UIGraphicsGetCurrentContext();
    
    CGContextTranslateCTM(bitmap, rotatedSize.width/2, rotatedSize.height/2);
    
    CGContextRotateCTM(bitmap, DegreesToRadians(degrees));//角度
    
    /*
     CGContextRotateCTM ( CGContextRef c, CGFloat angle );
     
     The angle, in radians, by which to rotate the coordinate space of the specified context. Positive values rotate counterclockwise(逆时针) and negative values rotate clockwise.)
     */
    
    CGContextScaleCTM(bitmap, 1.0, -1.0);
    CGContextDrawImage(bitmap, CGRectMake(-self.size.width / 2, -self.size.height / 2, self.size.width, self.size.height), [self CGImage]);//新图片的位置,画图区域
    
    UIImage *resImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return resImage;
}





@end
