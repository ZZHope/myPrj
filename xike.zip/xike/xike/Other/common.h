//
//  common.h
//  xike
//
//  Created by shaker on 15/6/1.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#ifndef xike_common_h
#define xike_common_h

//系统有关
#define kWidth   self.view.bounds.size.width
#define kHeight  self.view.bounds.size.height
#define DeviceVersion  [[[UIDevice currentDevice]systemVersion] floatValue]
#define LINESPACE 5
#define LINESPACE2 8
//设置颜色
#define kColor(R,G,B)  [UIColor colorWithRed:R/255.0 green:G/255.0 blue:B/255.0 alpha:1.0]
#define kDefaultColor  [UIColor colorWithRed:0/255.0 green:216/255.0 blue:165/255.0 alpha:1.0]

//自定义tabbar时用到（之后可以删除）
#define NormalImgName @"normal"
#define HightLightedImgName  @"hightLight"


//topicDetail复用标志
#define FromTopic            @"fromTopic"
#define CompleteTopic        @"completeTopic"
#define TakePartInTopic      @"takePartInTopic"
#define kReplaceOnePic       @"replaceOnePic"

//获取照片库

#define  KOriginalPhotoImagePath   [[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) objectAtIndex:0] stringByAppendingPathComponent:@"OriginalPhotoImages"]

#define kImgUrl     @"photoUrl" //bigPhoto
#define kThumbnail  @"thumbPic" //
#define kImgName    @"imgName"  //imageName
#define kSelPhoto   @"selPhoto" //选中的标志位
#define kFullImage  @"fullImage"
#define kOriginalPhotoImages  @"OriginalPhotoImages"


//跳转标志
#define kAddPhotos @"addPhoto"

//字体

#define kHeitiSC  @"Heiti SC"
#define kIsLantingD  @"FZLTXHK--GBK1-0IsD"
#define kIsSongD  @"STSongti-SC-RegularIsD"
#define kIsFangSongD @"STFangsongIsD"

//syncronize
#define isLogin @"isLogin"
#define  kAuthCode @"authCode"
#define kDeviceToken @"deviceToken"
#define kWorksId @"worksId"
#define kUserId @"userId"
#endif
