//
//  Contants.h
//  xike
//
//  Created by Leading Chen on 14/11/1.
//  Copyright (c) 2014年 Leading. All rights reserved.
//

#ifndef xike_Contants_h
#define xike_Contants_h

#define app_version 2.000f
//#define HOST @"http://121.40.139.180:8081"
//#define HOST_2 @"http://121.40.139.180:80"
//#define HOST_3 @"http://shaker.mobi"
#define HOST_4 @"http://v2.shaker.mobi"
#define tmpHost @"http://10.207.194.63:18080"
#define WXAppid @"wxca9958c9b1340c67"
#define WXAppSecect @"da1c1b7d4c36be3f5bdcb8be017c5911"
#define WeiboAppKey @"3549384627"
#define WeiboAppSecret @"7cc92f9aa73c34a79d3d28a6209bc738"
#define WeiboRedirectURL @"https://api.weibo.com/oauth2/default.html"
#define otherLogonPassword @"otherLogon"

#define viewWidth self.view.bounds.size.width
#define viewHeight self.view.bounds.size.height
#endif
