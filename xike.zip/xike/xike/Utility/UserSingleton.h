//
//  CbyUserSingleton.h
//  51CBY
//
//  Created by SJB on 15/2/7.
//  Copyright (c) 2015年 SJB. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserSingleton : NSObject

@property(nonatomic, copy) NSString *accountNumber;//邮箱
@property(nonatomic, copy) NSString *userID;
@property(nonatomic, assign) BOOL login;
@property(nonatomic, copy) NSString *nickName;
@property(nonatomic, copy) NSString *profileUrl;
@property(nonatomic, copy) NSString *deviceToken;
@property(nonatomic, copy) NSString *authCode;
@property(nonatomic, copy) NSString *fontName;

@property (nonatomic, copy) NSString *tabItemIndex;

+(UserSingleton *)shareUserSingleton;

@end
