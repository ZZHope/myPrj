//
//  test.h
//  testProgress
//
//  Created by shaker on 15/6/3.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "common.h"
@interface test : UIView
@property(nonatomic, assign)float progressRate;
@property(nonatomic, strong)UIColor *color;
@property(nonatomic, assign)float x;
@property(nonatomic, assign)float y;
@property(nonatomic, assign)float radius;
@property(nonatomic, assign)float startAngle;


@end
