//
//  CbyUserSingleton.m
//  51CBY
//
//  Created by SJB on 15/2/7.
//  Copyright (c) 2015年 SJB. All rights reserved.
//

#import "UserSingleton.h"

@implementation UserSingleton
static UserSingleton *userInfo;

+(id)allocWithZone:(struct _NSZone *)zone
{
    static UserSingleton *userInfo;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
       
        userInfo = [super allocWithZone:zone];
    });
    
    return userInfo;
}


+(UserSingleton *)shareUserSingleton
{
    if (!userInfo) {
        userInfo = [[UserSingleton alloc]init];
    }
    return userInfo;
}

-(id)init
{
    self = [super init];
    if (self) {
        
        [self initWithAccountNum:@"" userID:@"" isLogin:NO nickName:@"" profileUrl:@"" deviceTocken:@"" authCode:@"" fontName:@"Heiti SC" barItemIndex:@"0"];
    }
    return self;
    
   }

//便利初始化个人信息
-(void)initWithAccountNum:(NSString *)accountNum
                 userID:(NSString *)userID
                isLogin:(BOOL)login
               nickName:(NSString *)nickName
             profileUrl:(NSString *)profileUrl
             deviceTocken:(NSString*)deviceToken
                 authCode:(NSString*)authCode
                 fontName:(NSString*)fontName
             barItemIndex:(NSString*)barItemIndex

{
    _accountNumber = [[NSString alloc] initWithString:accountNum];
    _userID = [[NSString alloc]initWithString:userID];
    _nickName = [[NSString alloc]initWithString:nickName];
    _profileUrl = [[NSString alloc]initWithString:profileUrl];
    _deviceToken = [[NSString alloc]initWithString:deviceToken];
    _authCode = [[NSString alloc]initWithString:authCode];
    _fontName = [[NSString alloc]initWithString:fontName];
    _tabItemIndex = [[NSString alloc]initWithString:barItemIndex];
}




-(id)copy
{
    return self;
}

@end
