//
//  MyAlertView.h
//  xike
//
//  Created by shaker on 15/8/12.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol MyAlertViewDelegate <NSObject>

@optional
-(void)dismissMyAlert;

@end

@interface MyAlertView : UIView

@property(nonatomic,assign) id<MyAlertViewDelegate>deletage;

+(void)showMessageToView:(UIView*)view;

@end
