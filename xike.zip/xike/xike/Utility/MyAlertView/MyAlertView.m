//
//  MyAlertView.m
//  xike
//
//  Created by shaker on 15/8/12.
//  Copyright (c) 2015年 shaker. All rights reserved.
//

#import "MyAlertView.h"

@implementation MyAlertView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/


-(id)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        
        self.backgroundColor = [[UIColor blackColor]colorWithAlphaComponent:0.5f];
        [self buildSubView];
    }
    return self;
}


-(void)buildSubView
{
    UIImageView *msgView = [[UIImageView alloc]initWithFrame:CGRectMake((self.bounds.size.width-153)*0.5, (self.bounds.size.height-153)*0.5, 153, 153)];
    msgView.backgroundColor = [UIColor whiteColor];
    msgView.image = [UIImage imageNamed:@"tanchuang"];
    msgView.userInteractionEnabled = YES;
    [self addSubview:msgView];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(hideAlert)];
    [self addGestureRecognizer:tap];
    [self performSelector:@selector(dismissMyAlert) withObject:self afterDelay:2.0f];
}

+(void)showMessage:(NSString *)message toView:(UIView *)view
{
    
}

+(void)showMessageToView:(UIView*)view{
    MyAlertView *alert = [[self alloc]initWithFrame:view.bounds];
    [view addSubview:alert];
    
    //[view addSubview:self];
}

//gesture
-(void)hideAlert
{
    [self removeFromSuperview];
}

-(void)dismissMyAlert
{
   [self removeFromSuperview];
}


@end
